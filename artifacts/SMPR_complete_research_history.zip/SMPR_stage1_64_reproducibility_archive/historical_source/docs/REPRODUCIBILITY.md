# SMPR 复现指南

本指南区分三类任务：

1. **软件完整性验证**：秒级，不运行路由；
2. **V5 五例冒烟测试**：验证 Qiskit、持久分片、合并和质量参考；
3. **冻结 V5/V6 全量复现**：用于重新生成逐实例结果。

## 1. 解压到独立目录

```powershell
$zip = Get-ChildItem "$env:USERPROFILE\Downloads" `
  -Filter "SMPR_quantum_router_stage64_source_*.zip" |
  Sort-Object LastWriteTime -Descending |
  Select-Object -First 1

if (-not $zip) { throw "未找到 Stage 64 ZIP" }

$dest = "$env:USERPROFILE\smpr-stage64"
New-Item -ItemType Directory -Force -Path $dest | Out-Null
Expand-Archive -LiteralPath $zip.FullName -DestinationPath $dest -Force
Set-Location "$dest\SMPR_quantum_router_stage64"
```

不要在旧项目目录内直接覆盖解压，以免本机实验结果、旧虚拟环境和新源码混合。

## 2. 创建环境

冻结依赖为 Qiskit 2.4.2、qiskit-qasm3-import 0.6.0，支持
Python 3.10--3.12：

```powershell
py -3.10 -m venv .venv-smpr
.\.venv-smpr\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r .\requirements-frozen.txt
python -m pip install -e .
```

若机器没有 Python Launcher，可直接使用版本在 3.10--3.12 的 `python`：

```powershell
python --version
python -m venv .venv-smpr
```

## 3. 完整性、自检与测试

```powershell
python .\scripts\verify_release.py
python -c "import quantum_router; print(quantum_router.__version__)"
python -m quantum_router doctor
python -m unittest discover -s .\tests -v
```

预期：

```text
verification failures: 0
PASSED: True
0.4.0
[PASS] stage imports
[PASS] frozen_v5.toml
[PASS] frozen_v6.toml
[PASS] qiskit: installed=2.4.2, expected=2.4.2
[PASS] qiskit-qasm3-import: installed=0.6.0, expected=0.6.0
[PASS] credential files
[PASS] Stage 64 evidence
Ran 21 tests
OK
```

如果 `No module named quantum_router`，说明 editable 安装没有成功或当前激活的
虚拟环境不对。使用：

```powershell
Get-Command python
python -m pip show smpr-quantum-router
python -m pip install -e .
```

## 4. 五例冒烟测试

```powershell
python -m quantum_router run `
  --config .\configs\frozen_v5.toml `
  --executor persistent `
  --case-indices 1,25,28,53,56 `
  --workers 4 `
  --quality-reference .\evidence\reference\v5_cases.csv `
  --quality-policy exact `
  --output-dir .\results\stage64_v5_smoke
```

预期主结果：

```text
cases: 5
LightSABRE total SWAP: 191
SMPR total SWAP: 182
selected branches: {'cross_layout': 5}
audits: 5 5 5
safe quality floor: True
quality mismatches: 0
```

原始冻结 CSV 仍保留历史来源标签；Stage 64 控制台和公开结果使用跨布局分支。

若四个分片已成功完成、但合并阶段意外中止，在相同命令后加：

```powershell
--resume
```

恢复运行应显示 `resumed`。恢复墙钟只测量验证和合并已有结果，不能报告为
路由耗时。

## 5. 可靠性审计

```powershell
python -m quantum_router audit `
  --v5-cases .\evidence\reference\v5_cases.csv `
  --v6-cases .\evidence\reference\v6_cases.csv `
  --output-dir .\results\stage64_case_audit
```

应验证：

- V5/V6 行数与因子结构；
- 实例唯一、索引连续；
- 映射为合法排列；
- 三项审计全部通过；
- SMPR 和双分支选择均不劣于 LightSABRE；
- Stage 60 总量复算一致；
- 实例级和 cluster bootstrap 区间上端小于 0；
- 所有留一层级改善为正。

## 6. 全量 V5

```powershell
python -m quantum_router run `
  --config .\configs\frozen_v5.toml `
  --executor persistent `
  --workers 4 `
  --schedule lpt `
  --quality-reference .\evidence\reference\v5_cases.csv `
  --quality-policy exact `
  --output-dir .\results\stage64_v5
```

预期：

```text
cases: 60
LightSABRE total SWAP: 1691
SMPR total SWAP: 1641
quality mismatches: 0
```

可选加入旧逐例时间参考改善 LPT：

```powershell
--timing-reference .\path\to\stage57_parallel_v5_console.txt
```

## 7. 全量 V6

```powershell
python -m quantum_router run `
  --config .\configs\frozen_v6.toml `
  --executor persistent `
  --workers 4 `
  --schedule lpt `
  --quality-reference .\evidence\reference\v6_cases.csv `
  --quality-policy primary `
  --output-dir .\results\stage64_v6
```

预期主字段：

```text
cases: 120
LightSABRE total SWAP: 3176
SMPR total SWAP: 3051
selected branches: {'cross_layout': 51, 'lightsabre': 62, 'independent_rollout': 7}
audits: 120 120 120
safe quality floor: True
```

输出标签与列名为历史证据兼容保留。`primary` 允许 case 39 的一个已隔离辅助
深度差异，但仍严格检查选中来源、最终 SWAP、最终深度和审计字段。

## 8. 发布内证据复核

发布包附带 2026-07-25 独立安装复现的原始证据。执行：

```powershell
python -m quantum_router verify-evidence `
  --evidence-root .\evidence\verified_20260725 `
  --output-dir .\results\stage64_verified_evidence
```

预期：

```text
evidence hashes: 18/18
public legacy-name leaks: 0
PASSED: True
```

输出包含 `v5_public_cases.csv`、`v6_public_cases.csv`、最终报告、汇总 JSON
和 SHA-256 清单。该命令不会重跑路由，而是复核已归档的逐实例结果、环境、
联合统计审计和上传哈希。

## 9. 确定性探针

```powershell
.\scripts\run_deterministic_probe_v5.ps1
```

该配置把运行时间破平替换为种子、初始映射和标签。它是 Stage 64 正式规范的
回归入口，但不是冻结 V5/V6 结果的替代品。

## 10. 建议记录的环境信息

每次正式全量运行前保存：

```powershell
python --version | Tee-Object .\results\python-version.txt
python -m pip freeze | Tee-Object .\results\pip-freeze.txt
Get-ComputerInfo |
  Select-Object WindowsProductName,WindowsVersion,OsArchitecture,CsProcessors,
    CsTotalPhysicalMemory |
  Format-List |
  Out-File .\results\machine-info.txt
```

并设置：

```powershell
$env:PYTHONHASHSEED = "0"
$env:OMP_NUM_THREADS = "1"
$env:OPENBLAS_NUM_THREADS = "1"
$env:MKL_NUM_THREADS = "1"
```

CLI 子进程会再次固定这些关键变量。

## 11. 结果文件

每个输出目录至少应含：

- `cases.csv`：逐实例主结果；
- `attempts.csv`：候选尝试明细（适用时）；
- `summary.json`：汇总与执行元数据；
- `SHA256SUMS.txt`：输出完整性；
- 分片子目录及其清单（持久执行）。

正式归档时同时保存控制台日志，不要只保存最后一段摘要。

## 12. 凭据与隐私

发布包不得包含 API key、许可证、`.env` 或私钥。验证脚本会检查常见敏感文件。
如任何凭据曾被放入共享压缩包，即使后来删除，也应视为可能泄漏并立即轮换。
