# SMPR 正式算法规范

**算法名称：** Safe Multi-Layout Portfolio Router（SMPR）  
**规范版本：** 0.4.0 / Stage 64  
**主要质量序：** `(SWAP count, weighted depth)`  
**确定性选择：** `(quality, source priority, seed, mapping, label)`

## 1. 输入、输出与不变量

输入为逻辑线路 \(C=(Q,G,E_C)\)、无向耦合图
\(\mathcal H=(V,E_H)\) 和参数
\((r,k,b,\gamma)\)。其中 \(r\) 是 LightSABRE 试验数，\(k\) 是完整策略
展开宽度，\(b\) 是每个基布局保留的一换位邻居数，\(\gamma\) 是布局代理衰减。

输出包含：

1. 物理线路；
2. 初始、最终逻辑—物理映射；
3. SWAP 数和加权深度；
4. 候选来源和确定性标识；
5. 语义、拓扑、指标审计记录；
6. 输出文件的 SHA-256。

对任一中间路由状态必须保持：

- `logical_to_physical` 是单射；
- `physical_to_logical` 与正向映射互逆；
- 已执行门的所有 DAG 前驱都已执行；
- 每个已输出双比特门位于硬件耦合边；
- SWAP 同步更新正、逆映射，并在加权深度中占用 3 个时间单位。

## 2. 质量定义

主目标为新增 SWAP 数 \(S(c)\)。加权深度采用资源占用式调度：SWAP 权重
为 3，其余一、双比特门权重为 1。候选质量是

\[
q(c)=(S(c),D_w(c)),
\]

按字典序最小化。深度只在 SWAP 相同时参与选择。

正式确定性键为

\[
K_d(c)=
\bigl(S(c),D_w(c),p(c),\sigma(c),m(c),\ell(c)\bigr),
\]

其中来源优先级为：

1. `lightsabre`；
2. `cross_layout`（历史文件中可能使用旧标签）；
3. `adaptive_rollout`（历史文件中可能使用旧标签）。

\(\sigma\) 为种子，\(m\) 为初始映射规范元组，\(\ell\) 为候选标签。运行时间
不参与正式确定性破平。

## 3. 路由状态与闭包执行

每次 SWAP 决策前执行 `Drain`：

1. 找到 DAG 入度已归零的门；
2. 单比特门立即执行；
3. 双比特门仅当映射后的物理端点相邻时执行；
4. 更新后继门剩余入度；
5. 重复直到没有新门可执行。

闭包保证一个 SWAP 的价值包含其连续解锁的所有门，而非只计算交换后的瞬时
距离。

对双比特门 \(g(q_i,q_j)\)，路由距离为

\[
\delta_{\mathcal H}(g,\pi)=
d_{\mathcal H}(\pi(q_i),\pi(q_j))-1.
\]

前沿门和有序扩展集构成势函数：

\[
\Phi(s)=
\sum_{g\in\mathcal F(s)}\delta_{\mathcal H}(g,\pi_s)
+\sum_{i=0}^{|\mathcal X(s)|-1}2^{-i}
\delta_{\mathcal H}(\mathcal X_i(s),\pi_s).
\]

候选边来自前沿/扩展门物理端点的邻接边，以及这些端点之间确定性最短路径上的
边。候选先按一步代理排序，再只对前 \(k\) 项执行完整展开。

## 4. 完整基线策略展开

设冻结一步策略为 \(\pi_0\)。对候选 SWAP \(a\)，应用交换、执行闭包，再由
\(\pi_0\) 完成剩余线路：

\[
Q^{\pi_0}(s,a)=1+V^{\pi_0}(T(s,a)).
\]

若最优展开候选的剩余 SWAP **严格** 少于基线动作，才接受该候选；相等时保留
基线动作。这一严格门槛避免同值动作在逐步重规划中产生无意义循环。

伪代码：

```text
function ROLLOUT_STEP(state s, width k):
    Drain(s)
    A ← generate_candidates(s)
    A ← stable_sort(A, one_step_heuristic)
    a0 ← first(A)
    B ← first_k(A) ∪ {a0}
    for a in B:
        s_a ← deepcopy(s)
        apply_swap(s_a, a)
        Drain(s_a)
        q[a] ← 1 + complete_with_baseline_policy(s_a)
    â ← stable_argmin(q, deterministic_action_key)
    if q[â] < q[a0]:
        return â
    return a0
```

## 5. 多布局候选

### 5.1 LightSABRE 质量下界

运行种子 \(0,\ldots,r-1\)，保存每个候选的真实线路和初始布局。最佳
LightSABRE 候选必须始终进入最终候选集，不能只保留其计数摘要。

### 5.2 独立展开分支

使用自身冻结布局池运行完整展开路由。该分支提供策略多样性，但不是质量下界。
V6 证据显示它单独弱于 LightSABRE，因此不能把最终收益归因于该分支本身。

### 5.3 跨布局迁移

先收集 LightSABRE 中 \(q(c)=q_L^\*\) 的所有候选，按
`(seed, initial_mapping, label)` 排序并按映射去重。对每个布局 \(\pi\)，
计算布局代理

\[
P_\gamma(\pi)=
\sum_{i=0}^{M-1}\gamma^i
d_{\mathcal H}(\pi(q_i),\pi(q'_i)).
\]

枚举一换位邻域

\[
\mathcal N_1(\pi)=\{\pi\circ(i\,j)\mid 0\le i<j<n\},
\]

按 `(proxy, mapping)` 排序并保留前 \(b\) 个。每个基布局和保留邻居都从原始
逻辑线路冷启动完整路由。代理只决定预算，不直接决定最终输出。

## 6. SMPR 总流程

```text
function SMPR(circuit C, hardware H, parameters θ):
    P ← ∅

    LS ← run_lightsabre_trials(C, H, seeds=0..r-1)
    validate_all(LS)
    P ← P ∪ {best(LS)}

    R ← run_independent_adaptive_rollout(C, H, θ)
    validate_all(R)
    P ← P ∪ R

    layouts ← unique_tied_best_layouts(LS)
    for π in layouts:
        L ← {π} ∪ top_b_one_transposition_neighbors(π, γ)
        for mapping in stable_unique(L):
            c ← cold_route_with_rollout(C, H, mapping, θ)
            validate(c)
            P ← P ∪ {c}

    winner ← argmin(P, deterministic_candidate_key)
    assert quality(winner) ≤ quality(best(LS))
    export(winner)
    audit_semantics_topology_metrics(winner)
    return winner
```

## 7. 安全性

设最佳 LightSABRE 候选为 \(c_L\)，且 \(c_L\in\mathcal P\)。因为
\(c^\*=\arg\min_{c\in\mathcal P}K_d(c)\)，所以

\[
S(c^\*)\le S(c_L).
\]

若 SWAP 相等，则

\[
D_w(c^\*)\le D_w(c_L).
\]

这是候选集合和字典序选择的结构性质，不要求其他分支单独优于基线。实现仍须
通过导出后指标审计，排除内部计数与物理线路不一致。

## 8. 复杂度

设并列最优布局数为 \(L\)，一换位邻域有 \(\binom n2\) 项。直接代理筛选成本
为 \(O(Ln^2M)\)，跨布局完整路由次数最多为 \(L(1+b)\)。总抽象时间为

\[
O\!\left(
rT_{\mathrm{LS}}+T_{\mathrm{rollout}}+
Ln^2M+L(1+b)T_{\mathrm{rollout}}
\right).
\]

持久分片只减少进程启动和依赖导入，并在实例级并行；它不改变该单实例工作量。

## 9. 冻结证据兼容

V5/V6 冻结证据使用历史键

\[
K_f(c)=
(S(c),D_w(c),p(c),runtime(c),label(c)).
\]

`legacy` 配置必须用于精确复现这些结果。`deterministic` 配置实现本规范，但
切换破平规则视为版本边界。即使两种模式共享质量安全定理，也不能把既有 V6
描述为确定性模式的未见盲测。
