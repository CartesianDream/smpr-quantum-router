from __future__ import annotations

import contextlib
import io
import runpy
import unittest
from importlib import metadata as importlib_metadata
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from quantum_router.cli import build_route_command, command_doctor
from quantum_router.config import load_config
from quantum_router.legacy import find_repo_root, missing_stage_imports


class ConfigAndCliTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.root = find_repo_root(Path(__file__).resolve())

    def test_v5_and_v6_hashes_validate(self) -> None:
        for name in ("frozen_v5.toml", "frozen_v6.toml"):
            config = load_config(self.root / "configs" / name, self.root)
            config.validate_input()

    def test_all_stage_imports_are_present(self) -> None:
        self.assertEqual(missing_stage_imports(self.root), [])

    def test_package_metadata_and_release_safety(
        self,
    ) -> None:
        metadata = (self.root / "pyproject.toml").read_text(encoding="utf-8")
        requirements = (self.root / "requirements-frozen.txt").read_text(
            encoding="utf-8"
        )
        self.assertIn('name = "smpr-quantum-router"', metadata)
        self.assertIn('version = "0.4.0"', metadata)
        self.assertIn('"qiskit-qasm3-import==0.6.0"', metadata)
        self.assertIn("qiskit-qasm3-import==0.6.0", requirements)
        self.assertIn('requires-python = ">=3.10"', metadata)
        self.assertIn(
            "\"tomli==2.2.1; python_version < '3.11'\"",
            metadata,
        )
        self.assertIn(
            'tomli==2.2.1; python_version < "3.11"',
            requirements,
        )
        builder = runpy.run_path(
            str(self.root / "scripts" / "build_source_release.py")
        )
        self.assertFalse(
            builder["excluded"](
                Path("evidence/verified_20260725/v5/SHA256SUMS.txt")
            )
        )
        arguments = SimpleNamespace(
            repo_root=str(self.root),
            allow_missing_qiskit=True,
            json=True,
        )
        with patch(
            "quantum_router.cli.metadata.version",
            side_effect=importlib_metadata.PackageNotFoundError,
        ), contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(command_doctor(arguments), 0)

    def test_persistent_command_contains_frozen_executor_parameters(self) -> None:
        config = load_config(
            self.root / "configs" / "frozen_v6.toml",
            self.root,
        )
        command = build_route_command(
            repo_root=self.root,
            config=config,
            executor="persistent",
            output_dir=self.root / "results" / "test",
            case_indices="1,39",
        )
        joined = " ".join(command)
        self.assertIn("stage58_persistent_sharding.py", joined)
        self.assertIn("--workers 4", joined)
        self.assertIn("--schedule lpt", joined)
        self.assertIn("--case-indices 1,39", joined)
        self.assertIn("--selection-mode legacy", joined)
        self.assertIn("--quality-policy exact", joined)

    def test_sequential_command_exposes_all_frozen_portfolio_values(self) -> None:
        config = load_config(
            self.root / "configs" / "frozen_v5.toml",
            self.root,
        )
        command = build_route_command(
            repo_root=self.root,
            config=config,
            executor="sequential",
            output_dir=self.root / "results" / "test",
            limit=1,
        )
        joined = " ".join(command)
        self.assertIn("stage53_cross_layout_safe_hybrid.py", joined)
        self.assertIn("--qiskit-seeds 20", joined)
        self.assertIn("--qiskit-repeats 1", joined)
        self.assertIn("--hybrid-layouts 0", joined)
        self.assertIn("--hybrid-neighbors 4", joined)
        self.assertIn("--proxy-decay 0.95", joined)
        self.assertIn("--selection-mode legacy", joined)

    def test_deterministic_probe_is_explicit_in_command(self) -> None:
        config = load_config(
            self.root / "configs" / "deterministic_probe_v5.toml",
            self.root,
        )
        command = build_route_command(
            repo_root=self.root,
            config=config,
            executor="persistent",
            output_dir=self.root / "results" / "probe",
            case_indices="1",
        )
        self.assertIn("--selection-mode deterministic", " ".join(command))


if __name__ == "__main__":
    unittest.main()
