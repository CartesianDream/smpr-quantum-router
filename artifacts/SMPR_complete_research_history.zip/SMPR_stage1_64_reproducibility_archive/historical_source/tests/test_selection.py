from __future__ import annotations

import unittest
from dataclasses import dataclass

from quantum_router.selection import (
    deterministic_candidate_key,
    legacy_candidate_key,
    select_safe_candidate,
    unique_best_quality_layouts,
)


@dataclass
class Candidate:
    backend: str
    label: str
    swap: int
    depth: int
    runtime_ms: float
    initial_mapping: tuple[int, ...]
    seed: int | None


class SelectionTests(unittest.TestCase):
    def test_deterministic_key_ignores_runtime(self) -> None:
        slow_seed_zero = Candidate(
            "lightsabre",
            "seed0",
            5,
            12,
            100.0,
            (0, 1, 2),
            0,
        )
        fast_seed_one = Candidate(
            "lightsabre",
            "seed1",
            5,
            12,
            1.0,
            (2, 1, 0),
            1,
        )
        self.assertIs(
            min((slow_seed_zero, fast_seed_one), key=deterministic_candidate_key),
            slow_seed_zero,
        )
        self.assertIs(
            min((slow_seed_zero, fast_seed_one), key=legacy_candidate_key),
            fast_seed_one,
        )

    def test_exact_quality_tie_prefers_lightsabre(self) -> None:
        lightsabre = Candidate(
            "lightsabre", "ls", 4, 10, 99.0, (0, 1), 5
        )
        hybrid = Candidate("hybrid", "hy", 4, 10, 1.0, (1, 0), None)
        self.assertIs(
            min((hybrid, lightsabre), key=deterministic_candidate_key),
            lightsabre,
        )

    def test_unique_best_layouts_are_seed_ordered_and_deduplicated(self) -> None:
        candidates = [
            Candidate("lightsabre", "seed3", 7, 20, 1.0, (1, 0), 3),
            Candidate("lightsabre", "seed0", 7, 20, 9.0, (0, 1), 0),
            Candidate("lightsabre", "seed2", 7, 20, 0.5, (0, 1), 2),
            Candidate("lightsabre", "worse", 8, 18, 0.1, (1, 0), 1),
        ]
        selected = unique_best_quality_layouts(candidates)
        self.assertEqual([item.seed for item in selected], [0, 3])
        self.assertEqual(
            [item.initial_mapping for item in selected],
            [(0, 1), (1, 0)],
        )

    def test_safe_selection_requires_and_preserves_quality_floor(self) -> None:
        baseline = Candidate(
            "lightsabre", "ls", 8, 20, 4.0, (0, 1), 0
        )
        better = Candidate(
            "cross_layout", "transfer", 7, 22, 8.0, (1, 0), None
        )
        worse = Candidate(
            "adaptive_rollout", "rollout", 9, 18, 1.0, (0, 1), None
        )
        result = select_safe_candidate((worse, baseline, better))
        self.assertIs(result.winner, better)
        self.assertIs(result.baseline, baseline)
        self.assertEqual(result.swap_gain, 1)
        self.assertTrue(result.quality_gain)

        with self.assertRaisesRegex(ValueError, "LightSABRE"):
            select_safe_candidate((better, worse))


if __name__ == "__main__":
    unittest.main()
