from __future__ import annotations

import csv
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from quantum_router.legacy import find_repo_root


class Stage64EvidenceTests(unittest.TestCase):
    def test_verified_evidence_builds_public_release(self) -> None:
        root = find_repo_root(Path(__file__).resolve())
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary) / "public"
            completed = subprocess.run(
                [
                    sys.executable,
                    str(
                        root
                        / "experiments"
                        / "stage64_finalize_verified_release.py"
                    ),
                    "--evidence-root",
                    str(root / "evidence" / "verified_20260725"),
                    "--output-dir",
                    str(output),
                ],
                cwd=root,
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                check=False,
            )
            self.assertEqual(completed.returncode, 0, completed.stdout)
            summary = json.loads(
                (output / "summary.json").read_text(encoding="utf-8")
            )
            self.assertTrue(summary["passed"])
            self.assertEqual(summary["datasets"]["v5"]["selected_swap"], 1641)
            self.assertEqual(summary["datasets"]["v6"]["selected_swap"], 3051)
            self.assertEqual(summary["failures"], [])

            for name, expected_rows in (
                ("v5_public_cases.csv", 60),
                ("v6_public_cases.csv", 120),
            ):
                text = (output / name).read_text(encoding="utf-8").lower()
                self.assertNotIn("oaabr", text)
                self.assertNotIn("hybrid", text)
                with (output / name).open(
                    "r", encoding="utf-8", newline=""
                ) as handle:
                    rows = list(csv.DictReader(handle))
                self.assertEqual(len(rows), expected_rows)


if __name__ == "__main__":
    unittest.main()
