from __future__ import annotations

import csv
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from quantum_router.legacy import find_repo_root


class ShardResumeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        root = find_repo_root(Path(__file__).resolve())
        sys.path.insert(0, str(root / "experiments"))
        try:
            import stage58_persistent_sharding as stage58
        finally:
            sys.path.pop(0)
        cls.stage58 = stage58

    def test_resume_rejects_a_different_selection_mode(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            child = Path(temporary) / "shard_00"
            child.mkdir()
            with (child / "cases.csv").open(
                "w", encoding="utf-8", newline=""
            ) as handle:
                writer = csv.DictWriter(
                    handle,
                    fieldnames=[
                        "case_index",
                        "instance",
                        "semantic_equivalent",
                        "topology_valid",
                        "metric_valid",
                    ],
                )
                writer.writeheader()
                writer.writerow(
                    {
                        "case_index": 0,
                        "instance": "case0",
                        "semantic_equivalent": True,
                        "topology_valid": True,
                        "metric_valid": True,
                    }
                )
            (child / "attempts.csv").write_text("attempt\n1\n", encoding="utf-8")
            (child / "summary.json").write_text(
                json.dumps({"case_count": 1, "selection_mode": "legacy"}),
                encoding="utf-8",
            )
            task = self.stage58.ShardTask(
                shard_id=0,
                indices=(0,),
                instances=("case0",),
                predicted_seconds=1.0,
                child_dir=child,
                log_path=Path(temporary) / "log.txt",
            )
            self.assertTrue(
                self.stage58.validate_shard_output(task, "legacy")
            )
            self.assertFalse(
                self.stage58.validate_shard_output(task, "deterministic")
            )

    def test_primary_quality_policy_excludes_auxiliary_depth(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            reference = Path(temporary) / "reference.csv"
            with reference.open("w", encoding="utf-8", newline="") as handle:
                writer = csv.DictWriter(
                    handle,
                    fieldnames=["instance", "oaabr_depth"],
                )
                writer.writeheader()
                writer.writerow({"instance": "case39", "oaabr_depth": 29})
            rows = [{"instance": "case39", "oaabr_depth": "27"}]
            exact = self.stage58.compare_quality(rows, reference)
            primary = self.stage58.compare_quality(
                rows,
                reference,
                self.stage58.PRIMARY_QUALITY_COLUMNS,
            )
            self.assertEqual(
                exact,
                [
                    {
                        "instance": "case39",
                        "column": "oaabr_depth",
                        "reference": "29",
                        "persistent": "27",
                    }
                ],
            )
            self.assertEqual(primary, [])

    def test_resume_merges_completed_shards_end_to_end(self) -> None:
        root = find_repo_root(Path(__file__).resolve())
        with tempfile.TemporaryDirectory() as temporary:
            temporary_root = Path(temporary)
            input_path = temporary_root / "input.json"
            output = temporary_root / "output"
            input_path.write_text(
                json.dumps(
                    {
                        "cases": [
                            {"name": "case0", "n": 2, "cx_count": 1},
                            {"name": "case1", "n": 2, "cx_count": 1},
                        ]
                    }
                ),
                encoding="utf-8",
            )
            (output / "worker_logs").mkdir(parents=True)
            for index in range(2):
                child = output / "shards" / f"shard_{index:02d}"
                child.mkdir(parents=True)
                with (child / "cases.csv").open(
                    "w",
                    encoding="utf-8",
                    newline="",
                ) as handle:
                    writer = csv.DictWriter(
                        handle,
                        fieldnames=[
                            "case_index",
                            "instance",
                            "lightsabre_swap",
                            "lightsabre_depth",
                            "oaabr_swap",
                            "oaabr_depth",
                            "safe_dual_swap",
                            "selected_backend",
                            "selected_swap",
                            "selected_depth",
                            "semantic_equivalent",
                            "topology_valid",
                            "metric_valid",
                        ],
                    )
                    writer.writeheader()
                    writer.writerow(
                        {
                            "case_index": index,
                            "instance": f"case{index}",
                            "lightsabre_swap": 1,
                            "lightsabre_depth": 4,
                            "oaabr_swap": 1,
                            "oaabr_depth": 4,
                            "safe_dual_swap": 1,
                            "selected_backend": "lightsabre",
                            "selected_swap": 1,
                            "selected_depth": 4,
                            "semantic_equivalent": True,
                            "topology_valid": True,
                            "metric_valid": True,
                        }
                    )
                with (child / "attempts.csv").open(
                    "w",
                    encoding="utf-8",
                    newline="",
                ) as handle:
                    writer = csv.DictWriter(
                        handle,
                        fieldnames=["case_index", "backend", "label", "seed"],
                    )
                    writer.writeheader()
                    writer.writerow(
                        {
                            "case_index": index,
                            "backend": "lightsabre",
                            "label": "seed0",
                            "seed": 0,
                        }
                    )
                (child / "summary.json").write_text(
                    json.dumps(
                        {
                            "case_count": 1,
                            "selection_mode": "legacy",
                        }
                    ),
                    encoding="utf-8",
                )

            completed = subprocess.run(
                [
                    sys.executable,
                    str(
                        root
                        / "experiments"
                        / "stage58_persistent_sharding.py"
                    ),
                    "--input",
                    str(input_path),
                    "--workers",
                    "2",
                    "--schedule",
                    "contiguous",
                    "--stage53-script",
                    str(
                        root
                        / "experiments"
                        / "stage53_cross_layout_safe_hybrid.py"
                    ),
                    "--selection-mode",
                    "legacy",
                    "--output-dir",
                    str(output),
                    "--resume",
                ],
                cwd=root,
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                check=False,
            )
            self.assertEqual(completed.returncode, 0, completed.stdout)
            summary = json.loads(
                (output / "summary.json").read_text(encoding="utf-8")
            )
            self.assertEqual(summary["resumed_shards"], 2)
            self.assertEqual(summary["case_count"], 2)
            self.assertEqual(summary["selection_mode"], "legacy")


if __name__ == "__main__":
    unittest.main()
