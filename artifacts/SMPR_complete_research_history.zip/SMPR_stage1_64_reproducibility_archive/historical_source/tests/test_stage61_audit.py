from __future__ import annotations

import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from quantum_router.legacy import find_repo_root


class Stage61AuditTests(unittest.TestCase):
    def test_reference_cases_reproduce_stage61(self) -> None:
        root = find_repo_root(Path(__file__).resolve())
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary) / "audit"
            completed = subprocess.run(
                [
                    sys.executable,
                    str(root / "experiments" / "stage61_reliability_audit.py"),
                    "--v5-cases",
                    str(root / "evidence" / "reference" / "v5_cases.csv"),
                    "--v6-cases",
                    str(root / "evidence" / "reference" / "v6_cases.csv"),
                    "--output-dir",
                    str(output),
                ],
                cwd=root,
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                check=False,
            )
            self.assertEqual(completed.returncode, 0, completed.stdout)
            summary = json.loads(
                (output / "summary.json").read_text(encoding="utf-8")
            )
            self.assertTrue(summary["passed"])
            self.assertEqual(summary["v6"]["metrics"]["selected_swap"], 3051)
            self.assertEqual(
                summary["v6"]["iid_bootstrap_95_ci"],
                [-0.024346064814814817, -0.01363425925925926],
            )
            self.assertLess(
                summary["v6"]["cluster_bootstrap_95_ci"][1],
                0.0,
            )


if __name__ == "__main__":
    unittest.main()

