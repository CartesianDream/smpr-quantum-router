from __future__ import annotations

import contextlib
import io
import sys
import unittest
from pathlib import Path

from quantum_router import (
    CircuitDAG,
    Gate,
    HardwareGraph,
    run_shortest_path_baseline,
)
from quantum_router.legacy import find_repo_root


class CoreLegacyEquivalenceTests(unittest.TestCase):
    def test_migrated_core_matches_stage1_baseline(self) -> None:
        root = find_repo_root(Path(__file__).resolve())
        sys.path.insert(0, str(root / "experiments"))
        try:
            import stage1_core as legacy
        finally:
            sys.path.pop(0)

        gate_specs = [
            ("h", (0,)),
            ("cx", (0, 4)),
            ("cx", (1, 3)),
            ("cx", (4, 2)),
            ("cx", (0, 3)),
        ]
        edges = [(0, 1), (1, 2), (2, 3), (3, 4)]
        mapping = [0, 1, 2, 3, 4]

        new_dag = CircuitDAG(
            5,
            [
                Gate(index, name, qubits)
                for index, (name, qubits) in enumerate(gate_specs)
            ],
        )
        new_hardware = HardwareGraph(5, edges)
        new_state = run_shortest_path_baseline(
            new_dag,
            new_hardware,
            mapping,
        )

        old_dag = legacy.CircuitDAG(
            5,
            [
                legacy.Gate(index, name, qubits)
                for index, (name, qubits) in enumerate(gate_specs)
            ],
        )
        old_hardware = legacy.HardwareGraph(5, edges)
        with contextlib.redirect_stdout(io.StringIO()):
            old_state = legacy.run_shortest_path_baseline(
                old_dag,
                old_hardware,
                mapping,
            )

        self.assertEqual(
            new_state.logical_to_physical,
            old_state.logical_to_physical,
        )
        self.assertEqual(
            new_state.physical_operations,
            old_state.physical_operations,
        )
        self.assertEqual(new_state.current_depth(), old_state.current_depth())


if __name__ == "__main__":
    unittest.main()

