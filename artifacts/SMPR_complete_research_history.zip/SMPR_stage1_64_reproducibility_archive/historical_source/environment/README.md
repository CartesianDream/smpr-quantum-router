# Environment records

`requirements-frozen.txt` at the repository root is the supported minimal
environment for the frozen routing pipeline.

`legacy/` contains the original UTF-16 `pip freeze` exports recovered from the
uploaded project.  They include unrelated cloud and KaiWu SDK packages and are
retained only as historical environment evidence; do not use them as the normal
installation entry point.

