from __future__ import annotations

from pathlib import Path
import copy
import sys

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

from stage1_core import RoutingState

EXPECTED_FIELDS = {
    "logical_to_physical",
    "physical_to_logical",
    "remaining_predecessors",
    "executed_gates",
    "physical_operations",
    "physical_depth",
}

_fields_checked = False


def fast_routing_state_deepcopy(
    self: RoutingState,
    memo: dict[int, object],
) -> RoutingState:
    global _fields_checked

    if not _fields_checked:
        actual_fields = set(vars(self))
        if actual_fields != EXPECTED_FIELDS:
            raise RuntimeError(
                "RoutingState fields changed: "
                f"expected={sorted(EXPECTED_FIELDS)}, "
                f"actual={sorted(actual_fields)}"
            )
        _fields_checked = True

    existing = memo.get(id(self))
    if existing is not None:
        return existing  # type: ignore[return-value]

    cloned = RoutingState(
        logical_to_physical=self.logical_to_physical.copy(),
        physical_to_logical=self.physical_to_logical.copy(),
        remaining_predecessors=self.remaining_predecessors.copy(),
        executed_gates=self.executed_gates.copy(),
        # 元素都是由 str/int/None 构成的不可变 tuple。
        physical_operations=self.physical_operations.copy(),
        physical_depth=self.physical_depth.copy(),
    )

    memo[id(self)] = cloned
    return cloned


# 所有现有 copy.deepcopy(state) 会自动使用此实现。
RoutingState.__deepcopy__ = fast_routing_state_deepcopy

import stage48_profile_frozen_router as profiler_runner


if __name__ == "__main__":
    profiler_runner.main()