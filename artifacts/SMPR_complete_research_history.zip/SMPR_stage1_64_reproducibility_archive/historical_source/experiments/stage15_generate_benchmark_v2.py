from __future__ import annotations

import argparse
import json
import random
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass
from pathlib import Path

from stage9_generate_benchmark import (
    CIRCUIT_MODES,
    QUBIT_SIZES,
    TOPOLOGIES,
    generate_gate_specs,
    make_topology,
)


# ============================================================
# 1. 数据结构
# ============================================================

LENGTH_FACTORS = (3, 6, 12)


@dataclass(frozen=True)
class Profile:
    profile_id: int
    topology: str
    circuit_mode: str
    length_factor: int
    num_qubits: int


@dataclass(frozen=True)
class BalancedCase:
    name: str
    split: str
    seed: int
    profile_id: int
    num_qubits: int
    topology: str
    circuit_mode: str
    length_factor: int
    two_qubit_gate_count: int
    edges: tuple[tuple[int, int], ...]
    gate_specs: tuple[tuple, ...]
    initial_mapping: tuple[int, ...]


# ============================================================
# 2. 60 个互不重复的结构档案
# ============================================================

def build_profiles(
    master_seed: int,
) -> list[Profile]:
    """
    使用完整的：

        4 种拓扑 × 5 种线路模式 × 3 种长度因子

    得到 60 个结构档案。

    量子比特数 6、8、10 按打乱后的顺序均衡分配，
    因此整个设计中每种规模恰好出现 20 次。
    """

    structures = [
        (
            topology,
            circuit_mode,
            length_factor,
        )
        for topology in TOPOLOGIES
        for circuit_mode in CIRCUIT_MODES
        for length_factor in LENGTH_FACTORS
    ]

    rng = random.Random(master_seed)
    rng.shuffle(structures)

    profiles: list[Profile] = []

    for profile_id, (
        topology,
        circuit_mode,
        length_factor,
    ) in enumerate(structures):
        num_qubits = QUBIT_SIZES[
            profile_id % len(QUBIT_SIZES)
        ]

        profiles.append(
            Profile(
                profile_id=profile_id,
                topology=topology,
                circuit_mode=circuit_mode,
                length_factor=length_factor,
                num_qubits=num_qubits,
            )
        )

    return profiles


# ============================================================
# 3. 贪心平衡划分
# ============================================================

ATTRIBUTES = (
    "topology",
    "circuit_mode",
    "length_factor",
    "num_qubits",
)


def target_counts(
    profiles: list[Profile],
    quotas: dict[str, int],
) -> dict[
    str,
    dict[str, dict[object, float]],
]:
    """
    计算每个 split 在各属性值上的理想数量。
    """

    total = len(profiles)

    global_counts: dict[
        str,
        Counter[object],
    ] = {}

    for attribute in ATTRIBUTES:
        global_counts[attribute] = Counter(
            getattr(profile, attribute)
            for profile in profiles
        )

    targets: dict[
        str,
        dict[str, dict[object, float]],
    ] = {}

    for split, quota in quotas.items():
        targets[split] = {}

        for attribute in ATTRIBUTES:
            targets[split][attribute] = {
                value: (
                    count * quota / total
                )
                for value, count
                in global_counts[attribute].items()
            }

    return targets


def allocation_penalty(
    split: str,
    profile: Profile,
    current_counts: dict[
        str,
        dict[str, Counter[object]],
    ],
    targets: dict[
        str,
        dict[str, dict[object, float]],
    ],
) -> float:
    """
    将 profile 放入 split 后的局部平方偏差。

    只评价该 profile 涉及的属性值，足以完成贪心平衡。
    """

    penalty = 0.0

    for attribute in ATTRIBUTES:
        value = getattr(profile, attribute)

        after = (
            current_counts[split][attribute][value]
            + 1
        )

        target = targets[split][attribute][value]

        penalty += (after - target) ** 2

    return penalty


def balanced_partition(
    profiles: list[Profile],
    quotas: dict[str, int],
    master_seed: int,
) -> dict[str, list[Profile]]:
    if sum(quotas.values()) > len(profiles):
        raise ValueError(
            "开发集、验证集和测试集数量之和不能超过 60"
        )

    rng = random.Random(master_seed + 17)
    ordered = list(profiles)
    rng.shuffle(ordered)

    targets = target_counts(
        profiles,
        quotas,
    )

    assignments: dict[
        str,
        list[Profile],
    ] = {
        split: []
        for split in quotas
    }

    counts: dict[
        str,
        dict[str, Counter[object]],
    ] = {
        split: {
            attribute: Counter()
            for attribute in ATTRIBUTES
        }
        for split in quotas
    }

    remaining = dict(quotas)

    for profile in ordered:
        available = [
            split
            for split, count in remaining.items()
            if count > 0
        ]

        if not available:
            break

        split = min(
            available,
            key=lambda candidate_split: (
                allocation_penalty(
                    candidate_split,
                    profile,
                    counts,
                    targets,
                ),
                -remaining[candidate_split],
                candidate_split,
            ),
        )

        assignments[split].append(profile)
        remaining[split] -= 1

        for attribute in ATTRIBUTES:
            value = getattr(profile, attribute)
            counts[split][attribute][value] += 1

    if any(value != 0 for value in remaining.values()):
        raise RuntimeError(
            f"划分未完成，剩余额度：{remaining}"
        )

    for split in assignments:
        assignments[split].sort(
            key=lambda profile: profile.profile_id
        )

    return assignments


# ============================================================
# 4. 生成具体线路
# ============================================================

SPLIT_CODE = {
    "dev": 1,
    "validation": 2,
    "test": 3,
}


def build_case(
    split: str,
    index: int,
    profile: Profile,
    master_seed: int,
) -> BalancedCase:
    case_seed = (
        master_seed
        + 100_000 * SPLIT_CODE[split]
        + 1009 * profile.profile_id
    )

    rng = random.Random(case_seed)

    edges = make_topology(
        topology=profile.topology,
        n=profile.num_qubits,
        rng=rng,
    )

    two_qubit_gate_count = (
        profile.length_factor
        * profile.num_qubits
    )

    gate_specs = generate_gate_specs(
        n=profile.num_qubits,
        num_two_qubit_gates=(
            two_qubit_gate_count
        ),
        circuit_mode=profile.circuit_mode,
        edges=edges,
        rng=rng,
    )

    case = BalancedCase(
        name=(
            f"{split}_v2_{index:03d}_"
            f"{profile.topology}_"
            f"n{profile.num_qubits}_"
            f"{profile.circuit_mode}_"
            f"f{profile.length_factor}_"
            f"cx{two_qubit_gate_count}"
        ),
        split=split,
        seed=case_seed,
        profile_id=profile.profile_id,
        num_qubits=profile.num_qubits,
        topology=profile.topology,
        circuit_mode=profile.circuit_mode,
        length_factor=profile.length_factor,
        two_qubit_gate_count=(
            two_qubit_gate_count
        ),
        edges=edges,
        gate_specs=gate_specs,
        initial_mapping=tuple(
            range(profile.num_qubits)
        ),
    )

    validate_case(case)
    return case


def validate_case(
    case: BalancedCase,
) -> None:
    if len(case.initial_mapping) != case.num_qubits:
        raise ValueError(
            f"{case.name} 初始映射长度错误"
        )

    if set(case.initial_mapping) != set(
        range(case.num_qubits)
    ):
        raise ValueError(
            f"{case.name} 初始映射不是排列"
        )

    counted_cx = sum(
        gate[0] == "cx"
        for gate in case.gate_specs
    )

    if counted_cx != case.two_qubit_gate_count:
        raise ValueError(
            f"{case.name} 的 CX 数量不一致："
            f"{counted_cx} != "
            f"{case.two_qubit_gate_count}"
        )

    expected = (
        case.length_factor
        * case.num_qubits
    )

    if counted_cx != expected:
        raise ValueError(
            f"{case.name} 未满足 CX=factor*n"
        )

    vertices = set(range(case.num_qubits))

    for u, v in case.edges:
        if (
            u not in vertices
            or v not in vertices
            or u == v
        ):
            raise ValueError(
                f"{case.name} 存在非法边 {(u, v)}"
            )


# ============================================================
# 5. 保存
# ============================================================

def case_to_dict(
    case: BalancedCase,
) -> dict:
    data = asdict(case)

    data["edges"] = [
        list(edge)
        for edge in case.edges
    ]

    data["gate_specs"] = [
        list(gate)
        for gate in case.gate_specs
    ]

    data["initial_mapping"] = list(
        case.initial_mapping
    )

    return data


def save_cases(
    cases: list[BalancedCase],
    path: Path,
    master_seed: int,
) -> None:
    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    payload = {
        "schema_version": 2,
        "master_seed": master_seed,
        "case_count": len(cases),
        "design": {
            "topologies": list(TOPOLOGIES),
            "circuit_modes": list(
                CIRCUIT_MODES
            ),
            "length_factors": list(
                LENGTH_FACTORS
            ),
            "qubit_sizes": list(
                QUBIT_SIZES
            ),
            "two_qubit_gate_rule": (
                "two_qubit_gate_count = "
                "length_factor * num_qubits"
            ),
        },
        "cases": [
            case_to_dict(case)
            for case in cases
        ],
    }

    path.write_text(
        json.dumps(
            payload,
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )


def save_manifest(
    assignments: dict[str, list[Profile]],
    output_dir: Path,
    master_seed: int,
) -> None:
    payload = {
        "schema_version": 2,
        "master_seed": master_seed,
        "splits": {
            split: [
                asdict(profile)
                for profile in profiles
            ]
            for split, profiles
            in assignments.items()
        },
    }

    (output_dir / "manifest.json").write_text(
        json.dumps(
            payload,
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )


# ============================================================
# 6. 汇总
# ============================================================

def print_distribution(
    split: str,
    cases: list[BalancedCase],
) -> None:
    print()
    print(f"[{split}] 实例数：{len(cases)}")

    for attribute, title in (
        ("topology", "拓扑"),
        ("circuit_mode", "线路模式"),
        ("length_factor", "长度因子"),
        ("num_qubits", "量子比特数"),
        (
            "two_qubit_gate_count",
            "CX 数量",
        ),
    ):
        counter = Counter(
            getattr(case, attribute)
            for case in cases
        )

        print(
            f"  {title}："
            f"{dict(sorted(counter.items(), key=lambda x: str(x[0])))}"
        )


def print_summary(
    split_cases: dict[
        str,
        list[BalancedCase],
    ],
) -> None:
    print()
    print("=" * 88)
    print("Benchmark V2 数据集汇总")
    print("=" * 88)

    for split in (
        "dev",
        "validation",
        "test",
    ):
        print_distribution(
            split,
            split_cases[split],
        )

    all_cases = [
        case
        for cases in split_cases.values()
        for case in cases
    ]

    profile_ids = [
        case.profile_id
        for case in all_cases
    ]

    print()
    print(
        "不同 profile 数：",
        len(set(profile_ids)),
        "/",
        len(profile_ids),
    )

    if len(set(profile_ids)) != len(profile_ids):
        raise RuntimeError(
            "不同数据划分之间出现了重复 profile"
        )

    print()
    print("前 6 个实例：")

    for case in all_cases[:6]:
        print(
            f"  {case.name}: "
            f"n={case.num_qubits}, "
            f"CX={case.two_qubit_gate_count}, "
            f"factor={case.length_factor}"
        )


# ============================================================
# 7. 主程序
# ============================================================

def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Stage 15：生成长度均衡、划分互斥的 "
            "Benchmark V2。"
        )
    )

    parser.add_argument(
        "--master-seed",
        type=int,
        default=20260716,
    )

    parser.add_argument(
        "--dev-count",
        type=int,
        default=30,
    )

    parser.add_argument(
        "--validation-count",
        type=int,
        default=15,
    )

    parser.add_argument(
        "--test-count",
        type=int,
        default=15,
    )

    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path(
            "data/benchmarks_v2"
        ),
    )

    args = parser.parse_args()

    quotas = {
        "dev": args.dev_count,
        "validation": (
            args.validation_count
        ),
        "test": args.test_count,
    }

    if min(quotas.values()) <= 0:
        raise ValueError(
            "三个数据划分的数量必须都是正整数"
        )

    if sum(quotas.values()) > 60:
        raise ValueError(
            "当前完整结构设计只有 60 个互斥 profile；"
            "三个划分之和不能超过 60"
        )

    profiles = build_profiles(
        args.master_seed
    )

    assignments = balanced_partition(
        profiles=profiles,
        quotas=quotas,
        master_seed=args.master_seed,
    )

    split_cases: dict[
        str,
        list[BalancedCase],
    ] = {}

    for split, split_profiles in (
        assignments.items()
    ):
        split_cases[split] = [
            build_case(
                split=split,
                index=index,
                profile=profile,
                master_seed=args.master_seed,
            )
            for index, profile in enumerate(
                split_profiles
            )
        ]

        save_cases(
            split_cases[split],
            args.output_dir / f"{split}.json",
            args.master_seed,
        )

    save_manifest(
        assignments=assignments,
        output_dir=args.output_dir,
        master_seed=args.master_seed,
    )

    print("生成完成：")

    for split in (
        "dev",
        "validation",
        "test",
    ):
        print(
            "  ",
            (
                args.output_dir
                / f"{split}.json"
            ).resolve(),
        )

    print(
        "  ",
        (
            args.output_dir
            / "manifest.json"
        ).resolve(),
    )

    print_summary(split_cases)


if __name__ == "__main__":
    main()
