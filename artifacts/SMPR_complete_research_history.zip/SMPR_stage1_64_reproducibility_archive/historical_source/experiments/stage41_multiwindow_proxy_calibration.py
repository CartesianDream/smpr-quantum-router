from __future__ import annotations

import argparse
import csv
import json
import math
import statistics
import time
from dataclasses import asdict, dataclass, replace
from pathlib import Path

import stage20_score_structure_ablation as stage20
import stage21_policy_portfolio as stage21
import stage33_large_topology_probe as stage33
import stage36_policy_aware_fb_layout as stage36
import stage37_proxy_local_layout_refinement as stage37
import stage39_layout_router_cross_decomposition as stage39

from stage7_initial_mapping_pool import MappingCandidate
from stage10_dev_benchmark import DevCase, load_cases


@dataclass
class CalibrationRow:
    instance: str
    mapping_name: str
    mutation: str
    mapping: str
    is_baseline: bool
    window_swaps: str
    window_depths: str
    window_swap_sum: int | None
    window_depth_sum: int | None
    proxy_runtime_ms: float
    proxy_valid: bool
    proxy_error: str
    proxy_rank: int | None
    selected_for_full_route: bool
    full_result_source: str
    full_swap: int | None
    full_depth: int | None
    full_runtime_ms: float
    full_valid: bool
    full_error: str


@dataclass
class CaseResult:
    instance: str
    topology: str
    circuit_mode: str
    logical_qubits: int
    physical_qubits: int
    cx_count: int
    policy: str
    window_count: int
    window_fraction: float
    window_gate_count: int
    window_starts: str
    candidates: int
    full_top: int
    reused_full_results: int
    new_full_routes: int

    stage37_swap: int
    stage37_depth: int
    stage41_mapping: str
    stage41_mutation: str
    stage41_swap: int
    stage41_depth: int
    improvement: int

    calibrated_pairs: int
    pearson_proxy_vs_full: float | None
    spearman_proxy_vs_full: float | None
    proxy_budget_ms: float
    new_full_budget_ms: float
    total_budget_ms: float

    lightsabre_swap: int
    lightsabre_depth: int
    swap_gap: int
    depth_gap: int
    outcome: str


def read_csv(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        raise FileNotFoundError(f"找不到文件：{path.resolve()}")
    with path.open("r", encoding="utf-8-sig", newline="") as file:
        return list(csv.DictReader(file))


def save_csv(path: Path, rows: list, fields) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=fields)
        writer.writeheader()
        writer.writerows(asdict(row) for row in rows)


def slice_case(
    case: DevCase,
    start: int,
    count: int,
    index: int,
) -> DevCase:
    gates = tuple(case.test_case.gate_specs[start : start + count])
    return DevCase(
        test_case=replace(
            case.test_case,
            name=f"{case.name}_window{index}_s{start}_n{count}",
            gate_specs=gates,
        ),
        split=case.split,
        topology=case.topology,
        circuit_mode=case.circuit_mode,
        source_seed=case.source_seed,
    )


def make_windows(
    case: DevCase,
    count: int,
    fraction: float,
) -> tuple[list[DevCase], list[int], int]:
    total = len(case.test_case.gate_specs)
    window_size = max(1, min(total, math.ceil(total * fraction)))
    if count == 1:
        starts = [0]
    else:
        starts = [
            round(index * (total - window_size) / (count - 1))
            for index in range(count)
        ]
    windows = [
        slice_case(case, start, window_size, index)
        for index, start in enumerate(starts)
    ]
    return windows, starts, window_size


def average_ranks(values: list[float]) -> list[float]:
    order = sorted(range(len(values)), key=lambda index: (values[index], index))
    ranks = [0.0] * len(values)
    position = 0
    while position < len(order):
        end = position + 1
        while end < len(order) and values[order[end]] == values[order[position]]:
            end += 1
        rank = 0.5 * ((position + 1) + end)
        for cursor in range(position, end):
            ranks[order[cursor]] = rank
        position = end
    return ranks


def pearson(left: list[float], right: list[float]) -> float | None:
    if len(left) < 2:
        return None
    left_mean = statistics.fmean(left)
    right_mean = statistics.fmean(right)
    numerator = sum(
        (x - left_mean) * (y - right_mean) for x, y in zip(left, right)
    )
    left_norm = math.sqrt(sum((x - left_mean) ** 2 for x in left))
    right_norm = math.sqrt(sum((y - right_mean) ** 2 for y in right))
    if left_norm == 0.0 or right_norm == 0.0:
        return None
    return numerator / (left_norm * right_norm)


def correlation(rows: list[CalibrationRow]) -> tuple[int, float | None, float | None]:
    paired = [
        row for row in rows
        if row.proxy_valid
        and row.window_swap_sum is not None
        and row.full_valid
        and row.full_swap is not None
    ]
    proxy = [float(row.window_swap_sum) for row in paired]
    full = [float(row.full_swap) for row in paired]
    return (
        len(paired),
        pearson(proxy, full),
        pearson(average_ranks(proxy), average_ranks(full)),
    )


def outcome_text(ours: tuple[int, int], qiskit: tuple[int, int]) -> str:
    if ours < qiskit:
        return "OAABR胜"
    if ours == qiskit:
        return "平局"
    return "LightSABRE胜"


def summarize(rows: list[CaseResult]) -> dict:
    old = sum(row.stage37_swap for row in rows)
    calibrated = sum(row.stage41_swap for row in rows)
    lightsabre = sum(row.lightsabre_swap for row in rows)
    return {
        "case_count": len(rows),
        "stage37_swap": old,
        "stage41_swap": calibrated,
        "improvement": old - calibrated,
        "lightsabre_swap": lightsabre,
        "swap_gap": calibrated - lightsabre,
        "proxy_budget_ms": sum(row.proxy_budget_ms for row in rows),
        "new_full_budget_ms": sum(row.new_full_budget_ms for row in rows),
        "total_budget_ms": sum(row.total_budget_ms for row in rows),
        "case_correlations": {
            row.instance: {
                "pairs": row.calibrated_pairs,
                "pearson": row.pearson_proxy_vs_full,
                "spearman": row.spearman_proxy_vs_full,
            }
            for row in rows
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Stage 41：多时间窗口路由代理校准"
    )
    parser.add_argument(
        "--input", type=Path, default=Path("data/benchmarks_large_v1/probe.json")
    )
    parser.add_argument("--case-indices", type=str, default="7")
    parser.add_argument(
        "--stage36-cases", type=Path,
        default=Path("results/stage38_alternating_stage36_cases.csv"),
    )
    parser.add_argument(
        "--stage36-polish", type=Path,
        default=Path("results/stage38_alternating_polish.csv"),
    )
    parser.add_argument(
        "--stage37-cases", type=Path,
        default=Path("results/stage38_alternating_stage37_cases.csv"),
    )
    parser.add_argument(
        "--stage37-candidates", type=Path,
        default=Path("results/stage38_alternating_candidates.csv"),
    )
    parser.add_argument(
        "--stage40-probes", type=Path,
        default=Path("results/stage40_heron_probes.csv"),
    )
    parser.add_argument("--anchor-trials", type=int, default=4)
    parser.add_argument("--policy", type=str, default="front_sum")
    parser.add_argument("--window-count", type=int, default=4)
    parser.add_argument("--window-fraction", type=float, default=0.125)
    parser.add_argument("--full-top", type=int, default=8)
    parser.add_argument(
        "--calibration-output", type=Path,
        default=Path("results/stage41_calibration.csv"),
    )
    parser.add_argument(
        "--case-output", type=Path,
        default=Path("results/stage41_cases.csv"),
    )
    parser.add_argument(
        "--summary-output", type=Path,
        default=Path("results/stage41_summary.json"),
    )
    args = parser.parse_args()
    if args.window_count <= 0 or args.full_top <= 0 or args.anchor_trials <= 0:
        raise ValueError("window-count、full-top、anchor-trials必须为正")
    if not 0.0 < args.window_fraction <= 0.25:
        raise ValueError("window-fraction必须在(0, 0.25]内")
    if args.policy not in stage20.CONFIG_BY_NAME:
        raise ValueError(f"未知policy：{args.policy}")

    stage33.configure_router()
    config = stage20.CONFIG_BY_NAME[args.policy]
    cases = stage21.choose_cases(
        load_cases(args.input, limit=None),
        stage21.parse_indices(args.case_indices),
        None,
    )
    stage36_rows = {row["instance"]: row for row in read_csv(args.stage36_cases)}
    polish_rows = read_csv(args.stage36_polish)
    stage37_rows = {row["instance"]: row for row in read_csv(args.stage37_cases)}
    stage37_candidates = {
        (row["instance"], row["mapping_name"]): row
        for row in read_csv(args.stage37_candidates)
    }
    stage40_rows = [row for row in read_csv(args.stage40_probes)]

    print("===== Stage 41：多时间窗口代理校准 =====")
    print(f"输入：{args.input.resolve()}")
    print(f"实例数：{len(cases)}")
    print(
        f"窗口：count={args.window_count}, fraction={args.window_fraction}; "
        f"完整路由 top={args.full_top}; policy={config.name}"
    )
    print("复用Stage 40已有完整结果；Stage 37基线始终保留。")

    all_rows: list[CalibrationRow] = []
    case_results: list[CaseResult] = []
    for case_index, case in enumerate(cases, start=1):
        print(f"[{case_index}/{len(cases)}] {case.name} ...", flush=True)
        if case.name not in stage37_rows:
            raise ValueError(f"Stage 37 cases CSV缺少 {case.name}")
        reference = stage37_rows[case.name]
        baseline_mapping = stage39.recover_ours_mapping(
            case=case,
            stage37_row=reference,
            candidate_rows=stage37_candidates,
            stage36_rows=stage36_rows,
            polish_rows=polish_rows,
            anchor_trials=args.anchor_trials,
        )
        old_probe_rows = [row for row in stage40_rows if row["instance"] == case.name]
        if not old_probe_rows:
            raise ValueError(f"Stage 40 probes CSV缺少 {case.name}")

        known_full: dict[tuple[int, ...], dict[str, str]] = {}
        candidate_source: dict[tuple[int, ...], tuple[str, str]] = {}
        for old in old_probe_rows:
            mapping = stage37.parse_mapping(old["mapping"])
            candidate_source[mapping] = (old["mapping_name"], old["mutation"])
            if old.get("full_swap") not in (None, ""):
                known_full[mapping] = old
        candidate_source[baseline_mapping] = (
            reference["selected_mapping"], "stage37_baseline"
        )

        windows, starts, window_size = make_windows(
            case, args.window_count, args.window_fraction
        )
        rows: list[CalibrationRow] = []
        proxy_budget = 0.0
        for mapping, (mapping_name, mutation) in candidate_source.items():
            start_time = time.perf_counter()
            swaps: list[int] = []
            depths: list[int] = []
            error_text = ""
            try:
                for window in windows:
                    _end, swap, depth, _runtime = stage36.route_endpoint(
                        window, mapping, config
                    )
                    swaps.append(swap)
                    depths.append(depth)
            except Exception as error:
                error_text = f"{type(error).__name__}: {error}"
            elapsed = (time.perf_counter() - start_time) * 1000.0
            proxy_budget += elapsed

            known = known_full.get(mapping)
            is_baseline = mapping == baseline_mapping
            if is_baseline:
                full_source = "stage37_baseline"
                full_swap = int(reference["refined_swap"])
                full_depth = int(reference["refined_depth"])
                full_valid = True
            elif known is not None:
                full_source = "reused_stage40"
                full_swap = int(known["full_swap"])
                full_depth = int(known["full_depth"])
                full_valid = known.get("valid") == "True"
            else:
                full_source = "not_scored"
                full_swap = None
                full_depth = None
                full_valid = False

            rows.append(
                CalibrationRow(
                    instance=case.name,
                    mapping_name=mapping_name,
                    mutation=mutation,
                    mapping=stage37.mapping_text(mapping),
                    is_baseline=is_baseline,
                    window_swaps=",".join(str(value) for value in swaps),
                    window_depths=",".join(str(value) for value in depths),
                    window_swap_sum=sum(swaps) if not error_text else None,
                    window_depth_sum=sum(depths) if not error_text else None,
                    proxy_runtime_ms=elapsed,
                    proxy_valid=not error_text,
                    proxy_error=error_text,
                    proxy_rank=None,
                    selected_for_full_route=False,
                    full_result_source=full_source,
                    full_swap=full_swap,
                    full_depth=full_depth,
                    full_runtime_ms=0.0,
                    full_valid=full_valid,
                    full_error="",
                )
            )

        valid_proxy = [row for row in rows if row.proxy_valid]
        ranked = sorted(
            valid_proxy,
            key=lambda row: (
                int(row.window_swap_sum),
                int(row.window_depth_sum),
                row.mutation,
                row.mapping,
            ),
        )
        for rank, row in enumerate(ranked, start=1):
            row.proxy_rank = rank

        selected = [row for row in ranked if not row.is_baseline][: args.full_top]
        new_full_budget = 0.0
        new_full_routes = 0
        reused = 0
        for row in selected:
            row.selected_for_full_route = True
            if row.full_result_source == "reused_stage40":
                reused += 1
                continue
            mapping = stage37.parse_mapping(row.mapping)
            candidate = MappingCandidate(row.mapping_name, mapping, 0.0)
            attempt = stage33.run_attempt(case, candidate, 0.0, config)
            row.full_runtime_ms = attempt.runtime_ms
            new_full_budget += attempt.runtime_ms
            new_full_routes += 1
            row.full_result_source = "stage41_new"
            row.full_valid = attempt.valid
            row.full_error = attempt.error
            if attempt.valid:
                row.full_swap = int(attempt.swap)
                row.full_depth = int(attempt.depth)

        valid_full = [row for row in rows if row.full_valid and row.full_swap is not None]
        best = min(
            valid_full,
            key=lambda row: (
                int(row.full_swap),
                int(row.full_depth),
                row.mapping_name,
            ),
        )
        pairs, pearson_value, spearman_value = correlation(rows)
        lightsabre = (
            int(reference["lightsabre_swap"]),
            int(reference["lightsabre_depth"]),
        )
        ours = (int(best.full_swap), int(best.full_depth))
        result = CaseResult(
            instance=case.name,
            topology=case.topology,
            circuit_mode=case.circuit_mode,
            logical_qubits=case.num_qubits,
            physical_qubits=case.test_case.num_physical_qubits,
            cx_count=case.two_qubit_gate_count,
            policy=config.name,
            window_count=args.window_count,
            window_fraction=args.window_fraction,
            window_gate_count=window_size,
            window_starts=",".join(str(value) for value in starts),
            candidates=len(rows),
            full_top=args.full_top,
            reused_full_results=reused,
            new_full_routes=new_full_routes,
            stage37_swap=int(reference["refined_swap"]),
            stage37_depth=int(reference["refined_depth"]),
            stage41_mapping=best.mapping_name,
            stage41_mutation=best.mutation,
            stage41_swap=ours[0],
            stage41_depth=ours[1],
            improvement=int(reference["refined_swap"]) - ours[0],
            calibrated_pairs=pairs,
            pearson_proxy_vs_full=pearson_value,
            spearman_proxy_vs_full=spearman_value,
            proxy_budget_ms=proxy_budget,
            new_full_budget_ms=new_full_budget,
            total_budget_ms=proxy_budget + new_full_budget,
            lightsabre_swap=lightsabre[0],
            lightsabre_depth=lightsabre[1],
            swap_gap=ours[0] - lightsabre[0],
            depth_gap=ours[1] - lightsabre[1],
            outcome=outcome_text(ours, lightsabre),
        )
        case_results.append(result)
        all_rows.extend(rows)
        print(
            f"  windows starts={result.window_starts}, gates={window_size}; "
            f"reused/new={reused}/{new_full_routes}"
        )
        print(
            f"  correlation pairs={pairs}, pearson={pearson_value}, "
            f"spearman={spearman_value}"
        )
        print(
            f"  Stage37={result.stage37_swap}/{result.stage37_depth}, "
            f"Stage41={result.stage41_swap}/{result.stage41_depth} "
            f"({result.stage41_mutation}), DeltaSWAP=-{result.improvement}"
        )
        print(
            f"  LightSABRE={result.lightsabre_swap}/{result.lightsabre_depth}, "
            f"gap={result.swap_gap:+d}, {result.outcome}, "
            f"budget={result.total_budget_ms:.1f} ms"
        )

        save_csv(
            args.calibration_output,
            all_rows,
            CalibrationRow.__annotations__.keys(),
        )
        save_csv(args.case_output, case_results, CaseResult.__annotations__.keys())
        args.summary_output.parent.mkdir(parents=True, exist_ok=True)
        args.summary_output.write_text(
            json.dumps(summarize(case_results), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    summary = summarize(case_results)
    print("\n===== Stage 41 汇总 =====")
    print(f"Stage 37 total SWAP：{summary['stage37_swap']}")
    print(f"Stage 41 total SWAP：{summary['stage41_swap']}")
    print(f"多窗口校准减少：{summary['improvement']}")
    print(f"LightSABRE total SWAP：{summary['lightsabre_swap']}")
    print(f"相对 LightSABRE gap：{summary['swap_gap']:+d}")
    print(
        f"预算 proxy/new-full/total：{summary['proxy_budget_ms']:.1f}/"
        f"{summary['new_full_budget_ms']:.1f}/{summary['total_budget_ms']:.1f} ms"
    )
    print(f"校准明细：{args.calibration_output.resolve()}")
    print(f"逐实例：{args.case_output.resolve()}")
    print(f"汇总：{args.summary_output.resolve()}")


if __name__ == "__main__":
    main()
