from __future__ import annotations

import argparse
import csv
import json
import random
import statistics
from collections import Counter
from pathlib import Path


def bootstrap_mean_ci(
    values: list[float],
    samples: int,
    seed: int,
) -> tuple[float, float]:
    rng = random.Random(seed)
    count = len(values)

    means = [
        statistics.mean(
            values[rng.randrange(count)]
            for _ in range(count)
        )
        for _ in range(samples)
    ]
    means.sort()

    lower = means[int(0.025 * samples)]
    upper = means[int(0.975 * samples)]
    return lower, upper


def quality_key(
    swap: int,
    depth: int,
) -> tuple[int, int]:
    return swap, depth


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Stage 49: LightSABRE + accelerated OAABR "
            "safe dual-router portfolio"
        )
    )
    parser.add_argument(
        "--input",
        type=Path,
        default=Path(
            "results/stage48_rust_port/"
            "full_validation_skip_cases.csv"
        ),
    )
    parser.add_argument(
        "--case-output",
        type=Path,
        default=Path(
            "results/stage49_safe_dual/"
            "safe_dual_cases.csv"
        ),
    )
    parser.add_argument(
        "--summary-output",
        type=Path,
        default=Path(
            "results/stage49_safe_dual/"
            "safe_dual_summary.json"
        ),
    )
    parser.add_argument(
        "--bootstrap-samples",
        type=int,
        default=10000,
    )
    parser.add_argument(
        "--bootstrap-seed",
        type=int,
        default=20260717,
    )
    args = parser.parse_args()

    with args.input.open(
        "r",
        encoding="utf-8-sig",
        newline="",
    ) as handle:
        source_rows = list(csv.DictReader(handle))

    output_rows: list[dict[str, object]] = []
    backend_counts: Counter[str] = Counter()

    for row in source_rows:
        oaabr_swap = int(row["router_swap"])
        oaabr_depth = int(row["router_depth"])
        ls_swap = int(row["lightsabre_swap"])
        ls_depth = int(row["lightsabre_depth"])

        oaabr_runtime = float(row["router_runtime_ms"])
        ls_runtime = float(row["lightsabre_budget_ms"])

        oaabr_key = quality_key(
            oaabr_swap,
            oaabr_depth,
        )
        ls_key = quality_key(
            ls_swap,
            ls_depth,
        )

        if oaabr_key < ls_key:
            selected_backend = "oaabr"
            selected_swap = oaabr_swap
            selected_depth = oaabr_depth
        else:
            # 质量完全相同时选择运行更快的 LightSABRE。
            selected_backend = "lightsabre"
            selected_swap = ls_swap
            selected_depth = ls_depth

        backend_counts[selected_backend] += 1

        if selected_swap < ls_swap:
            swap_outcome = "win"
        elif selected_swap == ls_swap:
            swap_outcome = "tie"
        else:
            swap_outcome = "loss"

        if (
            quality_key(selected_swap, selected_depth)
            < ls_key
        ):
            quality_outcome = "win"
        elif (
            quality_key(selected_swap, selected_depth)
            == ls_key
        ):
            quality_outcome = "tie"
        else:
            quality_outcome = "loss"

        cx_count = int(row["cx_count"])

        output_rows.append(
            {
                "instance": row["instance"],
                "topology": row["topology"],
                "circuit_mode": row["circuit_mode"],
                "num_qubits": int(row["num_qubits"]),
                "cx_count": cx_count,
                "oaabr_swap": oaabr_swap,
                "oaabr_depth": oaabr_depth,
                "lightsabre_swap": ls_swap,
                "lightsabre_depth": ls_depth,
                "selected_backend": selected_backend,
                "selected_swap": selected_swap,
                "selected_depth": selected_depth,
                "swap_gain_vs_lightsabre": (
                    ls_swap - selected_swap
                ),
                "depth_gain_vs_lightsabre": (
                    ls_depth - selected_depth
                ),
                "normalized_swap_gap": (
                    (selected_swap - ls_swap) / cx_count
                ),
                "swap_outcome": swap_outcome,
                "quality_outcome": quality_outcome,
                "oaabr_runtime_ms": oaabr_runtime,
                "lightsabre_runtime_ms": ls_runtime,
                "dual_sequential_ms": (
                    oaabr_runtime + ls_runtime
                ),
                "dual_parallel_ms": max(
                    oaabr_runtime,
                    ls_runtime,
                ),
            }
        )

    oaabr_total = sum(
        int(row["oaabr_swap"])
        for row in output_rows
    )
    ls_total = sum(
        int(row["lightsabre_swap"])
        for row in output_rows
    )
    selected_total = sum(
        int(row["selected_swap"])
        for row in output_rows
    )

    swap_outcomes = Counter(
        str(row["swap_outcome"])
        for row in output_rows
    )
    quality_outcomes = Counter(
        str(row["quality_outcome"])
        for row in output_rows
    )

    normalized_gaps = [
        float(row["normalized_swap_gap"])
        for row in output_rows
    ]

    ci_lower, ci_upper = bootstrap_mean_ci(
        normalized_gaps,
        args.bootstrap_samples,
        args.bootstrap_seed,
    )

    summary = {
        "cases": len(output_rows),
        "selection_rule": (
            "minimize (swap_count, depth); "
            "exact ties select LightSABRE"
        ),
        "oaabr_total_swap": oaabr_total,
        "lightsabre_total_swap": ls_total,
        "safe_dual_total_swap": selected_total,
        "gain_vs_lightsabre": (
            ls_total - selected_total
        ),
        "relative_change_vs_lightsabre_pct": (
            100.0
            * (selected_total - ls_total)
            / ls_total
        ),
        "backend_counts": dict(backend_counts),
        "swap_win_tie_loss_vs_lightsabre": {
            "win": swap_outcomes["win"],
            "tie": swap_outcomes["tie"],
            "loss": swap_outcomes["loss"],
        },
        "quality_win_tie_loss_vs_lightsabre": {
            "win": quality_outcomes["win"],
            "tie": quality_outcomes["tie"],
            "loss": quality_outcomes["loss"],
        },
        "mean_normalized_swap_gap": (
            statistics.mean(normalized_gaps)
        ),
        "bootstrap_95_ci": [
            ci_lower,
            ci_upper,
        ],
        "dual_sequential_runtime_ms": sum(
            float(row["dual_sequential_ms"])
            for row in output_rows
        ),
        "dual_parallel_runtime_ms": sum(
            float(row["dual_parallel_ms"])
            for row in output_rows
        ),
        "bootstrap_samples": args.bootstrap_samples,
        "bootstrap_seed": args.bootstrap_seed,
        "source": str(args.input.resolve()),
    }

    args.case_output.parent.mkdir(
        parents=True,
        exist_ok=True,
    )
    args.summary_output.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    with args.case_output.open(
        "w",
        encoding="utf-8",
        newline="",
    ) as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=list(output_rows[0]),
        )
        writer.writeheader()
        writer.writerows(output_rows)

    args.summary_output.write_text(
        json.dumps(
            summary,
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )

    print("===== Stage 49 safe dual-router =====")
    print("cases:", len(output_rows))
    print("OAABR total SWAP:", oaabr_total)
    print("LightSABRE total SWAP:", ls_total)
    print("Safe dual total SWAP:", selected_total)
    print(
        "gain vs LightSABRE:",
        ls_total - selected_total,
    )
    print(
        "relative change:",
        f"{summary['relative_change_vs_lightsabre_pct']:+.2f}%",
    )
    print(
        "selected backends:",
        dict(backend_counts),
    )
    print(
        "SWAP W/T/L:",
        f"{swap_outcomes['win']}/"
        f"{swap_outcomes['tie']}/"
        f"{swap_outcomes['loss']}",
    )
    print(
        "quality W/T/L:",
        f"{quality_outcomes['win']}/"
        f"{quality_outcomes['tie']}/"
        f"{quality_outcomes['loss']}",
    )
    print(
        "normalized gap CI:",
        f"[{ci_lower:+.5f}, {ci_upper:+.5f}]",
    )
    print(
        "dual sequential runtime ms:",
        round(summary["dual_sequential_runtime_ms"], 1),
    )
    print(
        "dual parallel runtime ms:",
        round(summary["dual_parallel_runtime_ms"], 1),
    )
    print("cases output:", args.case_output.resolve())
    print(
        "summary output:",
        args.summary_output.resolve(),
    )


if __name__ == "__main__":
    main()