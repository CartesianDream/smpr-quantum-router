from __future__ import annotations

from pathlib import Path
import argparse
import cProfile
import csv
import io
import pstats
import sys
import time

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

import stage32_frozen_final_benchmark as stage32
from stage10_dev_benchmark import load_cases


def load_lightsabre_reference(path: Path) -> dict[str, dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    return {row["instance"]: row for row in rows}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--input",
        type=Path,
        default=Path("data/benchmarks_v5/final_test.json"),
    )
    parser.add_argument(
        "--reference",
        type=Path,
        default=Path(
            "results/stage46_fresh/full_oaabr_vs_ls_cases.csv"
        ),
    )
    parser.add_argument("--case-index", type=int, required=True)
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("results/stage48_rust_port"),
    )
    parser.add_argument("--top", type=int, default=60)
    args = parser.parse_args()

    cases = load_cases(args.input, None)
    if not 0 <= args.case_index < len(cases):
        raise IndexError(
            f"case-index {args.case_index} outside 0..{len(cases)-1}"
        )

    case = cases[args.case_index]
    references = load_lightsabre_reference(args.reference)
    reference = references[case.name]

    config = stage32.configure_router()
    variant = stage32.frozen_variant(case)

    args.output_dir.mkdir(parents=True, exist_ok=True)
    stem = f"case_{args.case_index:03d}_{case.name}"
    stats_path = args.output_dir / f"{stem}.pstats"
    report_path = args.output_dir / f"{stem}_profile.txt"

    print("===== Stage 48 frozen-router profile =====")
    print("case-index:", args.case_index)
    print("case:", case.name)
    print("variant:", variant)
    print(
        "LightSABRE reference:",
        reference["lightsabre_swap"],
        reference["lightsabre_depth"],
    )

    profiler = cProfile.Profile()
    start = time.perf_counter()

    profiler.enable()
    outcome = stage32.run_frozen_router(
        case=case,
        config=config,
        lightsabre_swap=int(reference["lightsabre_swap"]),
        lightsabre_depth=int(reference["lightsabre_depth"]),
    )
    profiler.disable()

    wall_seconds = time.perf_counter() - start
    profiler.dump_stats(stats_path)

    report = io.StringIO()

    print("===== cumulative time =====", file=report)
    pstats.Stats(
        profiler,
        stream=report,
    ).strip_dirs().sort_stats(
        "cumulative"
    ).print_stats(args.top)

    print("\n===== internal/self time =====", file=report)
    pstats.Stats(
        profiler,
        stream=report,
    ).strip_dirs().sort_stats(
        "tottime"
    ).print_stats(args.top)

    report_text = report.getvalue()
    report_path.write_text(report_text, encoding="utf-8")

    print("\n===== Result =====")
    print("router swap/depth:", outcome.swap, outcome.depth)
    print("runtime reported ms:", outcome.runtime_ms)
    print("profile wall seconds:", round(wall_seconds, 3))
    print("mapping budget:", outcome.mapping_budget)
    print("selected mapping:", outcome.selected_mapping)
    print("candidates scored:", outcome.mapping_candidates_scored)
    print("rollout mappings:", outcome.rollout_mappings)
    print("pstats:", stats_path.resolve())
    print("report:", report_path.resolve())

    print("\n" + report_text)


if __name__ == "__main__":
    main()