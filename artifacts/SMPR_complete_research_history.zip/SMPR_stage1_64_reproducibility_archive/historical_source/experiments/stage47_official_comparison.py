from __future__ import annotations

from collections import Counter
from pathlib import Path
import csv
import hashlib
import json
import math
import random

ROOT = Path("results")
STAGE46 = ROOT / "stage46_fresh"
STAGE47 = ROOT / "stage47_official_rust"

OAABR_LS_PATH = STAGE46 / "full_oaabr_vs_ls_cases.csv"
THREEWAY_PATH = STAGE46 / "full_threeway_cases.csv"
OFFICIAL_FAST_PATH = STAGE47 / "v5_official_best_fast_cases.csv"
OFFICIAL_FULL_PATH = STAGE47 / "v5_official_best_full20x20_cases.csv"

CASE_OUTPUT = STAGE47 / "official_comparison_cases.csv"
TOTAL_OUTPUT = STAGE47 / "official_comparison_totals.csv"
PAIR_OUTPUT = STAGE47 / "official_comparison_pairs.csv"
GROUP_OUTPUT = STAGE47 / "official_comparison_groups.csv"
SUMMARY_OUTPUT = STAGE47 / "official_comparison_summary.json"

BOOTSTRAP_SAMPLES = 10_000
BOOTSTRAP_SEED = 20260717

CONFIGS = {
    "lightsabre": {
        "swap": "lightsabre_swap",
        "depth": "lightsabre_depth",
        "runtime": "lightsabre_runtime_ms",
    },
    "oaabr": {
        "swap": "oaabr_swap",
        "depth": "oaabr_depth",
        "runtime": "oaabr_runtime_ms",
    },
    "simpletes_official_full20x20": {
        "swap": "simpletes_official_full_swap",
        "depth": "simpletes_official_full_depth",
        "runtime": "simpletes_official_full_runtime_ms",
    },
    "simpletes_official_fast4x4": {
        "swap": "simpletes_official_fast_swap",
        "depth": "simpletes_official_fast_depth",
        "runtime": "simpletes_official_fast_runtime_ms",
    },
    "simpletes_python_port": {
        "swap": "simpletes_port_swap",
        "depth": "simpletes_port_depth",
        "runtime": "simpletes_port_runtime_ms",
    },
}

PRIMARY_CONFIGS = (
    "lightsabre",
    "oaabr",
    "simpletes_official_full20x20",
)

PAIR_SPECS = (
    ("oaabr", "lightsabre"),
    ("oaabr", "simpletes_official_full20x20"),
    ("simpletes_official_full20x20", "lightsabre"),
    ("simpletes_official_full20x20", "simpletes_python_port"),
    ("simpletes_official_full20x20", "simpletes_official_fast4x4"),
)

GROUP_DIMENSIONS = (
    "topology",
    "circuit_mode",
    "num_qubits",
    "length_factor",
)


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        raise RuntimeError(f"refusing to write empty CSV: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def as_int(value) -> int:
    return int(float(value))


def as_float(value) -> float:
    return float(value)


def by_key(rows: list[dict[str, str]], key: str) -> dict[str, dict[str, str]]:
    result = {}
    for row in rows:
        value = str(row[key])
        if value in result:
            raise RuntimeError(f"duplicate key {value!r}")
        result[value] = row
    return result


def percentile(sorted_values: list[float], probability: float) -> float:
    if not sorted_values:
        raise RuntimeError("percentile of empty list")
    position = (len(sorted_values) - 1) * probability
    lower = math.floor(position)
    upper = math.ceil(position)
    if lower == upper:
        return sorted_values[lower]
    weight = position - lower
    return (
        sorted_values[lower] * (1.0 - weight)
        + sorted_values[upper] * weight
    )


def pair_seed(a: str, b: str) -> int:
    digest = hashlib.sha256(
        f"{BOOTSTRAP_SEED}:{a}:{b}".encode("utf-8")
    ).digest()
    return int.from_bytes(digest[:8], "big")


def bootstrap_mean_ci(values: list[float], a: str, b: str) -> tuple[float, float]:
    rng = random.Random(pair_seed(a, b))
    n = len(values)
    sampled_means = []

    for _ in range(BOOTSTRAP_SAMPLES):
        total = 0.0
        for _ in range(n):
            total += values[rng.randrange(n)]
        sampled_means.append(total / n)

    sampled_means.sort()
    return (
        percentile(sampled_means, 0.025),
        percentile(sampled_means, 0.975),
    )


oaabr_rows = read_csv(OAABR_LS_PATH)
port_rows = read_csv(THREEWAY_PATH)
fast_rows = read_csv(OFFICIAL_FAST_PATH)
full_rows = read_csv(OFFICIAL_FULL_PATH)

if not all(len(rows) == 60 for rows in (
    oaabr_rows, port_rows, fast_rows, full_rows
)):
    raise RuntimeError(
        "all four input CSVs must contain exactly 60 rows"
    )

oaabr_by_id = by_key(oaabr_rows, "instance")
port_by_id = by_key(port_rows, "instance")
fast_by_id = by_key(fast_rows, "id")
full_by_id = by_key(full_rows, "id")

id_sets = [
    set(oaabr_by_id),
    set(port_by_id),
    set(fast_by_id),
    set(full_by_id),
]
if any(ids != id_sets[0] for ids in id_sets[1:]):
    raise RuntimeError("case ID sets do not match")

merged_cases = []

# Preserve the frozen benchmark order.
for reference in oaabr_rows:
    instance = reference["instance"]
    port = port_by_id[instance]
    fast = fast_by_id[instance]
    full = full_by_id[instance]

    if fast["ok"].strip().lower() != "true":
        raise RuntimeError(f"fast official result failed: {instance}")
    if full["ok"].strip().lower() != "true":
        raise RuntimeError(f"full official result failed: {instance}")

    # The Stage46 copy of OAABR/LightSABRE must match the frozen source.
    if as_int(port["oaabr_swap"]) != as_int(reference["router_swap"]):
        raise RuntimeError(f"OAABR mismatch: {instance}")
    if as_int(port["lightsabre_swap"]) != as_int(
        reference["lightsabre_swap"]
    ):
        raise RuntimeError(f"LightSABRE mismatch: {instance}")

    row = {
        "instance": instance,
        "topology": reference["topology"],
        "circuit_mode": reference["circuit_mode"],
        "num_qubits": as_int(reference["num_qubits"]),
        "length_factor": as_int(reference["length_factor"]),
        "cx_count": as_int(reference["cx_count"]),

        "lightsabre_swap": as_int(reference["lightsabre_swap"]),
        "lightsabre_depth": as_int(reference["lightsabre_depth"]),
        "lightsabre_runtime_ms": as_float(
            reference["lightsabre_budget_ms"]
        ),

        "oaabr_swap": as_int(reference["router_swap"]),
        "oaabr_depth": as_int(reference["router_depth"]),
        "oaabr_runtime_ms": as_float(
            reference["router_runtime_ms"]
        ),

        "simpletes_official_full_swap": as_int(full["swap_count"]),
        "simpletes_official_full_depth": as_int(full["depth"]),
        "simpletes_official_full_runtime_ms": as_float(full["time_ms"]),

        "simpletes_official_fast_swap": as_int(fast["swap_count"]),
        "simpletes_official_fast_depth": as_int(fast["depth"]),
        "simpletes_official_fast_runtime_ms": as_float(fast["time_ms"]),

        "simpletes_port_swap": as_int(port["simpletes_swap"]),
        "simpletes_port_depth": as_int(port["simpletes_depth"]),
        "simpletes_port_runtime_ms": as_float(
            port["simpletes_runtime_ms"]
        ),
    }

    row.update({
        "oaabr_minus_lightsabre":
            row["oaabr_swap"] - row["lightsabre_swap"],
        "official_full_minus_oaabr":
            row["simpletes_official_full_swap"] - row["oaabr_swap"],
        "official_full_minus_lightsabre":
            row["simpletes_official_full_swap"] - row["lightsabre_swap"],
        "port_minus_official_full":
            row["simpletes_port_swap"]
            - row["simpletes_official_full_swap"],
        "official_fast_minus_full":
            row["simpletes_official_fast_swap"]
            - row["simpletes_official_full_swap"],
    })

    primary_values = {
        config: row[CONFIGS[config]["swap"]]
        for config in PRIMARY_CONFIGS
    }
    best_swap = min(primary_values.values())
    winners = [
        config
        for config, value in primary_values.items()
        if value == best_swap
    ]
    row["primary_best_swap"] = best_swap
    row["primary_winners"] = "+".join(winners)

    merged_cases.append(row)

write_csv(CASE_OUTPUT, merged_cases)

totals = []
totals_by_config = {}

for config, fields in CONFIGS.items():
    total = {
        "config": config,
        "total_swap": sum(row[fields["swap"]] for row in merged_cases),
        "total_depth": sum(row[fields["depth"]] for row in merged_cases),
        "total_runtime_ms": round(
            sum(row[fields["runtime"]] for row in merged_cases),
            3,
        ),
    }
    totals.append(total)
    totals_by_config[config] = total

lightsabre_total = totals_by_config["lightsabre"]["total_swap"]
for total in totals:
    total["swap_gap_vs_lightsabre"] = (
        total["total_swap"] - lightsabre_total
    )
    total["relative_gap_vs_lightsabre"] = round(
        (total["total_swap"] - lightsabre_total)
        / lightsabre_total,
        8,
    )

write_csv(TOTAL_OUTPUT, totals)

pair_rows = []

for a, b in PAIR_SPECS:
    a_fields = CONFIGS[a]
    b_fields = CONFIGS[b]

    swap_differences = [
        row[a_fields["swap"]] - row[b_fields["swap"]]
        for row in merged_cases
    ]
    normalized_differences = [
        difference / row["cx_count"]
        for difference, row in zip(swap_differences, merged_cases)
    ]

    raw_wins = sum(value < 0 for value in swap_differences)
    raw_ties = sum(value == 0 for value in swap_differences)
    raw_losses = sum(value > 0 for value in swap_differences)

    lex_wins = lex_ties = lex_losses = 0
    for row in merged_cases:
        a_value = (row[a_fields["swap"]], row[a_fields["depth"]])
        b_value = (row[b_fields["swap"]], row[b_fields["depth"]])
        if a_value < b_value:
            lex_wins += 1
        elif a_value == b_value:
            lex_ties += 1
        else:
            lex_losses += 1

    ci_low, ci_high = bootstrap_mean_ci(
        normalized_differences, a, b
    )

    total_a = totals_by_config[a]["total_swap"]
    total_b = totals_by_config[b]["total_swap"]
    runtime_a = totals_by_config[a]["total_runtime_ms"]
    runtime_b = totals_by_config[b]["total_runtime_ms"]

    pair_rows.append({
        "a": a,
        "b": b,
        "total_swap_a": total_a,
        "total_swap_b": total_b,
        "total_gap_a_minus_b": total_a - total_b,
        "relative_total_gap": round(
            (total_a - total_b) / total_b, 8
        ),
        "raw_swap_wins_a": raw_wins,
        "raw_swap_ties": raw_ties,
        "raw_swap_losses_a": raw_losses,
        "lexicographic_wins_a": lex_wins,
        "lexicographic_ties": lex_ties,
        "lexicographic_losses_a": lex_losses,
        "mean_gap_over_cx": round(
            sum(normalized_differences)
            / len(normalized_differences),
            8,
        ),
        "bootstrap_ci_low": round(ci_low, 8),
        "bootstrap_ci_high": round(ci_high, 8),
        "bootstrap_samples": BOOTSTRAP_SAMPLES,
        "runtime_ms_a": runtime_a,
        "runtime_ms_b": runtime_b,
        "runtime_ratio_a_over_b": round(
            runtime_a / runtime_b, 8
        ) if runtime_b else None,
    })

write_csv(PAIR_OUTPUT, pair_rows)

group_rows = []

for dimension in GROUP_DIMENSIONS:
    values = sorted(
        {row[dimension] for row in merged_cases},
        key=lambda value: (str(type(value)), value),
    )

    for value in values:
        subset = [
            row for row in merged_cases
            if row[dimension] == value
        ]

        output = {
            "dimension": dimension,
            "group": value,
            "case_count": len(subset),
            "cx_count": sum(row["cx_count"] for row in subset),
        }

        for config, fields in CONFIGS.items():
            output[f"{config}_swap"] = sum(
                row[fields["swap"]] for row in subset
            )
            output[f"{config}_runtime_ms"] = round(
                sum(row[fields["runtime"]] for row in subset),
                3,
            )

        output["oaabr_minus_lightsabre"] = (
            output["oaabr_swap"] - output["lightsabre_swap"]
        )
        output["official_full_minus_oaabr"] = (
            output["simpletes_official_full20x20_swap"]
            - output["oaabr_swap"]
        )
        output["official_full_minus_lightsabre"] = (
            output["simpletes_official_full20x20_swap"]
            - output["lightsabre_swap"]
        )
        output["port_minus_official_full"] = (
            output["simpletes_python_port_swap"]
            - output["simpletes_official_full20x20_swap"]
        )

        group_rows.append(output)

write_csv(GROUP_OUTPUT, group_rows)

oracle_specs = {
    "lightsabre_or_oaabr": (
        "lightsabre", "oaabr",
    ),
    "lightsabre_or_official_full": (
        "lightsabre", "simpletes_official_full20x20",
    ),
    "oaabr_or_official_full": (
        "oaabr", "simpletes_official_full20x20",
    ),
    "primary_threeway": PRIMARY_CONFIGS,
}

oracles = {}
for name, configs in oracle_specs.items():
    oracles[name] = sum(
        min(row[CONFIGS[config]["swap"]] for config in configs)
        for row in merged_cases
    )

winner_patterns = Counter(
    row["primary_winners"] for row in merged_cases
)

summary = {
    "metadata": {
        "case_count": len(merged_cases),
        "bootstrap_samples": BOOTSTRAP_SAMPLES,
        "bootstrap_seed": BOOTSTRAP_SEED,
        "normalized_gap_definition": "(swap_a - swap_b) / cx_count",
        "simpletes_repository_commit":
            "b7e0367b5ab19554fb40859e8069e091bb8c4ca2",
        "simpletes_candidate_sha256":
            "A57442805C3132F57FBA4085434D10600CF3DAA35464F407693B7147AA360317",
        "official_fast_trials": "4x4",
        "official_full_trials": "20x20",
        "runtime_note": (
            "Runtime totals come from different implementations and "
            "instrumentation paths; treat them as practical wall-budget "
            "indicators, not microbenchmark-equivalent measurements."
        ),
    },
    "totals": totals,
    "pairs": pair_rows,
    "oracles": oracles,
    "primary_winner_patterns": dict(sorted(winner_patterns.items())),
    "outputs": {
        "cases": str(CASE_OUTPUT),
        "totals": str(TOTAL_OUTPUT),
        "pairs": str(PAIR_OUTPUT),
        "groups": str(GROUP_OUTPUT),
        "summary": str(SUMMARY_OUTPUT),
    },
}

SUMMARY_OUTPUT.write_text(
    json.dumps(summary, indent=2, ensure_ascii=False) + "\n",
    encoding="utf-8",
)

print("===== Stage 47 official comparison =====")
print("\nTotals:")
for total in totals:
    print(
        f"  {total['config']:<34} "
        f"SWAP={total['total_swap']:>5}  "
        f"depth={total['total_depth']:>5}  "
        f"runtime={total['total_runtime_ms']:>10.1f} ms"
    )

print("\nSelected paired comparisons:")
for pair in pair_rows:
    print(
        f"  {pair['a']} vs {pair['b']}: "
        f"gap={pair['total_gap_a_minus_b']:+d}, "
        f"raw W/T/L="
        f"{pair['raw_swap_wins_a']}/"
        f"{pair['raw_swap_ties']}/"
        f"{pair['raw_swap_losses_a']}, "
        f"mean gap/CX={pair['mean_gap_over_cx']:+.5f}, "
        f"CI=[{pair['bootstrap_ci_low']:+.5f}, "
        f"{pair['bootstrap_ci_high']:+.5f}]"
    )

print("\nOracle totals:")
for name, value in oracles.items():
    print(f"  {name:<32} {value}")

print("\nPrimary winner patterns:")
for pattern, count in sorted(winner_patterns.items()):
    print(f"  {pattern:<55} {count}")

print("\nOutputs:")
for path in (
    CASE_OUTPUT,
    TOTAL_OUTPUT,
    PAIR_OUTPUT,
    GROUP_OUTPUT,
    SUMMARY_OUTPUT,
):
    print(f"  {path.resolve()}")