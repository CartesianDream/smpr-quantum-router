from __future__ import annotations

import argparse
import csv
import io
import time
from collections import Counter, defaultdict
from contextlib import redirect_stdout
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from stage1_core import CircuitDAG, HardwareGraph, RoutingState
from stage2_one_step import run_one_step_router
from stage3_two_step_beam import run_two_step_beam_router
from stage4_adaptive_beam import run_adaptive_router
from stage5_recent_repair import run_router_with_repair
from stage7_initial_mapping_pool import (
    MappingCandidate,
    generate_base_mapping_pool,
)
from stage10_dev_benchmark import DevCase, load_cases


# ============================================================
# 1. 路由器定义
# ============================================================

Router = Callable[
    [CircuitDAG, HardwareGraph, list[int]],
    RoutingState,
]


def adaptive_repair_runner(
    dag: CircuitDAG,
    hardware: HardwareGraph,
    initial_mapping: list[int],
) -> RoutingState:
    return run_router_with_repair(
        dag=dag,
        hardware=hardware,
        initial_mapping=initial_mapping,
        repair_threshold=8,
    )


ROUTERS: tuple[tuple[str, Router], ...] = (
    ("OneStepPotential", run_one_step_router),
    ("TwoStepBeam", run_two_step_beam_router),
    ("AdaptiveBeam", run_adaptive_router),
    ("AdaptiveBeamRepair", adaptive_repair_runner),
)


# ============================================================
# 2. 数据结构
# ============================================================

@dataclass
class CandidateResult:
    instance: str
    circuit_mode: str
    topology: str
    algorithm: str
    mapping_name: str
    swap_count: int | None
    added_two_qubit_count: int | None
    weighted_depth: int | None
    routing_ms: float
    valid: bool
    error: str

    @property
    def score(self) -> tuple[int, int]:
        if (
            self.added_two_qubit_count is None
            or self.weighted_depth is None
        ):
            return 10**9, 10**9

        return (
            self.added_two_qubit_count,
            self.weighted_depth,
        )


@dataclass
class AblationSummary:
    instance: str
    circuit_mode: str
    topology: str
    num_qubits: int
    algorithm: str
    best_mapping: str
    swap_count: int
    added_two_qubit_count: int
    weighted_depth: int
    pool_budget_ms: float
    qiskit_swap: int
    qiskit_added_two_qubit_count: int
    qiskit_depth: int
    outcome: str


# ============================================================
# 3. 工具函数
# ============================================================

def count_swaps(
    state: RoutingState,
) -> int:
    return sum(
        operation[0] == "swap"
        for operation in state.physical_operations
    )


def run_candidate(
    case: DevCase,
    candidate: MappingCandidate,
    algorithm_name: str,
    runner: Router,
    verbose: bool,
) -> CandidateResult:
    dag, hardware, _ = case.test_case.build()

    output_buffer = io.StringIO()
    start = time.perf_counter()

    try:
        if verbose:
            state = runner(
                dag,
                hardware,
                list(candidate.mapping),
            )
        else:
            with redirect_stdout(output_buffer):
                state = runner(
                    dag,
                    hardware,
                    list(candidate.mapping),
                )

        runtime_ms = (
            time.perf_counter() - start
        ) * 1000.0

        state.assert_valid(
            dag=dag,
            hardware=hardware,
        )

        if len(state.executed_gates) != len(dag.gates):
            raise AssertionError(
                "路由结束后仍有逻辑门未执行"
            )

        swap_count = count_swaps(state)

        return CandidateResult(
            instance=case.name,
            circuit_mode=case.circuit_mode,
            topology=case.topology,
            algorithm=algorithm_name,
            mapping_name=candidate.name,
            swap_count=swap_count,
            added_two_qubit_count=3 * swap_count,
            weighted_depth=state.current_depth(),
            routing_ms=runtime_ms,
            valid=True,
            error="",
        )

    except Exception as exc:
        runtime_ms = (
            time.perf_counter() - start
        ) * 1000.0

        return CandidateResult(
            instance=case.name,
            circuit_mode=case.circuit_mode,
            topology=case.topology,
            algorithm=algorithm_name,
            mapping_name=candidate.name,
            swap_count=None,
            added_two_qubit_count=None,
            weighted_depth=None,
            routing_ms=runtime_ms,
            valid=False,
            error=f"{type(exc).__name__}: {exc}",
        )


def best_candidate(
    rows: list[CandidateResult],
) -> CandidateResult:
    valid = [
        row
        for row in rows
        if row.valid
    ]

    if not valid:
        errors = "; ".join(
            row.error
            for row in rows
            if row.error
        )

        raise RuntimeError(
            "该算法在当前实例上没有合法结果："
            f"{errors}"
        )

    return min(
        valid,
        key=lambda row: (
            row.score,
            row.routing_ms,
            row.mapping_name,
        ),
    )


def compare_scores(
    left: tuple[int, int],
    right: tuple[int, int],
) -> str:
    if left < right:
        return "OAABR胜"

    if left > right:
        return "Qiskit胜"

    return "平局"


# ============================================================
# 4. 读取 Stage 10 的 Qiskit 基线
# ============================================================

def load_qiskit_summary(
    path: Path,
) -> dict[str, tuple[int, int, int]]:
    if not path.exists():
        raise FileNotFoundError(
            f"找不到 Stage 10 汇总文件："
            f"{path.resolve()}"
        )

    result: dict[
        str,
        tuple[int, int, int],
    ] = {}

    with path.open(
        "r",
        encoding="utf-8-sig",
        newline="",
    ) as file:
        reader = csv.DictReader(file)

        for row in reader:
            result[row["instance"]] = (
                int(row["qiskit_swap"]),
                int(row["qiskit_added_2q"]),
                int(row["qiskit_depth"]),
            )

    return result


# ============================================================
# 5. 保存 CSV
# ============================================================

RAW_FIELDS = (
    "instance",
    "circuit_mode",
    "topology",
    "algorithm",
    "mapping_name",
    "swap_count",
    "added_two_qubit_count",
    "weighted_depth",
    "routing_ms",
    "valid",
    "error",
)


def save_raw(
    path: Path,
    rows: list[CandidateResult],
) -> None:
    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    with path.open(
        "w",
        encoding="utf-8-sig",
        newline="",
    ) as file:
        writer = csv.DictWriter(
            file,
            fieldnames=RAW_FIELDS,
        )

        writer.writeheader()

        for row in rows:
            writer.writerow(
                {
                    "instance": row.instance,
                    "circuit_mode": (
                        row.circuit_mode
                    ),
                    "topology": row.topology,
                    "algorithm": row.algorithm,
                    "mapping_name": (
                        row.mapping_name
                    ),
                    "swap_count": row.swap_count,
                    "added_two_qubit_count": (
                        row.added_two_qubit_count
                    ),
                    "weighted_depth": (
                        row.weighted_depth
                    ),
                    "routing_ms": (
                        f"{row.routing_ms:.3f}"
                    ),
                    "valid": row.valid,
                    "error": row.error,
                }
            )


SUMMARY_FIELDS = tuple(
    AblationSummary.__annotations__.keys()
)


def save_summary(
    path: Path,
    rows: list[AblationSummary],
) -> None:
    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    with path.open(
        "w",
        encoding="utf-8-sig",
        newline="",
    ) as file:
        writer = csv.DictWriter(
            file,
            fieldnames=SUMMARY_FIELDS,
        )

        writer.writeheader()

        for row in rows:
            writer.writerow(
                {
                    field: getattr(row, field)
                    for field in SUMMARY_FIELDS
                }
            )


# ============================================================
# 6. 汇总打印
# ============================================================

def print_global_summary(
    rows: list[AblationSummary],
) -> None:
    print()
    print("=" * 100)
    print("Stage 11：路由结构消融总体汇总")
    print("=" * 100)

    by_algorithm: dict[
        str,
        list[AblationSummary],
    ] = defaultdict(list)

    for row in rows:
        by_algorithm[row.algorithm].append(row)

    for algorithm, algorithm_rows in (
        by_algorithm.items()
    ):
        outcomes = Counter(
            row.outcome
            for row in algorithm_rows
        )

        total_added = sum(
            row.added_two_qubit_count
            for row in algorithm_rows
        )

        total_depth = sum(
            row.weighted_depth
            for row in algorithm_rows
        )

        total_budget = sum(
            row.pool_budget_ms
            for row in algorithm_rows
        )

        print()
        print(f"[{algorithm}]")
        print("  胜负：", dict(outcomes))
        print(
            "  总附加2q：",
            total_added,
        )
        print(
            "  总加权深度：",
            total_depth,
        )
        print(
            "  总映射池路由时间："
            f"{total_budget:.3f} ms"
        )

    print()
    print("按线路模式比较最优自实现结构：")

    instances = sorted(
        {
            row.instance
            for row in rows
        }
    )

    best_structure_counter = Counter()
    mode_counter: dict[
        str,
        Counter[str],
    ] = defaultdict(Counter)

    for instance in instances:
        instance_rows = [
            row
            for row in rows
            if row.instance == instance
        ]

        best = min(
            instance_rows,
            key=lambda row: (
                row.added_two_qubit_count,
                row.weighted_depth,
                row.pool_budget_ms,
            ),
        )

        best_structure_counter[
            best.algorithm
        ] += 1

        mode_counter[
            best.circuit_mode
        ][best.algorithm] += 1

    print(
        "  全部实例：",
        dict(best_structure_counter),
    )

    for mode in sorted(mode_counter):
        print(
            f"  {mode}: "
            f"{dict(mode_counter[mode])}"
        )


# ============================================================
# 7. 主程序
# ============================================================

def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Stage 11：在相同基础映射池上比较 "
            "OneStep、固定两步、Adaptive 和 "
            "Adaptive+Repair。"
        )
    )

    parser.add_argument(
        "--input",
        type=Path,
        default=Path(
            "data/benchmarks/dev.json"
        ),
    )

    parser.add_argument(
        "--qiskit-summary",
        type=Path,
        default=Path(
            "results/stage10_dev_summary.csv"
        ),
    )

    parser.add_argument(
        "--limit",
        type=int,
        default=None,
        help="仅运行前若干个实例",
    )

    parser.add_argument(
        "--verbose",
        action="store_true",
        help="显示完整路由日志",
    )

    parser.add_argument(
        "--raw-output",
        type=Path,
        default=Path(
            "results/stage11_router_ablation_raw.csv"
        ),
    )

    parser.add_argument(
        "--summary-output",
        type=Path,
        default=Path(
            "results/stage11_router_ablation_summary.csv"
        ),
    )

    args = parser.parse_args()

    if args.limit is not None and args.limit <= 0:
        raise ValueError(
            "--limit 必须为正整数"
        )

    cases = load_cases(
        path=args.input,
        limit=args.limit,
    )

    qiskit_summary = load_qiskit_summary(
        args.qiskit_summary
    )

    raw_rows: list[CandidateResult] = []
    summary_rows: list[AblationSummary] = []

    print("===== Stage 11：路由结构消融 =====")
    print("实例数：", len(cases))
    print(
        "比较结构：",
        ", ".join(name for name, _ in ROUTERS),
    )

    for index, case in enumerate(
        cases,
        start=1,
    ):
        print()
        print(
            f"[{index}/{len(cases)}] "
            f"{case.name}"
        )

        mapping_start = time.perf_counter()

        candidates = generate_base_mapping_pool(
            case.test_case
        )

        mapping_generation_ms = (
            time.perf_counter() - mapping_start
        ) * 1000.0

        if case.name not in qiskit_summary:
            raise KeyError(
                f"Qiskit 汇总中缺少实例："
                f"{case.name}"
            )

        (
            qiskit_swap,
            qiskit_added,
            qiskit_depth,
        ) = qiskit_summary[case.name]

        for algorithm_name, runner in ROUTERS:
            algorithm_rows: list[
                CandidateResult
            ] = []

            for candidate in candidates:
                result = run_candidate(
                    case=case,
                    candidate=candidate,
                    algorithm_name=(
                        algorithm_name
                    ),
                    runner=runner,
                    verbose=args.verbose,
                )

                algorithm_rows.append(result)
                raw_rows.append(result)

            best = best_candidate(
                algorithm_rows
            )

            pool_budget = (
                mapping_generation_ms
                + sum(
                    row.routing_ms
                    for row in algorithm_rows
                )
            )

            outcome = compare_scores(
                best.score,
                (
                    qiskit_added,
                    qiskit_depth,
                ),
            )

            summary = AblationSummary(
                instance=case.name,
                circuit_mode=(
                    case.circuit_mode
                ),
                topology=case.topology,
                num_qubits=case.num_qubits,
                algorithm=algorithm_name,
                best_mapping=(
                    best.mapping_name
                ),
                swap_count=int(
                    best.swap_count
                ),
                added_two_qubit_count=int(
                    best.added_two_qubit_count
                ),
                weighted_depth=int(
                    best.weighted_depth
                ),
                pool_budget_ms=pool_budget,
                qiskit_swap=qiskit_swap,
                qiskit_added_two_qubit_count=(
                    qiskit_added
                ),
                qiskit_depth=qiskit_depth,
                outcome=outcome,
            )

            summary_rows.append(summary)

            print(
                f"  {algorithm_name:<22}"
                f"mapping={best.mapping_name:<8}"
                f"SWAP={best.swap_count:<3}"
                f"depth={best.weighted_depth:<4}"
                f"budget={pool_budget:>9.2f} ms  "
                f"{outcome}"
            )

        save_raw(
            args.raw_output,
            raw_rows,
        )

        save_summary(
            args.summary_output,
            summary_rows,
        )

    print_global_summary(
        summary_rows
    )

    print()
    print(
        "原始结果：",
        args.raw_output.resolve(),
    )

    print(
        "汇总结果：",
        args.summary_output.resolve(),
    )


if __name__ == "__main__":
    main()
