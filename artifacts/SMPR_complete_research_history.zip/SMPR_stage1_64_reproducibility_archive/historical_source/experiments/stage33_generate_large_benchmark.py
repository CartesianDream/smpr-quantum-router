from __future__ import annotations

import argparse
import json
import random
from collections import Counter, deque
from dataclasses import dataclass
from pathlib import Path


DEFAULT_SEED = 20260907


@dataclass(frozen=True)
class TopologySpec:
    name: str
    physical_qubits: int
    target_edges: int
    rows: int
    cols: int
    logical_sizes: tuple[int, int, int]


# 节点数和无向耦合边数取自用户提供的 SIMPLETES 文档。
# 由于当前包没有厂商逐边 coupling map，名称明确加 _like，避免把
# 合成拓扑误写成真实芯片。Stage 33 的目标是先验证尺度与稀疏度机制。
TOPOLOGIES = (
    TopologySpec("q20_like", 20, 43, 4, 5, (12, 16, 20)),
    TopologySpec("willow_like", 105, 182, 7, 15, (20, 32, 48)),
    TopologySpec("heron_like", 156, 176, 12, 13, (20, 32, 48)),
)

MODES = ("uniform", "alternating", "parallel_layers")
LENGTH_FACTORS = (6, 8, 10)


def edge(u: int, v: int) -> tuple[int, int]:
    return (u, v) if u < v else (v, u)


def grid_edges(rows: int, cols: int) -> list[tuple[int, int]]:
    result: list[tuple[int, int]] = []
    for r in range(rows):
        for c in range(cols):
            u = r * cols + c
            if c + 1 < cols:
                result.append(edge(u, u + 1))
            if r + 1 < rows:
                result.append(edge(u, u + cols))
    return sorted(set(result))


def snake_tree(rows: int, cols: int) -> list[tuple[int, int]]:
    order: list[int] = []
    for r in range(rows):
        row = [r * cols + c for c in range(cols)]
        if r % 2:
            row.reverse()
        order.extend(row)
    return [edge(order[i], order[i + 1]) for i in range(len(order) - 1)]


def diagonal_edges(rows: int, cols: int) -> list[tuple[int, int]]:
    result: list[tuple[int, int]] = []
    for r in range(rows - 1):
        for c in range(cols - 1):
            u = r * cols + c
            result.append(edge(u, u + cols + 1))
            result.append(edge(u + 1, u + cols))
    return sorted(set(result))


def balanced_grid_subset(
    rows: int,
    cols: int,
    target_edges: int,
) -> list[tuple[int, int]]:
    """
    稀疏大图不能用一条 snake path 再按编号局部补边，否则图会退化为
    近似长链。这里先保留每一行的全部横边，再把纵边均匀撒在每一对
    相邻行之间。第一轮保证每个行边界至少有一条连接。
    """
    horizontal = [
        edge(r * cols + c, r * cols + c + 1)
        for r in range(rows)
        for c in range(cols - 1)
    ]
    need_vertical = target_edges - len(horizontal)
    if need_vertical < rows - 1:
        raise ValueError("目标边数不足以连接所有网格行")

    vertical_order: list[tuple[int, int]] = []
    seen: set[tuple[int, int]] = set()
    # 4 与 13/15 互素；对当前大图可在每个行边界上均匀遍历列。
    for round_index in range(cols):
        for r in range(rows - 1):
            c = (5 * r + 4 * round_index) % cols
            candidate = edge(r * cols + c, (r + 1) * cols + c)
            if candidate not in seen:
                seen.add(candidate)
                vertical_order.append(candidate)
    if len(vertical_order) < need_vertical:
        raise RuntimeError("可用纵边不足")
    return horizontal + vertical_order[:need_vertical]


def build_topology(spec: TopologySpec) -> tuple[tuple[int, int], ...]:
    if spec.rows * spec.cols != spec.physical_qubits:
        raise ValueError(f"{spec.name}: rows*cols 与节点数不一致")

    ordinary = grid_edges(spec.rows, spec.cols)
    horizontal_count = spec.rows * (spec.cols - 1)

    if horizontal_count + spec.rows - 1 <= spec.target_edges <= len(ordinary):
        selected = balanced_grid_subset(
            spec.rows, spec.cols, spec.target_edges
        )
    else:
        # Q20-like 的43边多于4x5普通网格的31边，保留全网格并均匀加入
        # 对角耦合。大图稀疏分支不会走到这里。
        selected = list(ordinary)
        seen = set(selected)
        for candidate in diagonal_edges(spec.rows, spec.cols):
            if len(selected) >= spec.target_edges:
                break
            if candidate not in seen:
                seen.add(candidate)
                selected.append(candidate)

    if len(selected) != spec.target_edges:
        raise RuntimeError(
            f"{spec.name}: 只能生成 {len(selected)} 条边，目标为 {spec.target_edges}"
        )
    validate_connected(spec.physical_qubits, selected)
    return tuple(sorted(selected))


def validate_connected(n: int, edges: list[tuple[int, int]]) -> None:
    adjacency = [[] for _ in range(n)]
    for u, v in edges:
        adjacency[u].append(v)
        adjacency[v].append(u)
    seen = {0}
    queue: deque[int] = deque([0])
    while queue:
        u = queue.popleft()
        for v in adjacency[u]:
            if v not in seen:
                seen.add(v)
                queue.append(v)
    if len(seen) != n:
        raise ValueError(f"合成拓扑不连通：{len(seen)}/{n}")


def uniform_pairs(n: int, count: int, rng: random.Random) -> list[tuple[int, int]]:
    result: list[tuple[int, int]] = []
    for _ in range(count):
        u = rng.randrange(n)
        v = rng.randrange(n - 1)
        if v >= u:
            v += 1
        result.append((u, v))
    return result


def alternating_pairs(n: int, count: int, rng: random.Random) -> list[tuple[int, int]]:
    result: list[tuple[int, int]] = []
    offset = max(2, n // 2)
    for i in range(count):
        u = (3 * i + rng.randrange(max(1, n // 4))) % n
        if (i // max(1, n // 2)) % 2 == 0:
            v = (u + offset + i % 3) % n
        else:
            v = (u + 1 + i % 2) % n
        if u == v:
            v = (v + 1) % n
        result.append((u, v))
    return result


def parallel_pairs(n: int, count: int, rng: random.Random) -> list[tuple[int, int]]:
    result: list[tuple[int, int]] = []
    while len(result) < count:
        order = list(range(n))
        rng.shuffle(order)
        for i in range(0, n - 1, 2):
            result.append((order[i], order[i + 1]))
            if len(result) == count:
                break
    return result


def generate_gate_specs(
    logical_qubits: int,
    cx_count: int,
    mode: str,
    rng: random.Random,
) -> tuple[tuple, ...]:
    if mode == "uniform":
        pairs = uniform_pairs(logical_qubits, cx_count, rng)
    elif mode == "alternating":
        pairs = alternating_pairs(logical_qubits, cx_count, rng)
    elif mode == "parallel_layers":
        pairs = parallel_pairs(logical_qubits, cx_count, rng)
    else:
        raise ValueError(f"未知线路模式：{mode}")
    return tuple(("cx", u, v) for u, v in pairs)


def build_cases(master_seed: int) -> list[dict]:
    cases: list[dict] = []
    index = 0
    for topology_index, spec in enumerate(TOPOLOGIES):
        edges = build_topology(spec)
        for profile_index, (mode, logical_qubits, factor) in enumerate(
            zip(MODES, spec.logical_sizes, LENGTH_FACTORS)
        ):
            seed = master_seed + 100_003 * topology_index + 1009 * profile_index
            rng = random.Random(seed)
            cx_count = logical_qubits * factor
            name = (
                f"large_v1_{index:03d}_{spec.name}_p{spec.physical_qubits}_"
                f"l{logical_qubits}_{mode}_f{factor}_cx{cx_count}"
            )
            cases.append(
                {
                    "name": name,
                    "split": "probe",
                    "seed": seed,
                    "profile_id": index,
                    "num_qubits": logical_qubits,
                    "physical_qubits": spec.physical_qubits,
                    "topology": spec.name,
                    "circuit_mode": mode,
                    "length_factor": factor,
                    "two_qubit_gate_count": cx_count,
                    "edges": [list(value) for value in edges],
                    "gate_specs": [list(value) for value in generate_gate_specs(
                        logical_qubits, cx_count, mode, rng
                    )],
                    "initial_mapping": list(range(logical_qubits)),
                    "topology_is_exact_hardware": False,
                }
            )
            index += 1
    return cases


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Stage 33：生成逻辑/物理规模分离的大拓扑探针"
    )
    parser.add_argument("--master-seed", type=int, default=DEFAULT_SEED)
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("data/benchmarks_large_v1/probe.json"),
    )
    args = parser.parse_args()

    cases = build_cases(args.master_seed)
    payload = {
        "schema_version": 6,
        "master_seed": args.master_seed,
        "purpose": "large sparse topology scalability and compact-layout probe",
        "warning": (
            "Q20/Willow/Heron-like synthetic graphs match documented node/edge "
            "counts but are not vendor-exact coupling maps"
        ),
        "cases": cases,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    print("===== Stage 33：大拓扑基准生成完成 =====")
    print(f"输出：{args.output.resolve()}")
    print(f"实例数：{len(cases)}")
    print("注意：这是等规模/等稀疏度拓扑，不冒充厂商逐边拓扑。")
    for topology, count in Counter(case["topology"] for case in cases).items():
        first = next(case for case in cases if case["topology"] == topology)
        print(
            f"  {topology}: {count} cases, "
            f"physical={first['physical_qubits']}, edges={len(first['edges'])}"
        )


if __name__ == "__main__":
    main()
