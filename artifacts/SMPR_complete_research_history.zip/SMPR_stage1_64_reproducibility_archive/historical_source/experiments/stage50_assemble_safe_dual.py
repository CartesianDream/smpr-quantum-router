from __future__ import annotations

import argparse
import csv
import hashlib
import json
import sys
from collections import Counter
from pathlib import Path

from qiskit import qasm3, qpy

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

from stage6_fixed_layout_benchmark import (
    weighted_qiskit_depth,
)


def load_by_instance(
    path: Path,
) -> dict[str, dict[str, str]]:
    with path.open(
        "r",
        encoding="utf-8-sig",
        newline="",
    ) as handle:
        rows = list(csv.DictReader(handle))

    return {
        row["instance"]: row
        for row in rows
    }


def sha256(path: Path) -> str:
    digest = hashlib.sha256()

    with path.open("rb") as handle:
        while True:
            block = handle.read(1024 * 1024)
            if not block:
                break
            digest.update(block)

    return digest.hexdigest()


def relative_text(
    path: Path,
    root: Path,
) -> str:
    try:
        return path.resolve().relative_to(
            root.resolve()
        ).as_posix()
    except ValueError:
        return str(path.resolve())


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Assemble and validate the executable "
            "Stage 50 safe dual-router outputs"
        )
    )
    parser.add_argument(
        "--portfolio",
        type=Path,
        default=Path(
            "results/stage49_safe_dual/"
            "safe_dual_cases.csv"
        ),
    )
    parser.add_argument(
        "--oaabr-cases",
        type=Path,
        default=Path(
            "results/stage50_executable/"
            "oaabr_winner_cases.csv"
        ),
    )
    parser.add_argument(
        "--lightsabre-cases",
        type=Path,
        default=Path(
            "results/stage50_executable/"
            "lightsabre_winner_cases.csv"
        ),
    )
    parser.add_argument(
        "--case-output",
        type=Path,
        default=Path(
            "results/stage50_executable/"
            "safe_dual_executable_cases.csv"
        ),
    )
    parser.add_argument(
        "--manifest-output",
        type=Path,
        default=Path(
            "results/stage50_executable/"
            "safe_dual_manifest.json"
        ),
    )
    parser.add_argument(
        "--hash-output",
        type=Path,
        default=Path(
            "results/stage50_executable/"
            "SHA256SUMS.txt"
        ),
    )
    args = parser.parse_args()

    root = Path.cwd()
    portfolio = load_by_instance(
        args.portfolio
    )
    oaabr = load_by_instance(
        args.oaabr_cases
    )
    lightsabre = load_by_instance(
        args.lightsabre_cases
    )

    if len(portfolio) != 60:
        raise AssertionError(
            f"portfolio 应有 60 例，实际 "
            f"{len(portfolio)}"
        )

    output_rows: list[dict[str, object]] = []
    artifacts: set[Path] = set()

    for instance, selected in portfolio.items():
        backend = selected["selected_backend"]
        expected_swap = int(
            selected["selected_swap"]
        )
        expected_depth = int(
            selected["selected_depth"]
        )
        source_cx = int(selected["cx_count"])

        if backend == "oaabr":
            source = oaabr[instance]
        elif backend == "lightsabre":
            source = lightsabre[instance]
        else:
            raise ValueError(
                f"{instance}: 未知 backend {backend}"
            )

        if source["status"] != "exported":
            raise AssertionError(
                f"{instance}: {backend} 未导出，"
                f"status={source['status']}"
            )

        actual_swap = int(source["swap"])
        actual_depth = int(source["depth"])

        if (
            actual_swap != expected_swap
            or actual_depth != expected_depth
        ):
            raise AssertionError(
                f"{instance}: 导出质量 "
                f"{actual_swap}/{actual_depth} "
                f"!= portfolio "
                f"{expected_swap}/{expected_depth}"
            )

        qasm_path = Path(source["qasm"])
        if not qasm_path.is_file():
            raise FileNotFoundError(qasm_path)

        manifest_path = (
            qasm_path.parent /
            "manifest.json"
        )
        if not manifest_path.is_file():
            raise FileNotFoundError(
                manifest_path
            )

        parsed = qasm3.loads(
            qasm_path.read_text(
                encoding="utf-8"
            )
        )
        operations = dict(
            parsed.count_ops()
        )

        if backend == "oaabr":
            parsed_swap = int(
                operations.get("swap", 0)
            )
            parsed_cx = int(
                operations.get("cx", 0)
            )
            expected_cx = (
                source_cx + 3 * expected_swap
            )

            if parsed_swap != 0:
                raise AssertionError(
                    f"{instance}: OAABR QASM "
                    "仍包含抽象 SWAP"
                )

            if parsed_cx != expected_cx:
                raise AssertionError(
                    f"{instance}: OAABR CX "
                    f"{parsed_cx} != {expected_cx}"
                )

            parsed_depth = int(
                parsed.depth()
            )

            if parsed_depth != expected_depth:
                raise AssertionError(
                    f"{instance}: OAABR QASM depth "
                    f"{parsed_depth} != "
                    f"{expected_depth}"
                )

            qpy_path = None
            qpy_hash = ""

        else:
            parsed_swap = int(
                operations.get("swap", 0)
            )

            if parsed_swap != expected_swap:
                raise AssertionError(
                    f"{instance}: LightSABRE "
                    f"QASM SWAP {parsed_swap} != "
                    f"{expected_swap}"
                )

            parsed_depth = int(
                weighted_qiskit_depth(parsed)
            )

            if parsed_depth != expected_depth:
                raise AssertionError(
                    f"{instance}: LightSABRE "
                    f"QASM depth {parsed_depth} != "
                    f"{expected_depth}"
                )

            qpy_path = Path(source["qpy"])
            if not qpy_path.is_file():
                raise FileNotFoundError(
                    qpy_path
                )

            with qpy_path.open("rb") as handle:
                loaded = qpy.load(handle)

            if len(loaded) != 1:
                raise AssertionError(
                    f"{instance}: QPY 电路数 "
                    f"{len(loaded)} != 1"
                )

            qpy_circuit = loaded[0]
            qpy_swap = int(
                qpy_circuit.count_ops().get(
                    "swap",
                    0,
                )
            )
            qpy_depth = int(
                weighted_qiskit_depth(
                    qpy_circuit
                )
            )

            if (
                qpy_swap != expected_swap
                or qpy_depth != expected_depth
            ):
                raise AssertionError(
                    f"{instance}: QPY 质量 "
                    f"{qpy_swap}/{qpy_depth} != "
                    f"{expected_swap}/"
                    f"{expected_depth}"
                )

            qpy_hash = sha256(qpy_path)
            artifacts.add(qpy_path)

        qasm_hash = sha256(qasm_path)
        manifest_hash = sha256(
            manifest_path
        )

        artifacts.add(qasm_path)
        artifacts.add(manifest_path)

        output_rows.append(
            {
                "instance": instance,
                "backend": backend,
                "swap": expected_swap,
                "depth": expected_depth,
                "source_cx": source_cx,
                "qasm": relative_text(
                    qasm_path,
                    root,
                ),
                "qasm_sha256": qasm_hash,
                "qpy": (
                    ""
                    if qpy_path is None
                    else relative_text(
                        qpy_path,
                        root,
                    )
                ),
                "qpy_sha256": qpy_hash,
                "manifest": relative_text(
                    manifest_path,
                    root,
                ),
                "manifest_sha256": (
                    manifest_hash
                ),
                "validated": True,
            }
        )

    output_rows.sort(
        key=lambda row: row["instance"]
    )

    backend_counts = Counter(
        str(row["backend"])
        for row in output_rows
    )
    total_swap = sum(
        int(row["swap"])
        for row in output_rows
    )

    if backend_counts != {
        "oaabr": 12,
        "lightsabre": 48,
    }:
        raise AssertionError(
            f"backend counts 错误："
            f"{dict(backend_counts)}"
        )

    if total_swap != 1670:
        raise AssertionError(
            f"总 SWAP {total_swap} != 1670"
        )

    args.case_output.parent.mkdir(
        parents=True,
        exist_ok=True,
    )
    args.manifest_output.parent.mkdir(
        parents=True,
        exist_ok=True,
    )
    args.hash_output.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    with args.case_output.open(
        "w",
        encoding="utf-8",
        newline="",
    ) as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=list(output_rows[0]),
        )
        writer.writeheader()
        writer.writerows(output_rows)

    hash_lines = [
        (
            f"{sha256(path)}  "
            f"{relative_text(path, root)}"
        )
        for path in sorted(
            artifacts,
            key=lambda item: str(item),
        )
    ]
    args.hash_output.write_text(
        "\n".join(hash_lines) + "\n",
        encoding="utf-8",
    )

    manifest = {
        "stage": 50,
        "name": (
            "Executable safe dual-router"
        ),
        "selection_rule": (
            "minimize (SWAP, weighted depth); "
            "exact ties select LightSABRE"
        ),
        "cases": len(output_rows),
        "backend_counts": dict(
            backend_counts
        ),
        "total_swap": total_swap,
        "lightsabre_baseline_swap": 1691,
        "gain_vs_lightsabre": 21,
        "relative_gain_pct": (
            100.0 * 21 / 1691
        ),
        "qasm_validated": len(
            output_rows
        ),
        "qpy_validated": (
            backend_counts["lightsabre"]
        ),
        "case_output": relative_text(
            args.case_output,
            root,
        ),
        "hash_output": relative_text(
            args.hash_output,
            root,
        ),
        "case_output_sha256": sha256(
            args.case_output
        ),
        "hash_output_sha256": sha256(
            args.hash_output
        ),
        "portfolio_source": relative_text(
            args.portfolio,
            root,
        ),
        "portfolio_source_sha256": sha256(
            args.portfolio
        ),
    }

    args.manifest_output.write_text(
        json.dumps(
            manifest,
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )

    print(
        "===== Stage 50 executable safe dual ====="
    )
    print("cases:", len(output_rows))
    print(
        "backends:",
        dict(backend_counts),
    )
    print("total SWAP:", total_swap)
    print(
        "gain vs LightSABRE:",
        1691 - total_swap,
    )
    print(
        "QASM validated:",
        len(output_rows),
    )
    print(
        "QPY validated:",
        backend_counts["lightsabre"],
    )
    print(
        "cases output:",
        args.case_output.resolve(),
    )
    print(
        "manifest:",
        args.manifest_output.resolve(),
    )
    print(
        "hashes:",
        args.hash_output.resolve(),
    )


if __name__ == "__main__":
    main()