from __future__ import annotations

import argparse
import csv
import json
import time
from collections import Counter
from dataclasses import asdict, dataclass
from pathlib import Path

import stage20_score_structure_ablation as stage20
import stage21_policy_portfolio as stage21
import stage32_frozen_final_benchmark as stage32
import stage33_large_topology_probe as stage33

from stage10_dev_benchmark import DevCase, load_cases
from stage17_validation_select import run_qiskit_multiseed


@dataclass
class CaseResult:
    instance: str
    topology: str
    circuit_mode: str
    logical_qubits: int
    physical_qubits: int
    cx_count: int
    mode: str
    ours_variant: str
    ours_swap: int | None
    ours_depth: int | None
    ours_runtime_ms: float
    lightsabre_seed: int
    lightsabre_swap: int
    lightsabre_depth: int
    lightsabre_runtime_ms: float
    selected_router: str
    selected_swap: int
    selected_depth: int
    saving_vs_lightsabre: int


def quality(swap: int, depth: int) -> tuple[int, int]:
    return swap, depth


def run_large_ours(
    case: DevCase,
    anchor_trials: int,
    mapping_trials: int,
) -> tuple[str, int, int, float]:
    start = time.perf_counter()
    pool, _ = stage33.compact_mapping_pool(case, anchor_trials)
    configs = [
        stage20.CONFIG_BY_NAME["simpletes_ordered"],
        stage20.CONFIG_BY_NAME["front_sum"],
    ]
    attempts = [
        stage33.run_attempt(case, mapping, proxy, config)
        for mapping, proxy in pool[:mapping_trials]
        for config in configs
    ]
    valid = [row for row in attempts if row.valid]
    if not valid:
        errors = " | ".join(row.error for row in attempts)
        raise RuntimeError(f"{case.name} 自研候选全部失败：{errors}")
    best = min(valid, key=stage33.quality)
    runtime_ms = (time.perf_counter() - start) * 1000.0
    return (
        f"stage33:{best.mapping}:{best.policy}",
        int(best.swap),
        int(best.depth),
        runtime_ms,
    )


def run_ours(
    case: DevCase,
    config: stage20.StructuralConfig,
    lightsabre_swap: int,
    lightsabre_depth: int,
    anchor_trials: int,
    mapping_trials: int,
) -> tuple[str, int, int, float]:
    dag, hardware, _ = case.test_case.build()
    if hardware.num_qubits > dag.num_logical_qubits:
        return run_large_ours(case, anchor_trials, mapping_trials)

    routed = stage32.run_frozen_router(
        case=case,
        config=config,
        lightsabre_swap=lightsabre_swap,
        lightsabre_depth=lightsabre_depth,
    )
    return routed.variant, routed.swap, routed.depth, routed.runtime_ms


def save_csv(path: Path, rows: list[CaseResult]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=CaseResult.__annotations__.keys())
        writer.writeheader()
        writer.writerows(asdict(row) for row in rows)


def summarize(rows: list[CaseResult], mode: str) -> dict:
    lightsabre_swap = sum(row.lightsabre_swap for row in rows)
    selected_swap = sum(row.selected_swap for row in rows)
    selected = Counter(row.selected_router for row in rows)
    return {
        "mode": mode,
        "case_count": len(rows),
        "lightsabre_swap": lightsabre_swap,
        "selected_swap": selected_swap,
        "saving_vs_lightsabre": lightsabre_swap - selected_swap,
        "relative_saving": (
            (lightsabre_swap - selected_swap) / lightsabre_swap
            if lightsabre_swap else 0.0
        ),
        "selected_router_counts": dict(selected),
        "ours_runtime_ms": sum(row.ours_runtime_ms for row in rows),
        "lightsabre_runtime_ms": sum(row.lightsabre_runtime_ms for row in rows),
    }


def write_summary(path: Path, rows: list[CaseResult], mode: str) -> dict:
    result = summarize(rows, mode)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    return result


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Stage 44：LightSABRE 单路由或 LightSABRE+OAABR 简单 Portfolio"
    )
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--mode", choices=("portfolio", "lightsabre"), default="portfolio")
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--case-indices", type=str, default=None)
    parser.add_argument("--qiskit-seeds", type=int, default=20)
    parser.add_argument("--qiskit-repeats", type=int, default=2)
    parser.add_argument("--anchor-trials", type=int, default=2)
    parser.add_argument("--mapping-trials", type=int, default=1)
    parser.add_argument(
        "--case-output", type=Path,
        default=Path("results/stage44_portfolio_cases.csv"),
    )
    parser.add_argument(
        "--summary-output", type=Path,
        default=Path("results/stage44_portfolio_summary.json"),
    )
    args = parser.parse_args()

    if not args.input.exists():
        raise FileNotFoundError(f"找不到输入：{args.input.resolve()}")
    if args.limit is not None and args.limit <= 0:
        raise ValueError("--limit 必须为正整数")
    if min(
        args.qiskit_seeds, args.qiskit_repeats,
        args.anchor_trials, args.mapping_trials,
    ) <= 0:
        raise ValueError("所有预算参数必须为正整数")

    cases = stage21.choose_cases(
        load_cases(args.input, limit=None),
        stage21.parse_indices(args.case_indices),
        args.limit,
    )
    stage33.configure_router()
    config = stage32.configure_router()

    print("===== Stage 44：简单 LightSABRE Portfolio =====")
    print(f"输入：{args.input.resolve()}")
    print(f"实例数：{len(cases)}")
    print(f"模式：{args.mode}")
    print(f"LightSABRE：{args.qiskit_seeds} seeds x {args.qiskit_repeats} repeats")
    if args.mode == "portfolio":
        print("选择规则：按 (SWAP, depth) 取 OAABR 与 LightSABRE 中较优者")
    else:
        print("只运行 LightSABRE；不运行自研候选")

    rows: list[CaseResult] = []
    for index, case in enumerate(cases, start=1):
        dag, hardware, _ = case.test_case.build()
        lightsabre, lightsabre_ms = run_qiskit_multiseed(
            case, args.qiskit_seeds, args.qiskit_repeats
        )
        ls_swap = int(lightsabre.swap_count)
        ls_depth = int(lightsabre.weighted_depth)

        ours_variant = "disabled"
        ours_swap: int | None = None
        ours_depth: int | None = None
        ours_ms = 0.0
        if args.mode == "portfolio":
            ours_variant, ours_swap, ours_depth, ours_ms = run_ours(
                case, config, ls_swap, ls_depth,
                args.anchor_trials, args.mapping_trials,
            )

        if (
            ours_swap is not None
            and ours_depth is not None
            and quality(ours_swap, ours_depth) < quality(ls_swap, ls_depth)
        ):
            selected_router = "OAABR"
            selected_swap, selected_depth = ours_swap, ours_depth
        else:
            selected_router = "LightSABRE"
            selected_swap, selected_depth = ls_swap, ls_depth

        row = CaseResult(
            instance=case.name,
            topology=case.topology,
            circuit_mode=case.circuit_mode,
            logical_qubits=dag.num_logical_qubits,
            physical_qubits=hardware.num_qubits,
            cx_count=case.two_qubit_gate_count,
            mode=args.mode,
            ours_variant=ours_variant,
            ours_swap=ours_swap,
            ours_depth=ours_depth,
            ours_runtime_ms=ours_ms,
            lightsabre_seed=int(lightsabre.seed),
            lightsabre_swap=ls_swap,
            lightsabre_depth=ls_depth,
            lightsabre_runtime_ms=lightsabre_ms,
            selected_router=selected_router,
            selected_swap=selected_swap,
            selected_depth=selected_depth,
            saving_vs_lightsabre=ls_swap - selected_swap,
        )
        rows.append(row)
        save_csv(args.case_output, rows)
        write_summary(args.summary_output, rows, args.mode)
        ours_text = (
            f"{ours_swap}/{ours_depth}" if ours_swap is not None else "未运行"
        )
        print(
            f"[{index}/{len(cases)}] {case.name}: "
            f"ours={ours_text}, LightSABRE={ls_swap}/{ls_depth}, "
            f"选择={selected_router} -> {selected_swap}/{selected_depth}, "
            f"节省={row.saving_vs_lightsabre}"
        )

    result = write_summary(args.summary_output, rows, args.mode)
    save_csv(args.case_output, rows)
    print("\n===== Stage 44 汇总 =====")
    print(f"LightSABRE total SWAP：{result['lightsabre_swap']}")
    print(f"最终选择 total SWAP：{result['selected_swap']}")
    print(f"相对 LightSABRE 减少：{result['saving_vs_lightsabre']}")
    print(f"相对改善：{result['relative_saving']:.2%}")
    print(f"选择次数：{result['selected_router_counts']}")
    print(
        f"预算 ours/LightSABRE：{result['ours_runtime_ms']:.1f}/"
        f"{result['lightsabre_runtime_ms']:.1f} ms"
    )
    print(f"逐实例结果：{args.case_output.resolve()}")
    print(f"汇总 JSON：{args.summary_output.resolve()}")


if __name__ == "__main__":
    main()
