from __future__ import annotations

import argparse
import csv
import json
import time
from collections import Counter
from dataclasses import asdict, dataclass
from pathlib import Path

import stage21_policy_portfolio as stage21
import stage33_large_topology_probe as stage33

from stage6_fixed_layout_benchmark import (
    build_coupling_map,
    build_qiskit_circuit,
    transpile,
    weighted_qiskit_depth,
)
from stage7_initial_mapping_pool import MappingCandidate
from stage10_dev_benchmark import DevCase, load_cases


@dataclass
class AutoLayoutRow:
    instance: str
    seed: int
    mapping: str
    swap: int
    depth: int
    runtime_ms: float


@dataclass
class TransferAttempt:
    instance: str
    layout_seed: int
    mapping: str
    policy: str
    swap: int | None
    depth: int | None
    runtime_ms: float
    valid: bool
    error: str


@dataclass
class CaseResult:
    instance: str
    topology: str
    circuit_mode: str
    logical_qubits: int
    physical_qubits: int
    cx_count: int

    compact_mapping: str
    compact_policy: str
    compact_ours_swap: int
    compact_ours_depth: int

    qiskit_layouts_generated: int
    qiskit_layouts_unique: int
    transferred_layout_seed: int
    transferred_mapping: str
    transferred_policy: str
    transferred_ours_swap: int
    transferred_ours_depth: int
    transferred_ours_budget_ms: float

    same_layout_qiskit_swap: int
    same_layout_qiskit_depth: int
    improvement_on_same_layout: int

    auto_qiskit_best_seed: int
    auto_qiskit_swap: int
    auto_qiskit_depth: int
    auto_qiskit_budget_ms: float

    gain_vs_compact_layout: int
    final_swap_gap: int
    final_depth_gap: int
    outcome: str


def extract_initial_mapping(routed, circuit, logical_qubits: int) -> tuple[int, ...]:
    """兼容Qiskit 1.x/2.x的TranspileLayout表示。"""
    layout = getattr(routed, "layout", None)
    if layout is None:
        raise RuntimeError("Qiskit输出没有layout信息")

    method = getattr(layout, "initial_index_layout", None)
    if callable(method):
        try:
            values = list(method(filter_ancillas=True))
        except TypeError:
            values = list(method())
        if len(values) >= logical_qubits:
            mapping = tuple(int(value) for value in values[:logical_qubits])
            if len(set(mapping)) == logical_qubits:
                return mapping

    initial_layout = getattr(layout, "initial_layout", None)
    if initial_layout is not None:
        get_virtual_bits = getattr(initial_layout, "get_virtual_bits", None)
        if callable(get_virtual_bits):
            virtual_to_physical = get_virtual_bits()
            try:
                mapping = tuple(
                    int(virtual_to_physical[qubit])
                    for qubit in circuit.qubits[:logical_qubits]
                )
            except KeyError:
                mapping = ()
            if len(mapping) == logical_qubits and len(set(mapping)) == logical_qubits:
                return mapping

    raise RuntimeError(
        "无法从Qiskit TranspileLayout提取logical->physical映射；"
        f"layout类型={type(layout).__name__}"
    )


def generate_qiskit_layouts(
    case: DevCase,
    seeds: int,
) -> list[AutoLayoutRow]:
    if transpile is None:
        raise RuntimeError("当前环境没有安装Qiskit")
    circuit = build_qiskit_circuit(case.test_case)
    coupling_map = build_coupling_map(case.test_case)
    rows: list[AutoLayoutRow] = []
    for seed in range(seeds):
        start = time.perf_counter()
        routed = transpile(
            circuit,
            coupling_map=coupling_map,
            layout_method="sabre",
            routing_method="sabre",
            optimization_level=0,
            seed_transpiler=seed,
        )
        elapsed_ms = (time.perf_counter() - start) * 1000.0
        operations = dict(routed.count_ops())
        mapping = extract_initial_mapping(routed, circuit, case.num_qubits)
        if any(
            physical < 0 or physical >= case.test_case.num_physical_qubits
            for physical in mapping
        ):
            raise RuntimeError(f"{case.name}/seed={seed}: 提取出非法物理节点")
        rows.append(
            AutoLayoutRow(
                instance=case.name,
                seed=seed,
                mapping=",".join(str(value) for value in mapping),
                swap=int(operations.get("swap", 0)),
                depth=weighted_qiskit_depth(routed),
                runtime_ms=elapsed_ms,
            )
        )
    return rows


def mapping_tuple(text: str) -> tuple[int, ...]:
    return tuple(int(value) for value in text.split(",") if value != "")


def auto_quality(row: AutoLayoutRow) -> tuple[int, int, float, int]:
    return row.swap, row.depth, row.runtime_ms, row.seed


def save_csv(path: Path, rows: list, fields) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=fields)
        writer.writeheader()
        writer.writerows(asdict(row) for row in rows)


def summarize(rows: list[CaseResult]) -> dict:
    compact = sum(row.compact_ours_swap for row in rows)
    transferred = sum(row.transferred_ours_swap for row in rows)
    auto = sum(row.auto_qiskit_swap for row in rows)
    outcomes = Counter(row.outcome for row in rows)
    return {
        "case_count": len(rows),
        "compact_ours_swap": compact,
        "qiskit_layout_ours_swap": transferred,
        "qiskit_auto_swap": auto,
        "gain_from_layout_transfer": compact - transferred,
        "final_swap_gap": transferred - auto,
        "same_layout_online_improvement": sum(
            row.improvement_on_same_layout for row in rows
        ),
        "wins": outcomes["OAABR胜"],
        "ties": outcomes["平局"],
        "losses": outcomes["LightSABRE胜"],
        "transferred_ours_budget_ms": sum(
            row.transferred_ours_budget_ms for row in rows
        ),
        "qiskit_auto_budget_ms": sum(row.auto_qiskit_budget_ms for row in rows),
    }


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Stage 35：把Qiskit候选初始布局迁移给自研在线路由器"
    )
    parser.add_argument(
        "--input", type=Path, default=Path("data/benchmarks_large_v1/probe.json")
    )
    parser.add_argument("--case-indices", type=str, default="3,6")
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--anchor-trials", type=int, default=2)
    parser.add_argument("--mapping-trials", type=int, default=1)
    parser.add_argument("--policies", type=str, default=stage33.DEFAULT_POLICIES)
    parser.add_argument("--layout-seeds", type=int, default=5)
    parser.add_argument(
        "--auto-output", type=Path,
        default=Path("results/stage35_auto_layouts.csv"),
    )
    parser.add_argument(
        "--attempt-output", type=Path,
        default=Path("results/stage35_transfer_attempts.csv"),
    )
    parser.add_argument(
        "--case-output", type=Path,
        default=Path("results/stage35_cases.csv"),
    )
    parser.add_argument(
        "--summary-output", type=Path,
        default=Path("results/stage35_summary.json"),
    )
    args = parser.parse_args()
    if args.layout_seeds <= 0:
        raise ValueError("layout-seeds必须为正数")

    stage33.configure_router()
    policies = stage33.parse_policies(args.policies)
    cases = stage21.choose_cases(
        load_cases(args.input, limit=None),
        stage21.parse_indices(args.case_indices),
        args.limit,
    )

    print("===== Stage 35：Qiskit布局 × 自研在线路由交叉探针 =====")
    print(f"输入：{args.input.resolve()}")
    print(f"实例数：{len(cases)}")
    print(f"Qiskit布局种子：{args.layout_seeds}")
    print(f"自研策略：{[config.name for config in policies]}")
    print("注意：本阶段使用Qiskit布局作为诊断oracle，不是最终自主算法。")

    auto_rows_all: list[AutoLayoutRow] = []
    transfer_rows_all: list[TransferAttempt] = []
    case_rows: list[CaseResult] = []
    for index, case in enumerate(cases, start=1):
        print(f"[{index}/{len(cases)}] {case.name} ...", flush=True)

        compact_pool, _ = stage33.compact_mapping_pool(case, args.anchor_trials)
        compact_candidates = compact_pool[: args.mapping_trials]
        compact_attempts = [
            stage33.run_attempt(case, mapping, proxy, config)
            for mapping, proxy in compact_candidates
            for config in policies
        ]
        compact_valid = [row for row in compact_attempts if row.valid]
        if not compact_valid:
            raise RuntimeError(f"{case.name}: compact路由全部失败")
        compact_best = min(compact_valid, key=stage33.quality)

        auto_rows = generate_qiskit_layouts(case, args.layout_seeds)
        auto_rows_all.extend(auto_rows)
        auto_best = min(auto_rows, key=auto_quality)
        auto_budget = sum(row.runtime_ms for row in auto_rows)

        # 相同物理映射去重；同一映射保留Qiskit路由质量最好的种子，作为
        # “同布局Qiskit”对照。
        best_by_mapping: dict[str, AutoLayoutRow] = {}
        for row in auto_rows:
            old = best_by_mapping.get(row.mapping)
            if old is None or auto_quality(row) < auto_quality(old):
                best_by_mapping[row.mapping] = row

        transferred_candidates: list[tuple] = []
        transfer_budget = 0.0
        for layout_row in best_by_mapping.values():
            mapping = mapping_tuple(layout_row.mapping)
            candidate = MappingCandidate(
                name=f"qiskit_layout_seed{layout_row.seed}",
                mapping=mapping,
                generation_ms=layout_row.runtime_ms,
            )
            for config in policies:
                attempt = stage33.run_attempt(
                    case=case,
                    mapping=candidate,
                    proxy_cost=0.0,
                    config=config,
                )
                transfer_budget += attempt.runtime_ms
                transfer_rows_all.append(
                    TransferAttempt(
                        instance=case.name,
                        layout_seed=layout_row.seed,
                        mapping=layout_row.mapping,
                        policy=config.name,
                        swap=attempt.swap,
                        depth=attempt.depth,
                        runtime_ms=attempt.runtime_ms,
                        valid=attempt.valid,
                        error=attempt.error,
                    )
                )
                if attempt.valid:
                    transferred_candidates.append((attempt, layout_row))
        if not transferred_candidates:
            raise RuntimeError(f"{case.name}: 所有迁移布局上的自研路由失败")
        transferred_best, same_layout_qiskit = min(
            transferred_candidates,
            key=lambda item: stage33.quality(item[0]),
        )

        final_pair = (
            int(transferred_best.swap),
            int(transferred_best.depth),
        )
        auto_pair = (auto_best.swap, auto_best.depth)
        if final_pair < auto_pair:
            outcome = "OAABR胜"
        elif final_pair == auto_pair:
            outcome = "平局"
        else:
            outcome = "LightSABRE胜"

        row = CaseResult(
            instance=case.name,
            topology=case.topology,
            circuit_mode=case.circuit_mode,
            logical_qubits=case.num_qubits,
            physical_qubits=case.test_case.num_physical_qubits,
            cx_count=case.two_qubit_gate_count,
            compact_mapping=compact_best.mapping,
            compact_policy=compact_best.policy,
            compact_ours_swap=int(compact_best.swap),
            compact_ours_depth=int(compact_best.depth),
            qiskit_layouts_generated=len(auto_rows),
            qiskit_layouts_unique=len(best_by_mapping),
            transferred_layout_seed=same_layout_qiskit.seed,
            transferred_mapping=same_layout_qiskit.mapping,
            transferred_policy=transferred_best.policy,
            transferred_ours_swap=int(transferred_best.swap),
            transferred_ours_depth=int(transferred_best.depth),
            transferred_ours_budget_ms=transfer_budget,
            same_layout_qiskit_swap=same_layout_qiskit.swap,
            same_layout_qiskit_depth=same_layout_qiskit.depth,
            improvement_on_same_layout=(
                same_layout_qiskit.swap - int(transferred_best.swap)
            ),
            auto_qiskit_best_seed=auto_best.seed,
            auto_qiskit_swap=auto_best.swap,
            auto_qiskit_depth=auto_best.depth,
            auto_qiskit_budget_ms=auto_budget,
            gain_vs_compact_layout=(
                int(compact_best.swap) - int(transferred_best.swap)
            ),
            final_swap_gap=int(transferred_best.swap) - auto_best.swap,
            final_depth_gap=int(transferred_best.depth) - auto_best.depth,
            outcome=outcome,
        )
        case_rows.append(row)
        print(
            f"  compact+ours={row.compact_ours_swap}/{row.compact_ours_depth}"
        )
        print(
            f"  Qiskit-layout+ours={row.transferred_ours_swap}/"
            f"{row.transferred_ours_depth}; same-layout Qiskit="
            f"{row.same_layout_qiskit_swap}/{row.same_layout_qiskit_depth}"
        )
        print(
            f"  auto LightSABRE={row.auto_qiskit_swap}/{row.auto_qiskit_depth}; "
            f"layout gain={row.gain_vs_compact_layout:+d}, "
            f"final gap={row.final_swap_gap:+d}, {row.outcome}"
        )

        save_csv(args.auto_output, auto_rows_all, AutoLayoutRow.__annotations__.keys())
        save_csv(
            args.attempt_output,
            transfer_rows_all,
            TransferAttempt.__annotations__.keys(),
        )
        save_csv(args.case_output, case_rows, CaseResult.__annotations__.keys())
        args.summary_output.parent.mkdir(parents=True, exist_ok=True)
        args.summary_output.write_text(
            json.dumps(summarize(case_rows), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    summary = summarize(case_rows)
    print("\n===== Stage 35 汇总 =====")
    print(f"compact+ours total SWAP：{summary['compact_ours_swap']}")
    print(f"Qiskit-layout+ours total SWAP：{summary['qiskit_layout_ours_swap']}")
    print(f"auto LightSABRE total SWAP：{summary['qiskit_auto_swap']}")
    print(f"布局迁移减少：{summary['gain_from_layout_transfer']}")
    print(f"相对LightSABRE gap：{summary['final_swap_gap']:+d}")
    print(
        f"同布局在线改进：{summary['same_layout_online_improvement']:+d}"
    )
    print(
        f"逐实例胜/平/负：{summary['wins']}/"
        f"{summary['ties']}/{summary['losses']}"
    )
    print(f"Qiskit布局：{args.auto_output.resolve()}")
    print(f"迁移尝试：{args.attempt_output.resolve()}")
    print(f"逐实例：{args.case_output.resolve()}")
    print(f"汇总：{args.summary_output.resolve()}")


if __name__ == "__main__":
    main()
