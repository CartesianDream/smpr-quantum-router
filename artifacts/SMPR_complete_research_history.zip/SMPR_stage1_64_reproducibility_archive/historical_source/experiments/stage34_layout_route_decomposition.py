from __future__ import annotations

import argparse
import csv
import json
from collections import Counter
from dataclasses import asdict, dataclass, replace
from pathlib import Path

import stage21_policy_portfolio as stage21
import stage33_large_topology_probe as stage33

from stage6_fixed_layout_benchmark import RunResult, run_qiskit_sabre
from stage10_dev_benchmark import DevCase, load_cases
from stage17_validation_select import run_qiskit_multiseed


@dataclass
class AttemptRow:
    instance: str
    mapping: str
    algorithm: str
    seed: int | None
    repeat: int | None
    swap: int | None
    depth: int | None
    runtime_ms: float
    valid: bool
    error: str


@dataclass
class CaseDiagnosis:
    instance: str
    topology: str
    circuit_mode: str
    logical_qubits: int
    physical_qubits: int
    hardware_edges: int
    average_degree: float
    maximum_degree: int
    graph_diameter: int
    articulation_points: int
    cycle_rank: int
    logical_occupancy: float

    mapping: str
    mapping_proxy_cost: float
    mapping_span: int
    own_policy: str
    own_swap: int
    own_depth: int
    own_budget_ms: float

    qiskit_fixed_seed: int
    qiskit_fixed_swap: int
    qiskit_fixed_depth: int
    qiskit_fixed_budget_ms: float

    qiskit_auto_seed: int
    qiskit_auto_swap: int
    qiskit_auto_depth: int
    qiskit_auto_budget_ms: float

    online_routing_gap: int
    initial_layout_gap: int
    total_gap: int
    diagnosis: str


def articulation_count(adjacency: list[set[int]]) -> int:
    n = len(adjacency)
    discovery = [-1] * n
    low = [0] * n
    parent = [-1] * n
    points: set[int] = set()
    clock = 0

    def visit(u: int) -> None:
        nonlocal clock
        discovery[u] = low[u] = clock
        clock += 1
        children = 0
        for v in sorted(adjacency[u]):
            if discovery[v] == -1:
                parent[v] = u
                children += 1
                visit(v)
                low[u] = min(low[u], low[v])
                if parent[u] == -1 and children > 1:
                    points.add(u)
                if parent[u] != -1 and low[v] >= discovery[u]:
                    points.add(u)
            elif v != parent[u]:
                low[u] = min(low[u], discovery[v])

    for node in range(n):
        if discovery[node] == -1:
            visit(node)
    return len(points)


def graph_metrics(case: DevCase, mapping: tuple[int, ...]) -> dict[str, float | int]:
    _dag, hardware, _identity = case.test_case.build()
    distances = stage33.all_pairs_distances(hardware)
    degrees = [len(neighbors) for neighbors in hardware.adjacency]
    edge_count = len(hardware.edges)
    mapped = list(mapping)
    return {
        "hardware_edges": edge_count,
        "average_degree": 2.0 * edge_count / hardware.num_qubits,
        "maximum_degree": max(degrees, default=0),
        "graph_diameter": max(max(row) for row in distances),
        "articulation_points": articulation_count(hardware.adjacency),
        "cycle_rank": edge_count - hardware.num_qubits + 1,
        "logical_occupancy": case.num_qubits / hardware.num_qubits,
        "mapping_span": max(
            distances[mapped[i]][mapped[j]]
            for i in range(len(mapped))
            for j in range(i + 1, len(mapped))
        ) if len(mapped) > 1 else 0,
    }


def result_key(row: RunResult) -> tuple[int, int, float, int]:
    return (
        int(row.swap_count) if row.swap_count is not None else 10**9,
        int(row.weighted_depth) if row.weighted_depth is not None else 10**9,
        row.runtime_ms,
        int(row.seed) if row.seed is not None else -1,
    )


def run_qiskit_fixed_mapping(
    case: DevCase,
    mapping_name: str,
    mapping: tuple[int, ...],
    seeds: int,
    repeats: int,
) -> tuple[RunResult, float, list[AttemptRow]]:
    fixed_case = replace(case.test_case, initial_mapping=mapping)

    # 与自动布局基线一致，先预热一次并丢弃。
    run_qiskit_sabre(fixed_case, seed=0)

    raw: list[RunResult] = []
    attempts: list[AttemptRow] = []
    for seed in range(seeds):
        for repeat_index in range(repeats):
            result = run_qiskit_sabre(fixed_case, seed=seed)
            raw.append(result)
            attempts.append(
                AttemptRow(
                    instance=case.name,
                    mapping=mapping_name,
                    algorithm="qiskit_sabre_fixed_layout",
                    seed=seed,
                    repeat=repeat_index,
                    swap=result.swap_count,
                    depth=result.weighted_depth,
                    runtime_ms=result.runtime_ms,
                    valid=result.valid,
                    error=result.error,
                )
            )
    valid = [row for row in raw if row.valid]
    if not valid:
        raise RuntimeError(
            f"{case.name}/{mapping_name}: 固定布局 Qiskit 全部失败："
            + " | ".join(row.error for row in raw)
        )
    return min(valid, key=result_key), sum(row.runtime_ms for row in raw), attempts


def diagnosis_label(online_gap: int, layout_gap: int, total_gap: int) -> str:
    if total_gap <= 0:
        return "无总劣势"
    positive_online = max(0, online_gap)
    positive_layout = max(0, layout_gap)
    if positive_online >= 2 * max(1, positive_layout):
        return "在线路由为主"
    if positive_layout >= 2 * max(1, positive_online):
        return "初始布局为主"
    return "布局与路由共同造成"


def save_csv(path: Path, rows: list, fields) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=fields)
        writer.writeheader()
        writer.writerows(asdict(row) for row in rows)


def summarize(rows: list[CaseDiagnosis]) -> dict:
    own = sum(row.own_swap for row in rows)
    fixed = sum(row.qiskit_fixed_swap for row in rows)
    auto = sum(row.qiskit_auto_swap for row in rows)
    return {
        "case_count": len(rows),
        "own_swap": own,
        "qiskit_fixed_swap": fixed,
        "qiskit_auto_swap": auto,
        "online_routing_gap": own - fixed,
        "initial_layout_gap": fixed - auto,
        "total_gap": own - auto,
        "diagnosis_counts": dict(Counter(row.diagnosis for row in rows)),
        "own_budget_ms": sum(row.own_budget_ms for row in rows),
        "qiskit_fixed_budget_ms": sum(row.qiskit_fixed_budget_ms for row in rows),
        "qiskit_auto_budget_ms": sum(row.qiskit_auto_budget_ms for row in rows),
    }


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Stage 34：同一初始布局下分解布局与在线路由差距"
    )
    parser.add_argument(
        "--input", type=Path, default=Path("data/benchmarks_large_v1/probe.json")
    )
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--case-indices", type=str, default="3,6")
    parser.add_argument("--anchor-trials", type=int, default=2)
    parser.add_argument("--mapping-trials", type=int, default=1)
    parser.add_argument("--policies", type=str, default=stage33.DEFAULT_POLICIES)
    parser.add_argument("--qiskit-seeds", type=int, default=5)
    parser.add_argument("--qiskit-repeats", type=int, default=1)
    parser.add_argument(
        "--attempt-output", type=Path,
        default=Path("results/stage34_attempts.csv"),
    )
    parser.add_argument(
        "--case-output", type=Path,
        default=Path("results/stage34_cases.csv"),
    )
    parser.add_argument(
        "--summary-output", type=Path,
        default=Path("results/stage34_summary.json"),
    )
    args = parser.parse_args()
    if args.qiskit_seeds <= 0 or args.qiskit_repeats <= 0:
        raise ValueError("Qiskit seeds/repeats 必须为正数")

    stage33.configure_router()
    policies = stage33.parse_policies(args.policies)
    cases = stage21.choose_cases(
        load_cases(args.input, limit=None),
        stage21.parse_indices(args.case_indices),
        args.limit,
    )

    print("===== Stage 34：布局—在线路由责任分解 =====")
    print(f"输入：{args.input.resolve()}")
    print(f"实例数：{len(cases)}")
    print(f"策略：{[config.name for config in policies]}")
    print(
        f"布局：anchors={args.anchor_trials}, mappings={args.mapping_trials}"
    )
    print(
        f"Qiskit fixed/auto：{args.qiskit_seeds} seeds x "
        f"{args.qiskit_repeats} repeats"
    )
    print("分解恒等式：ours-auto = (ours-fixed) + (fixed-auto)")

    all_attempts: list[AttemptRow] = []
    case_rows: list[CaseDiagnosis] = []
    for index, case in enumerate(cases, start=1):
        print(f"[{index}/{len(cases)}] {case.name} ...", flush=True)
        pool, _generated = stage33.compact_mapping_pool(case, args.anchor_trials)
        selected_pool = pool[: args.mapping_trials]

        candidates: list[tuple] = []
        for mapping, proxy_cost in selected_pool:
            own_rows = [
                stage33.run_attempt(case, mapping, proxy_cost, config)
                for config in policies
            ]
            for row in own_rows:
                all_attempts.append(
                    AttemptRow(
                        instance=case.name,
                        mapping=mapping.name,
                        algorithm=f"own_{row.policy}",
                        seed=None,
                        repeat=None,
                        swap=row.swap,
                        depth=row.depth,
                        runtime_ms=row.runtime_ms,
                        valid=row.valid,
                        error=row.error,
                    )
                )
            valid_own = [row for row in own_rows if row.valid]
            if not valid_own:
                raise RuntimeError(f"{case.name}/{mapping.name}: 自研路由全部失败")
            own_best = min(valid_own, key=stage33.quality)
            fixed_best, fixed_budget, fixed_attempts = run_qiskit_fixed_mapping(
                case=case,
                mapping_name=mapping.name,
                mapping=mapping.mapping,
                seeds=args.qiskit_seeds,
                repeats=args.qiskit_repeats,
            )
            all_attempts.extend(fixed_attempts)
            candidates.append(
                (
                    own_best,
                    mapping,
                    proxy_cost,
                    fixed_best,
                    fixed_budget,
                    sum(row.runtime_ms for row in own_rows),
                )
            )

        selected = min(
            candidates,
            key=lambda item: stage33.quality(item[0]),
        )
        own_best, mapping, proxy_cost, fixed_best, _fixed_selected, _own_selected = selected
        total_fixed_budget = sum(item[4] for item in candidates)
        total_own_budget = sum(item[5] for item in candidates)
        auto_best, auto_budget = run_qiskit_multiseed(
            case, args.qiskit_seeds, args.qiskit_repeats
        )
        if auto_best.swap_count is None or auto_best.weighted_depth is None:
            raise RuntimeError(f"{case.name}: Qiskit auto 无合法结果")
        all_attempts.append(
            AttemptRow(
                instance=case.name,
                mapping="auto",
                algorithm="qiskit_sabre_auto_layout_best",
                seed=auto_best.seed,
                repeat=None,
                swap=auto_best.swap_count,
                depth=auto_best.weighted_depth,
                runtime_ms=auto_best.total_ms,
                valid=auto_best.valid,
                error=auto_best.error,
            )
        )

        metrics = graph_metrics(case, mapping.mapping)
        own_swap = int(own_best.swap)
        fixed_swap = int(fixed_best.swap_count)
        auto_swap = int(auto_best.swap_count)
        online_gap = own_swap - fixed_swap
        layout_gap = fixed_swap - auto_swap
        total_gap = own_swap - auto_swap
        row = CaseDiagnosis(
            instance=case.name,
            topology=case.topology,
            circuit_mode=case.circuit_mode,
            logical_qubits=case.num_qubits,
            physical_qubits=case.test_case.num_physical_qubits,
            hardware_edges=int(metrics["hardware_edges"]),
            average_degree=float(metrics["average_degree"]),
            maximum_degree=int(metrics["maximum_degree"]),
            graph_diameter=int(metrics["graph_diameter"]),
            articulation_points=int(metrics["articulation_points"]),
            cycle_rank=int(metrics["cycle_rank"]),
            logical_occupancy=float(metrics["logical_occupancy"]),
            mapping=mapping.name,
            mapping_proxy_cost=float(proxy_cost),
            mapping_span=int(metrics["mapping_span"]),
            own_policy=own_best.policy,
            own_swap=own_swap,
            own_depth=int(own_best.depth),
            own_budget_ms=total_own_budget,
            qiskit_fixed_seed=int(fixed_best.seed),
            qiskit_fixed_swap=fixed_swap,
            qiskit_fixed_depth=int(fixed_best.weighted_depth),
            qiskit_fixed_budget_ms=total_fixed_budget,
            qiskit_auto_seed=int(auto_best.seed),
            qiskit_auto_swap=auto_swap,
            qiskit_auto_depth=int(auto_best.weighted_depth),
            qiskit_auto_budget_ms=auto_budget,
            online_routing_gap=online_gap,
            initial_layout_gap=layout_gap,
            total_gap=total_gap,
            diagnosis=diagnosis_label(online_gap, layout_gap, total_gap),
        )
        case_rows.append(row)
        print(
            f"  ours={row.own_swap}/{row.own_depth}, "
            f"same-layout SABRE={row.qiskit_fixed_swap}/{row.qiskit_fixed_depth}, "
            f"auto LightSABRE={row.qiskit_auto_swap}/{row.qiskit_auto_depth}"
        )
        print(
            f"  gap decomposition: routing={row.online_routing_gap:+d}, "
            f"layout={row.initial_layout_gap:+d}, total={row.total_gap:+d}; "
            f"诊断={row.diagnosis}"
        )
        print(
            f"  graph: diameter={row.graph_diameter}, "
            f"articulation={row.articulation_points}, "
            f"cycle-rank={row.cycle_rank}, mapping-span={row.mapping_span}"
        )

        save_csv(args.attempt_output, all_attempts, AttemptRow.__annotations__.keys())
        save_csv(args.case_output, case_rows, CaseDiagnosis.__annotations__.keys())
        args.summary_output.parent.mkdir(parents=True, exist_ok=True)
        args.summary_output.write_text(
            json.dumps(summarize(case_rows), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    summary = summarize(case_rows)
    print("\n===== Stage 34 汇总 =====")
    print(f"ours total SWAP：{summary['own_swap']}")
    print(f"same-layout SABRE total SWAP：{summary['qiskit_fixed_swap']}")
    print(f"auto LightSABRE total SWAP：{summary['qiskit_auto_swap']}")
    print(f"在线路由差距：{summary['online_routing_gap']:+d}")
    print(f"初始布局差距：{summary['initial_layout_gap']:+d}")
    print(f"总差距：{summary['total_gap']:+d}")
    print(f"诊断计数：{summary['diagnosis_counts']}")
    print(f"逐尝试：{args.attempt_output.resolve()}")
    print(f"逐实例：{args.case_output.resolve()}")
    print(f"汇总：{args.summary_output.resolve()}")


if __name__ == "__main__":
    main()
