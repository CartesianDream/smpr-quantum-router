from __future__ import annotations

import argparse
import csv
import json
from collections import Counter
from dataclasses import asdict, dataclass
from pathlib import Path

import stage21_policy_portfolio as stage21
import stage33_large_topology_probe as stage33
import stage34_layout_route_decomposition as stage34
import stage35_qiskit_layout_transfer_probe as stage35
import stage37_proxy_local_layout_refinement as stage37

from stage7_initial_mapping_pool import MappingCandidate
from stage10_dev_benchmark import DevCase, load_cases


@dataclass
class TransferAttempt:
    instance: str
    qiskit_layout_seed: int
    mapping: str
    policy: str
    swap: int | None
    depth: int | None
    runtime_ms: float
    valid: bool
    error: str


@dataclass
class CaseResult:
    instance: str
    topology: str
    circuit_mode: str
    logical_qubits: int
    physical_qubits: int
    cx_count: int

    ours_layout_name: str
    ours_policy: str
    cell_oo_swap: int
    cell_oo_depth: int

    cell_oq_seed: int
    cell_oq_swap: int
    cell_oq_depth: int
    cell_oq_budget_ms: float

    qiskit_layout_seed: int
    qiskit_layout_mapping: str
    qiskit_layout_ours_policy: str
    cell_qo_swap: int
    cell_qo_depth: int
    cell_qo_budget_ms: float

    cell_qq_swap: int
    cell_qq_depth: int
    cell_qq_budget_ms: float

    total_gap: int
    routing_gap_on_ours_layout: int
    layout_gap_with_qiskit_router: int
    layout_gap_with_ours_router: int
    routing_gap_on_qiskit_layout: int
    interaction: int
    shapley_layout: float
    shapley_routing: float
    diagnosis: str


def read_csv(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        raise FileNotFoundError(f"找不到文件：{path.resolve()}")
    with path.open("r", encoding="utf-8-sig", newline="") as file:
        return list(csv.DictReader(file))


def save_csv(path: Path, rows: list, fields) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=fields)
        writer.writeheader()
        writer.writerows(asdict(row) for row in rows)


def mapping_text(mapping: tuple[int, ...]) -> str:
    return ",".join(str(value) for value in mapping)


def recover_ours_mapping(
    case: DevCase,
    stage37_row: dict[str, str],
    candidate_rows: dict[tuple[str, str], dict[str, str]],
    stage36_rows: dict[str, dict[str, str]],
    polish_rows: list[dict[str, str]],
    anchor_trials: int,
) -> tuple[int, ...]:
    selected_name = stage37_row["selected_mapping"]
    candidate = candidate_rows.get((case.name, selected_name))
    if candidate is not None:
        return stage37.parse_mapping(candidate["mapping"])

    if stage37_row.get("selected_mutation") == "stage36_fallback":
        if case.name not in stage36_rows:
            raise ValueError(f"Stage 36 cases CSV 缺少 {case.name}")
        return stage37.recover_stage36_mapping(
            case=case,
            case_row=stage36_rows[case.name],
            polish_rows=polish_rows,
            anchor_trials=anchor_trials,
        )
    raise ValueError(
        f"{case.name}: 在 Stage 37 candidates CSV 中找不到 {selected_name}"
    )


def diagnosis_label(total: int, layout: float, routing: float) -> str:
    if total <= 0:
        return "无总劣势"
    positive_layout = max(0.0, layout)
    positive_routing = max(0.0, routing)
    if positive_layout >= 2.0 * max(1.0, positive_routing):
        return "初始布局为主"
    if positive_routing >= 2.0 * max(1.0, positive_layout):
        return "在线路由为主"
    return "布局与路由共同造成"


def summarize(rows: list[CaseResult]) -> dict:
    oo = sum(row.cell_oo_swap for row in rows)
    oq = sum(row.cell_oq_swap for row in rows)
    qo = sum(row.cell_qo_swap for row in rows)
    qq = sum(row.cell_qq_swap for row in rows)
    return {
        "case_count": len(rows),
        "cell_oo_swap": oo,
        "cell_oq_swap": oq,
        "cell_qo_swap": qo,
        "cell_qq_swap": qq,
        "total_gap": oo - qq,
        "routing_gap_on_ours_layout": oo - oq,
        "layout_gap_with_qiskit_router": oq - qq,
        "layout_gap_with_ours_router": oo - qo,
        "routing_gap_on_qiskit_layout": qo - qq,
        "interaction": oo - oq - qo + qq,
        "shapley_layout": sum(row.shapley_layout for row in rows),
        "shapley_routing": sum(row.shapley_routing for row in rows),
        "diagnosis_counts": dict(Counter(row.diagnosis for row in rows)),
        "qiskit_fixed_budget_ms": sum(row.cell_oq_budget_ms for row in rows),
        "ours_transfer_budget_ms": sum(row.cell_qo_budget_ms for row in rows),
        "qiskit_auto_budget_ms": sum(row.cell_qq_budget_ms for row in rows),
    }


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Stage 39：初始布局 × 在线路由的2×2交叉责任分解"
    )
    parser.add_argument(
        "--input", type=Path, default=Path("data/benchmarks_large_v1/probe.json")
    )
    parser.add_argument("--case-indices", type=str, default="4,7")
    parser.add_argument(
        "--stage36-cases", type=Path,
        default=Path("results/stage38_alternating_stage36_cases.csv"),
    )
    parser.add_argument(
        "--stage36-polish", type=Path,
        default=Path("results/stage38_alternating_polish.csv"),
    )
    parser.add_argument(
        "--stage37-cases", type=Path,
        default=Path("results/stage38_alternating_stage37_cases.csv"),
    )
    parser.add_argument(
        "--stage37-candidates", type=Path,
        default=Path("results/stage38_alternating_candidates.csv"),
    )
    parser.add_argument("--anchor-trials", type=int, default=4)
    parser.add_argument("--layout-seeds", type=int, default=5)
    parser.add_argument("--fixed-seeds", type=int, default=5)
    parser.add_argument("--fixed-repeats", type=int, default=1)
    parser.add_argument(
        "--policies", type=str, default=stage33.DEFAULT_POLICIES
    )
    parser.add_argument(
        "--auto-output", type=Path,
        default=Path("results/stage39_auto_layouts.csv"),
    )
    parser.add_argument(
        "--attempt-output", type=Path,
        default=Path("results/stage39_transfer_attempts.csv"),
    )
    parser.add_argument(
        "--case-output", type=Path,
        default=Path("results/stage39_cases.csv"),
    )
    parser.add_argument(
        "--summary-output", type=Path,
        default=Path("results/stage39_summary.json"),
    )
    args = parser.parse_args()
    if min(
        args.anchor_trials,
        args.layout_seeds,
        args.fixed_seeds,
        args.fixed_repeats,
    ) <= 0:
        raise ValueError("所有预算参数必须为正数")

    stage33.configure_router()
    policies = stage33.parse_policies(args.policies)
    cases = stage21.choose_cases(
        load_cases(args.input, limit=None),
        stage21.parse_indices(args.case_indices),
        None,
    )
    stage36_rows = {row["instance"]: row for row in read_csv(args.stage36_cases)}
    polish_rows = read_csv(args.stage36_polish)
    stage37_rows = {row["instance"]: row for row in read_csv(args.stage37_cases)}
    candidate_rows = {
        (row["instance"], row["mapping_name"]): row
        for row in read_csv(args.stage37_candidates)
    }
    missing = [case.name for case in cases if case.name not in stage37_rows]
    if missing:
        raise ValueError("Stage 37 cases CSV 缺少实例：" + ", ".join(missing))

    print("===== Stage 39：布局 × 路由 2×2 交叉分解 =====")
    print(f"输入：{args.input.resolve()}")
    print(f"实例数：{len(cases)}")
    print("OO=我们的布局+我们的路由；OQ=我们的布局+Qiskit路由")
    print("QO=Qiskit布局+我们的路由；QQ=Qiskit布局+Qiskit路由")
    print(
        f"Qiskit布局种子={args.layout_seeds}; 固定布局="
        f"{args.fixed_seeds} seeds x {args.fixed_repeats} repeats"
    )
    print(f"自研迁移策略：{[item.name for item in policies]}")
    print("本阶段只诊断，不改变任何路由或布局参数。")

    all_auto: list[stage35.AutoLayoutRow] = []
    all_transfer: list[TransferAttempt] = []
    results: list[CaseResult] = []
    for index, case in enumerate(cases, start=1):
        print(f"[{index}/{len(cases)}] {case.name} ...", flush=True)
        reference = stage37_rows[case.name]
        ours_mapping = recover_ours_mapping(
            case=case,
            stage37_row=reference,
            candidate_rows=candidate_rows,
            stage36_rows=stage36_rows,
            polish_rows=polish_rows,
            anchor_trials=args.anchor_trials,
        )

        fixed_best, fixed_budget, _fixed_attempts = (
            stage34.run_qiskit_fixed_mapping(
                case=case,
                mapping_name=reference["selected_mapping"],
                mapping=ours_mapping,
                seeds=args.fixed_seeds,
                repeats=args.fixed_repeats,
            )
        )
        if fixed_best.swap_count is None or fixed_best.weighted_depth is None:
            raise RuntimeError(f"{case.name}: 固定布局Qiskit无合法结果")

        auto_rows = stage35.generate_qiskit_layouts(case, args.layout_seeds)
        all_auto.extend(auto_rows)
        auto_best = min(auto_rows, key=stage35.auto_quality)
        auto_budget = sum(row.runtime_ms for row in auto_rows)
        qiskit_mapping = stage35.mapping_tuple(auto_best.mapping)
        qiskit_candidate = MappingCandidate(
            name=f"qiskit_auto_seed{auto_best.seed}",
            mapping=qiskit_mapping,
            generation_ms=0.0,
        )

        transfer_budget = 0.0
        transfer_valid: list[tuple] = []
        for config in policies:
            attempt = stage33.run_attempt(
                case=case,
                mapping=qiskit_candidate,
                proxy_cost=0.0,
                config=config,
            )
            transfer_budget += attempt.runtime_ms
            all_transfer.append(
                TransferAttempt(
                    instance=case.name,
                    qiskit_layout_seed=auto_best.seed,
                    mapping=auto_best.mapping,
                    policy=config.name,
                    swap=attempt.swap,
                    depth=attempt.depth,
                    runtime_ms=attempt.runtime_ms,
                    valid=attempt.valid,
                    error=attempt.error,
                )
            )
            if attempt.valid:
                transfer_valid.append(attempt)
        if not transfer_valid:
            raise RuntimeError(f"{case.name}: Qiskit布局上的自研路由全部失败")
        transfer_best = min(transfer_valid, key=stage33.quality)

        oo = int(reference["refined_swap"])
        oo_depth = int(reference["refined_depth"])
        oq = int(fixed_best.swap_count)
        qo = int(transfer_best.swap)
        qq = int(auto_best.swap)
        routing_on_ours = oo - oq
        layout_with_qiskit = oq - qq
        layout_with_ours = oo - qo
        routing_on_qiskit = qo - qq
        interaction = oo - oq - qo + qq
        shapley_layout = 0.5 * (layout_with_ours + layout_with_qiskit)
        shapley_routing = 0.5 * (routing_on_ours + routing_on_qiskit)
        total = oo - qq
        diagnosis = diagnosis_label(total, shapley_layout, shapley_routing)

        row = CaseResult(
            instance=case.name,
            topology=case.topology,
            circuit_mode=case.circuit_mode,
            logical_qubits=case.num_qubits,
            physical_qubits=case.test_case.num_physical_qubits,
            cx_count=case.two_qubit_gate_count,
            ours_layout_name=reference["selected_mapping"],
            ours_policy=reference["selected_policy"],
            cell_oo_swap=oo,
            cell_oo_depth=oo_depth,
            cell_oq_seed=int(fixed_best.seed),
            cell_oq_swap=oq,
            cell_oq_depth=int(fixed_best.weighted_depth),
            cell_oq_budget_ms=fixed_budget,
            qiskit_layout_seed=auto_best.seed,
            qiskit_layout_mapping=auto_best.mapping,
            qiskit_layout_ours_policy=transfer_best.policy,
            cell_qo_swap=qo,
            cell_qo_depth=int(transfer_best.depth),
            cell_qo_budget_ms=transfer_budget,
            cell_qq_swap=qq,
            cell_qq_depth=auto_best.depth,
            cell_qq_budget_ms=auto_budget,
            total_gap=total,
            routing_gap_on_ours_layout=routing_on_ours,
            layout_gap_with_qiskit_router=layout_with_qiskit,
            layout_gap_with_ours_router=layout_with_ours,
            routing_gap_on_qiskit_layout=routing_on_qiskit,
            interaction=interaction,
            shapley_layout=shapley_layout,
            shapley_routing=shapley_routing,
            diagnosis=diagnosis,
        )
        results.append(row)
        print(
            f"  OO={oo}/{oo_depth}, OQ={oq}/{row.cell_oq_depth}, "
            f"QO={qo}/{row.cell_qo_depth}, QQ={qq}/{row.cell_qq_depth}"
        )
        print(
            f"  total={total:+d}; Shapley layout={shapley_layout:+.1f}, "
            f"routing={shapley_routing:+.1f}; interaction={interaction:+d}; "
            f"诊断={diagnosis}"
        )

        save_csv(
            args.auto_output, all_auto, stage35.AutoLayoutRow.__annotations__.keys()
        )
        save_csv(
            args.attempt_output,
            all_transfer,
            TransferAttempt.__annotations__.keys(),
        )
        save_csv(args.case_output, results, CaseResult.__annotations__.keys())
        args.summary_output.parent.mkdir(parents=True, exist_ok=True)
        args.summary_output.write_text(
            json.dumps(summarize(results), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    summary = summarize(results)
    print("\n===== Stage 39 汇总 =====")
    print(
        f"四格 total SWAP：OO={summary['cell_oo_swap']}, "
        f"OQ={summary['cell_oq_swap']}, QO={summary['cell_qo_swap']}, "
        f"QQ={summary['cell_qq_swap']}"
    )
    print(f"总差距 OO-QQ：{summary['total_gap']:+d}")
    print(
        f"Shapley责任：layout={summary['shapley_layout']:+.1f}, "
        f"routing={summary['shapley_routing']:+.1f}"
    )
    print(f"交互项：{summary['interaction']:+d}")
    print(f"诊断计数：{summary['diagnosis_counts']}")
    print(f"Qiskit布局：{args.auto_output.resolve()}")
    print(f"迁移尝试：{args.attempt_output.resolve()}")
    print(f"逐实例：{args.case_output.resolve()}")
    print(f"汇总：{args.summary_output.resolve()}")


if __name__ == "__main__":
    main()
