from __future__ import annotations

import argparse
import csv
import json
import time
from collections import Counter
from dataclasses import asdict, dataclass
from pathlib import Path

import stage20_score_structure_ablation as stage20
import stage21_policy_portfolio as stage21
import stage33_large_topology_probe as stage33

from stage7_initial_mapping_pool import MappingCandidate, build_interaction_matrices
from stage10_dev_benchmark import DevCase, load_cases


@dataclass
class CandidateRow:
    instance: str
    mapping_name: str
    mutation: str
    mapping: str
    proxy_all: float
    proxy_early: float
    proxy_late: float
    proxy_blend: float
    selected_by: str
    selected_for_route: bool


@dataclass
class AttemptRow:
    instance: str
    mapping_name: str
    mutation: str
    policy: str
    swap: int | None
    depth: int | None
    runtime_ms: float
    valid: bool
    error: str


@dataclass
class CaseResult:
    instance: str
    topology: str
    circuit_mode: str
    logical_qubits: int
    physical_qubits: int
    cx_count: int
    neighbors_generated: int
    neighbors_routed: int
    proxy_top: int
    early_weight: float
    local_policies: str

    stage36_mapping: str
    stage36_policy: str
    stage36_swap: int
    stage36_depth: int

    selected_mapping: str
    selected_mutation: str
    selected_policy: str
    refined_swap: int
    refined_depth: int
    improvement: int
    local_budget_ms: float

    lightsabre_seed: int
    lightsabre_swap: int
    lightsabre_depth: int
    swap_gap: int
    depth_gap: int
    outcome: str


def read_csv(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        raise FileNotFoundError(f"找不到文件：{path.resolve()}")
    with path.open("r", encoding="utf-8-sig", newline="") as file:
        return list(csv.DictReader(file))


def mapping_text(mapping: tuple[int, ...]) -> str:
    return ",".join(str(value) for value in mapping)


def parse_mapping(text: str) -> tuple[int, ...]:
    return tuple(int(value) for value in text.split(",") if value.strip())


def save_csv(path: Path, rows: list, fields) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=fields)
        writer.writeheader()
        writer.writerows(asdict(row) for row in rows)


def recover_stage36_mapping(
    case: DevCase,
    case_row: dict[str, str],
    polish_rows: list[dict[str, str]],
    anchor_trials: int,
) -> tuple[int, ...]:
    selected_name = case_row["selected_mapping"]
    for row in polish_rows:
        if row.get("instance") != case.name or row.get("direction") != "backward":
            continue
        candidate_name = (
            f"{row['initial_mapping']}_fb_{row['policy']}_r"
            f"{int(row['round_index'])}"
        )
        if candidate_name == selected_name:
            mapping = parse_mapping(row["end_mapping"])
            if len(mapping) != case.num_qubits:
                raise ValueError(f"{case.name}: Stage 36 映射长度不正确")
            return mapping

    pool, _ = stage33.compact_mapping_pool(case, anchor_trials)
    matches = [item.mapping for item, _ in pool if item.name == selected_name]
    if len(matches) == 1:
        return matches[0]
    raise ValueError(
        f"{case.name}: 无法从 Stage 36 CSV 恢复映射 {selected_name}；"
        "请确认 cases 与 polish CSV 来自同一次 Stage 36 运行"
    )


def build_neighbors(
    case: DevCase,
    parent: tuple[int, ...],
) -> dict[tuple[int, ...], str]:
    _dag, hardware, _ = case.test_case.build()
    occupied = set(parent)
    boundary = sorted(
        {
            neighbor
            for physical in occupied
            for neighbor in hardware.adjacency[physical]
            if neighbor not in occupied
        }
    )
    candidates: dict[tuple[int, ...], str] = {}

    for left in range(len(parent)):
        for right in range(left + 1, len(parent)):
            mapping = list(parent)
            mapping[left], mapping[right] = mapping[right], mapping[left]
            candidates[tuple(mapping)] = f"swap_q{left}_{right}"

    for logical in range(len(parent)):
        for physical in boundary:
            mapping = list(parent)
            mapping[logical] = physical
            candidates[tuple(mapping)] = f"move_q{logical}_p{physical}"

    return candidates


def proxy_rows(
    case: DevCase,
    neighbors: dict[tuple[int, ...], str],
    proxy_top: int,
    early_weight: float,
) -> tuple[list[CandidateRow], dict[tuple[int, ...], set[str]]]:
    dag, hardware, _ = case.test_case.build()
    distances = stage33.all_pairs_distances(hardware)
    matrices = build_interaction_matrices(dag)
    scores: dict[tuple[int, ...], dict[str, float]] = {}
    for mapping in neighbors:
        all_cost = stage33.matrix_cost(mapping, matrices["all"], distances)
        early_cost = stage33.matrix_cost(mapping, matrices["early"], distances)
        late_cost = stage33.matrix_cost(mapping, matrices["late"], distances)
        scores[mapping] = {
            "all": all_cost,
            "early": early_cost,
            "late": late_cost,
            "blend": all_cost + early_weight * early_cost,
        }

    selected: dict[tuple[int, ...], set[str]] = {}
    for proxy_name in ("all", "early", "late", "blend"):
        ranked = sorted(
            neighbors,
            key=lambda mapping: (
                scores[mapping][proxy_name],
                neighbors[mapping],
                mapping,
            ),
        )
        for mapping in ranked[:proxy_top]:
            selected.setdefault(mapping, set()).add(proxy_name)

    rows: list[CandidateRow] = []
    for index, mapping in enumerate(
        sorted(neighbors, key=lambda item: (neighbors[item], item))
    ):
        mutation = neighbors[mapping]
        rows.append(
            CandidateRow(
                instance=case.name,
                mapping_name=f"stage37_n{index}_{mutation}",
                mutation=mutation,
                mapping=mapping_text(mapping),
                proxy_all=scores[mapping]["all"],
                proxy_early=scores[mapping]["early"],
                proxy_late=scores[mapping]["late"],
                proxy_blend=scores[mapping]["blend"],
                selected_by=",".join(sorted(selected.get(mapping, set()))),
                selected_for_route=mapping in selected,
            )
        )
    return rows, selected


def quality(swap: int, depth: int) -> tuple[int, int]:
    return swap, depth


def outcome_text(
    ours: tuple[int, int], lightsabre: tuple[int, int]
) -> str:
    if ours < lightsabre:
        return "OAABR胜"
    if ours == lightsabre:
        return "平局"
    return "LightSABRE胜"


def summarize(rows: list[CaseResult]) -> dict:
    stage36_swap = sum(row.stage36_swap for row in rows)
    refined_swap = sum(row.refined_swap for row in rows)
    lightsabre_swap = sum(row.lightsabre_swap for row in rows)
    outcomes = Counter(row.outcome for row in rows)
    return {
        "case_count": len(rows),
        "stage36_swap": stage36_swap,
        "refined_swap": refined_swap,
        "improvement": stage36_swap - refined_swap,
        "lightsabre_swap": lightsabre_swap,
        "swap_gap": refined_swap - lightsabre_swap,
        "wins": outcomes["OAABR胜"],
        "ties": outcomes["平局"],
        "losses": outcomes["LightSABRE胜"],
        "local_budget_ms": sum(row.local_budget_ms for row in rows),
    }


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Stage 37：Stage 36 布局的代理筛选局部精修"
    )
    parser.add_argument(
        "--input", type=Path, default=Path("data/benchmarks_large_v1/probe.json")
    )
    parser.add_argument("--case-indices", type=str, default="3,6")
    parser.add_argument(
        "--stage36-cases", type=Path,
        default=Path("results/stage36_cases.csv"),
    )
    parser.add_argument(
        "--stage36-polish", type=Path,
        default=Path("results/stage36_polish.csv"),
    )
    parser.add_argument("--anchor-trials", type=int, default=4)
    parser.add_argument("--proxy-top", type=int, default=5)
    parser.add_argument("--early-weight", type=float, default=2.0)
    parser.add_argument("--local-policies", type=str, default="front_sum")
    parser.add_argument(
        "--candidate-output", type=Path,
        default=Path("results/stage37_candidates.csv"),
    )
    parser.add_argument(
        "--attempt-output", type=Path,
        default=Path("results/stage37_attempts.csv"),
    )
    parser.add_argument(
        "--case-output", type=Path,
        default=Path("results/stage37_cases.csv"),
    )
    parser.add_argument(
        "--summary-output", type=Path,
        default=Path("results/stage37_summary.json"),
    )
    args = parser.parse_args()
    if args.proxy_top <= 0 or args.anchor_trials <= 0:
        raise ValueError("proxy-top 与 anchor-trials 必须为正数")
    if args.early_weight < 0:
        raise ValueError("early-weight 必须非负")

    stage33.configure_router()
    local_policies = stage33.parse_policies(args.local_policies)
    cases = stage21.choose_cases(
        load_cases(args.input, limit=None),
        stage21.parse_indices(args.case_indices),
        None,
    )
    stage36_rows = {row["instance"]: row for row in read_csv(args.stage36_cases)}
    polish_rows = read_csv(args.stage36_polish)
    missing = [case.name for case in cases if case.name not in stage36_rows]
    if missing:
        raise ValueError("Stage 36 cases CSV 缺少实例：" + ", ".join(missing))

    print("===== Stage 37：代理筛选局部布局精修 =====")
    print(f"输入：{args.input.resolve()}")
    print(f"实例数：{len(cases)}")
    print(f"Stage 36 cases：{args.stage36_cases.resolve()}")
    print(f"Stage 36 polish：{args.stage36_polish.resolve()}")
    print(
        f"代理：all/early/late/blend，每类 top={args.proxy_top}, "
        f"early-weight={args.early_weight}"
    )
    print(f"局部真实路由策略：{[item.name for item in local_policies]}")
    print("原 Stage 36 布局始终保留；本阶段不重新调用 Qiskit。")

    all_candidates: list[CandidateRow] = []
    all_attempts: list[AttemptRow] = []
    results: list[CaseResult] = []
    for case_index, case in enumerate(cases, start=1):
        print(f"[{case_index}/{len(cases)}] {case.name} ...", flush=True)
        reference = stage36_rows[case.name]
        parent = recover_stage36_mapping(
            case, reference, polish_rows, args.anchor_trials
        )
        neighbors = build_neighbors(case, parent)
        candidate_rows, selected = proxy_rows(
            case, neighbors, args.proxy_top, args.early_weight
        )
        all_candidates.extend(candidate_rows)
        by_mapping = {
            parse_mapping(row.mapping): row for row in candidate_rows
        }

        baseline = (
            int(reference["fb_swap"]),
            int(reference["fb_depth"]),
            reference["selected_mapping"],
            "stage36_fallback",
            reference["selected_policy"],
        )
        valid_results = [baseline]
        local_budget_ms = 0.0
        for mapping in sorted(selected, key=lambda item: (by_mapping[item].mutation, item)):
            candidate_row = by_mapping[mapping]
            candidate = MappingCandidate(
                name=candidate_row.mapping_name,
                mapping=mapping,
                generation_ms=0.0,
            )
            for config in local_policies:
                attempt = stage33.run_attempt(case, candidate, 0.0, config)
                local_budget_ms += attempt.runtime_ms
                all_attempts.append(
                    AttemptRow(
                        instance=case.name,
                        mapping_name=candidate.name,
                        mutation=candidate_row.mutation,
                        policy=config.name,
                        swap=attempt.swap,
                        depth=attempt.depth,
                        runtime_ms=attempt.runtime_ms,
                        valid=attempt.valid,
                        error=attempt.error,
                    )
                )
                if attempt.valid:
                    valid_results.append(
                        (
                            int(attempt.swap),
                            int(attempt.depth),
                            candidate.name,
                            candidate_row.mutation,
                            config.name,
                        )
                    )

        best = min(valid_results, key=lambda row: (row[0], row[1], row[2], row[4]))
        lightsabre = (
            int(reference["lightsabre_swap"]),
            int(reference["lightsabre_depth"]),
        )
        ours = (best[0], best[1])
        row = CaseResult(
            instance=case.name,
            topology=case.topology,
            circuit_mode=case.circuit_mode,
            logical_qubits=case.num_qubits,
            physical_qubits=case.test_case.num_physical_qubits,
            cx_count=case.two_qubit_gate_count,
            neighbors_generated=len(neighbors),
            neighbors_routed=len(selected),
            proxy_top=args.proxy_top,
            early_weight=args.early_weight,
            local_policies=",".join(item.name for item in local_policies),
            stage36_mapping=reference["selected_mapping"],
            stage36_policy=reference["selected_policy"],
            stage36_swap=int(reference["fb_swap"]),
            stage36_depth=int(reference["fb_depth"]),
            selected_mapping=best[2],
            selected_mutation=best[3],
            selected_policy=best[4],
            refined_swap=best[0],
            refined_depth=best[1],
            improvement=int(reference["fb_swap"]) - best[0],
            local_budget_ms=local_budget_ms,
            lightsabre_seed=int(reference["lightsabre_seed"]),
            lightsabre_swap=lightsabre[0],
            lightsabre_depth=lightsabre[1],
            swap_gap=best[0] - lightsabre[0],
            depth_gap=best[1] - lightsabre[1],
            outcome=outcome_text(ours, lightsabre),
        )
        results.append(row)
        print(
            f"  Stage36={row.stage36_swap}/{row.stage36_depth}, "
            f"refined={row.refined_swap}/{row.refined_depth} "
            f"({row.selected_mutation}, {row.selected_policy}), "
            f"DeltaSWAP=-{row.improvement}"
        )
        print(
            f"  LightSABRE={row.lightsabre_swap}/{row.lightsabre_depth}, "
            f"gap={row.swap_gap:+d}, {row.outcome}, "
            f"neighbors={row.neighbors_generated}/{row.neighbors_routed}, "
            f"budget={row.local_budget_ms:.1f} ms"
        )

        save_csv(
            args.candidate_output,
            all_candidates,
            CandidateRow.__annotations__.keys(),
        )
        save_csv(
            args.attempt_output,
            all_attempts,
            AttemptRow.__annotations__.keys(),
        )
        save_csv(args.case_output, results, CaseResult.__annotations__.keys())
        args.summary_output.parent.mkdir(parents=True, exist_ok=True)
        args.summary_output.write_text(
            json.dumps(summarize(results), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    summary = summarize(results)
    print("\n===== Stage 37 汇总 =====")
    print(f"Stage 36 total SWAP：{summary['stage36_swap']}")
    print(f"Stage 37 total SWAP：{summary['refined_swap']}")
    print(f"局部精修减少：{summary['improvement']}")
    print(f"LightSABRE total SWAP：{summary['lightsabre_swap']}")
    print(f"相对 LightSABRE gap：{summary['swap_gap']:+d}")
    print(
        f"逐实例胜/平/负：{summary['wins']}/"
        f"{summary['ties']}/{summary['losses']}"
    )
    print(f"局部搜索总预算：{summary['local_budget_ms']:.1f} ms")
    print(f"候选明细：{args.candidate_output.resolve()}")
    print(f"真实路由：{args.attempt_output.resolve()}")
    print(f"逐实例：{args.case_output.resolve()}")
    print(f"汇总：{args.summary_output.resolve()}")


if __name__ == "__main__":
    main()
