from __future__ import annotations

import argparse
import json
from collections import Counter
from dataclasses import asdict, replace
from pathlib import Path

import stage16_generate_benchmark_v3 as stage16


SCHEMA_VERSION = 4
DEFAULT_MASTER_SEED = 20260727
DEFAULT_SPLIT_OFFSET = 1
DEFAULT_QUBIT_OFFSET = 0


def choose_split(
    topology_index: int,
    circuit_mode_index: int,
    length_factor_index: int,
    split_offset: int,
) -> str:
    residue = (
        topology_index
        + circuit_mode_index
        + length_factor_index
        + split_offset
    ) % 4
    if residue in (0, 1):
        return "dev"
    if residue == 2:
        return "validation"
    return "test"


def choose_num_qubits(
    circuit_mode_index: int,
    length_factor_index: int,
    qubit_offset: int,
) -> int:
    index = (
        circuit_mode_index
        + length_factor_index
        + qubit_offset
    ) % len(stage16.QUBIT_SIZES)
    return stage16.QUBIT_SIZES[index]


def build_profiles(
    split_offset: int,
    qubit_offset: int,
) -> list[stage16.StratifiedProfile]:
    profiles: list[stage16.StratifiedProfile] = []
    profile_id = 0

    for topology_index, topology in enumerate(stage16.TOPOLOGIES):
        for circuit_mode_index, circuit_mode in enumerate(
            stage16.CIRCUIT_MODES
        ):
            for length_factor_index, length_factor in enumerate(
                stage16.LENGTH_FACTORS
            ):
                profiles.append(
                    stage16.StratifiedProfile(
                        profile_id=profile_id,
                        topology_index=topology_index,
                        circuit_mode_index=circuit_mode_index,
                        length_factor_index=length_factor_index,
                        topology=topology,
                        circuit_mode=circuit_mode,
                        length_factor=length_factor,
                        num_qubits=choose_num_qubits(
                            circuit_mode_index,
                            length_factor_index,
                            qubit_offset,
                        ),
                        split=choose_split(
                            topology_index,
                            circuit_mode_index,
                            length_factor_index,
                            split_offset,
                        ),
                    )
                )
                profile_id += 1

    return profiles


def build_v4_case(
    profile: stage16.StratifiedProfile,
    split_index: int,
    master_seed: int,
) -> stage16.StratifiedCase:
    case = stage16.build_case(profile, split_index, master_seed)
    return replace(case, name=case.name.replace("_v3_", "_v4_", 1))


def save_split(
    cases: list[stage16.StratifiedCase],
    path: Path,
    master_seed: int,
    split_offset: int,
    qubit_offset: int,
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "schema_version": SCHEMA_VERSION,
        "master_seed": master_seed,
        "case_count": len(cases),
        "design": {
            "topologies": list(stage16.TOPOLOGIES),
            "circuit_modes": list(stage16.CIRCUIT_MODES),
            "length_factors": list(stage16.LENGTH_FACTORS),
            "qubit_sizes": list(stage16.QUBIT_SIZES),
            "split_offset": split_offset,
            "qubit_offset": qubit_offset,
            "split_rule": (
                "(topology_index + circuit_mode_index + "
                "length_factor_index + split_offset) mod 4"
            ),
            "qubit_rule": (
                "(circuit_mode_index + length_factor_index + "
                "qubit_offset) mod 3"
            ),
            "two_qubit_gate_rule": (
                "two_qubit_gate_count = length_factor * num_qubits"
            ),
        },
        "cases": [stage16.case_to_dict(case) for case in cases],
    }
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def save_manifest(
    profiles: list[stage16.StratifiedProfile],
    path: Path,
    master_seed: int,
    split_offset: int,
    qubit_offset: int,
) -> None:
    payload = {
        "schema_version": SCHEMA_VERSION,
        "master_seed": master_seed,
        "split_offset": split_offset,
        "qubit_offset": qubit_offset,
        "profiles": [asdict(profile) for profile in profiles],
    }
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def print_distribution(
    split: str,
    cases: list[stage16.StratifiedCase],
) -> None:
    print(f"[{split}] 实例数：{len(cases)}")
    for field in (
        "topology",
        "circuit_mode",
        "length_factor",
        "num_qubits",
    ):
        counts = Counter(getattr(case, field) for case in cases)
        print(f"  {field}: {dict(sorted(counts.items(), key=str))}")


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Stage 27：生成 split 轮换且使用新随机种子的 Benchmark V4"
    )
    parser.add_argument(
        "--master-seed", type=int, default=DEFAULT_MASTER_SEED
    )
    parser.add_argument(
        "--split-offset", type=int, default=DEFAULT_SPLIT_OFFSET
    )
    parser.add_argument(
        "--qubit-offset", type=int, default=DEFAULT_QUBIT_OFFSET
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("data/benchmarks_v4"),
    )
    args = parser.parse_args()

    profiles = build_profiles(args.split_offset, args.qubit_offset)
    grouped = stage16.group_profiles(profiles)
    stage16.validate_stratification(grouped)

    split_cases: dict[str, list[stage16.StratifiedCase]] = {}
    for split in ("dev", "validation", "test"):
        split_cases[split] = [
            build_v4_case(profile, index, args.master_seed)
            for index, profile in enumerate(grouped[split])
        ]
        save_split(
            split_cases[split],
            args.output_dir / f"{split}.json",
            args.master_seed,
            args.split_offset,
            args.qubit_offset,
        )

    args.output_dir.mkdir(parents=True, exist_ok=True)
    save_manifest(
        profiles,
        args.output_dir / "manifest.json",
        args.master_seed,
        args.split_offset,
        args.qubit_offset,
    )

    print("===== Benchmark V4 生成完成 =====")
    print(f"输出：{args.output_dir.resolve()}")
    print(f"master seed：{args.master_seed}")
    print(f"split offset：{args.split_offset}")
    print(f"qubit offset：{args.qubit_offset}")
    for split in ("dev", "validation", "test"):
        print_distribution(split, split_cases[split])

    ring_n10_dev = [
        case
        for case in split_cases["dev"]
        if case.topology == "ring" and case.num_qubits == 10
    ]
    print("V4 dev 的 ring-n10：")
    for case in ring_n10_dev:
        print(
            f"  {case.name}: mode={case.circuit_mode}, "
            f"CX={case.two_qubit_gate_count}"
        )


if __name__ == "__main__":
    main()
