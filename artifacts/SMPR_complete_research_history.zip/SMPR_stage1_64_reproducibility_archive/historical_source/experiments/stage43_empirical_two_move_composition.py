from __future__ import annotations

import argparse
import csv
import json
import re
from dataclasses import asdict, dataclass
from pathlib import Path

import stage20_score_structure_ablation as stage20
import stage21_policy_portfolio as stage21
import stage33_large_topology_probe as stage33
import stage37_proxy_local_layout_refinement as stage37
import stage39_layout_router_cross_decomposition as stage39

from stage7_initial_mapping_pool import MappingCandidate
from stage10_dev_benchmark import load_cases


SWAP_PATTERN = re.compile(r"^swap_q(\d+)_(\d+)$")
MOVE_PATTERN = re.compile(r"^move_q(\d+)_p(\d+)$")


@dataclass
class CompositionAttempt:
    instance: str
    parent_mapping_name: str
    parent_mutation: str
    parent_swap: int
    parent_depth: int
    second_mutation: str
    composed_mapping_name: str
    mapping: str
    policy: str
    swap: int | None
    depth: int | None
    runtime_ms: float
    valid: bool
    skipped: bool
    error: str


@dataclass
class CaseResult:
    instance: str
    topology: str
    circuit_mode: str
    logical_qubits: int
    physical_qubits: int
    cx_count: int
    policy: str
    parents_requested: int
    parents_used: int
    mutation_library: int
    compositions_generated: int
    compositions_routed: int

    stage37_swap: int
    stage37_depth: int
    best_parent_mutation: str
    best_parent_swap: int
    best_parent_depth: int

    selected_mapping: str
    selected_path: str
    selected_swap: int
    selected_depth: int
    improvement: int
    route_budget_ms: float

    lightsabre_swap: int
    lightsabre_depth: int
    swap_gap: int
    depth_gap: int
    outcome: str


def read_csv(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        raise FileNotFoundError(f"找不到文件：{path.resolve()}")
    with path.open("r", encoding="utf-8-sig", newline="") as file:
        return list(csv.DictReader(file))


def save_csv(path: Path, rows: list, fields) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=fields)
        writer.writeheader()
        writer.writerows(asdict(row) for row in rows)


def apply_mutation(
    mapping: tuple[int, ...],
    mutation: str,
) -> tuple[int, ...] | None:
    swap_match = SWAP_PATTERN.match(mutation)
    if swap_match:
        left, right = (int(value) for value in swap_match.groups())
        if left >= len(mapping) or right >= len(mapping) or left == right:
            return None
        result = list(mapping)
        result[left], result[right] = result[right], result[left]
        return tuple(result)

    move_match = MOVE_PATTERN.match(mutation)
    if move_match:
        logical, physical = (int(value) for value in move_match.groups())
        if logical >= len(mapping):
            return None
        if physical in mapping and mapping[logical] != physical:
            return None
        result = list(mapping)
        result[logical] = physical
        return tuple(result)
    return None


def outcome_text(ours: tuple[int, int], qiskit: tuple[int, int]) -> str:
    if ours < qiskit:
        return "OAABR胜"
    if ours == qiskit:
        return "平局"
    return "LightSABRE胜"


def summarize(rows: list[CaseResult]) -> dict:
    old = sum(row.stage37_swap for row in rows)
    selected = sum(row.selected_swap for row in rows)
    lightsabre = sum(row.lightsabre_swap for row in rows)
    return {
        "case_count": len(rows),
        "stage37_swap": old,
        "stage43_swap": selected,
        "improvement": old - selected,
        "lightsabre_swap": lightsabre,
        "swap_gap": selected - lightsabre,
        "compositions_generated": sum(row.compositions_generated for row in rows),
        "compositions_routed": sum(row.compositions_routed for row in rows),
        "route_budget_ms": sum(row.route_budget_ms for row in rows),
    }


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Stage 43：真实标签变换库的两步布局组合搜索"
    )
    parser.add_argument(
        "--input", type=Path, default=Path("data/benchmarks_large_v1/probe.json")
    )
    parser.add_argument("--case-indices", type=str, default="7")
    parser.add_argument(
        "--stage36-cases", type=Path,
        default=Path("results/stage38_alternating_stage36_cases.csv"),
    )
    parser.add_argument(
        "--stage36-polish", type=Path,
        default=Path("results/stage38_alternating_polish.csv"),
    )
    parser.add_argument(
        "--stage37-cases", type=Path,
        default=Path("results/stage38_alternating_stage37_cases.csv"),
    )
    parser.add_argument(
        "--stage37-candidates", type=Path,
        default=Path("results/stage38_alternating_candidates.csv"),
    )
    parser.add_argument(
        "--stage42-labels", type=Path,
        default=Path("results/stage42_heron_labels.csv"),
    )
    parser.add_argument("--anchor-trials", type=int, default=4)
    parser.add_argument("--policy", type=str, default="front_sum")
    parser.add_argument("--parents", type=int, default=1)
    parser.add_argument(
        "--attempt-output", type=Path,
        default=Path("results/stage43_attempts.csv"),
    )
    parser.add_argument(
        "--case-output", type=Path,
        default=Path("results/stage43_cases.csv"),
    )
    parser.add_argument(
        "--summary-output", type=Path,
        default=Path("results/stage43_summary.json"),
    )
    args = parser.parse_args()
    if args.anchor_trials <= 0 or args.parents <= 0:
        raise ValueError("anchor-trials与parents必须为正")
    if args.policy not in stage20.CONFIG_BY_NAME:
        raise ValueError(f"未知policy：{args.policy}")

    stage33.configure_router()
    config = stage20.CONFIG_BY_NAME[args.policy]
    cases = stage21.choose_cases(
        load_cases(args.input, limit=None),
        stage21.parse_indices(args.case_indices),
        None,
    )
    stage36_rows = {row["instance"]: row for row in read_csv(args.stage36_cases)}
    polish_rows = read_csv(args.stage36_polish)
    stage37_rows = {row["instance"]: row for row in read_csv(args.stage37_cases)}
    stage37_candidates = {
        (row["instance"], row["mapping_name"]): row
        for row in read_csv(args.stage37_candidates)
    }
    label_rows = read_csv(args.stage42_labels)

    print("===== Stage 43：真实变换库两步组合搜索 =====")
    print(f"输入：{args.input.resolve()}")
    print(f"实例数：{len(cases)}")
    print(f"完整路由策略：{config.name}")
    print(f"非基线父布局数：{args.parents}")
    print("允许父布局暂时劣于基线；最终始终保留Stage 37回退。")

    all_attempts: list[CompositionAttempt] = []
    case_results: list[CaseResult] = []
    for case_index, case in enumerate(cases, start=1):
        print(f"[{case_index}/{len(cases)}] {case.name} ...", flush=True)
        if case.name not in stage37_rows:
            raise ValueError(f"Stage 37 cases CSV缺少 {case.name}")
        reference = stage37_rows[case.name]
        baseline_mapping = stage39.recover_ours_mapping(
            case=case,
            stage37_row=reference,
            candidate_rows=stage37_candidates,
            stage36_rows=stage36_rows,
            polish_rows=polish_rows,
            anchor_trials=args.anchor_trials,
        )
        labels = [row for row in label_rows if row["instance"] == case.name]
        if not labels:
            raise ValueError(f"Stage 42 labels CSV缺少 {case.name}")
        nonbaseline = sorted(
            [row for row in labels if row.get("is_baseline") != "True"],
            key=lambda row: (
                int(row["full_swap"]),
                int(row["full_depth"]),
                row["mapping_name"],
            ),
        )
        parents = nonbaseline[: args.parents]
        if not parents:
            raise ValueError(f"{case.name}: Stage 42没有非基线标签")
        mutation_library = sorted(
            {
                row["mutation"]
                for row in nonbaseline
                if SWAP_PATTERN.match(row["mutation"])
                or MOVE_PATTERN.match(row["mutation"])
            }
        )

        fallback = (
            int(reference["refined_swap"]),
            int(reference["refined_depth"]),
            reference["selected_mapping"],
            "stage37_fallback",
        )
        valid_results = [fallback]
        seen: set[tuple[int, ...]] = {baseline_mapping}
        generated = 0
        routed = 0
        budget = 0.0
        for parent_index, parent in enumerate(parents):
            parent_mapping = stage37.parse_mapping(parent["mapping"])
            parent_mutation = parent["mutation"]
            print(
                f"  parent {parent_index + 1}: {parent_mutation}, "
                f"cost={parent['full_swap']}/{parent['full_depth']}",
                flush=True,
            )
            for second_mutation in mutation_library:
                composed = apply_mutation(parent_mapping, second_mutation)
                name = (
                    f"stage43_p{parent_index}_{parent_mutation}__"
                    f"{second_mutation}"
                )
                if composed is None or composed in seen:
                    all_attempts.append(
                        CompositionAttempt(
                            instance=case.name,
                            parent_mapping_name=parent["mapping_name"],
                            parent_mutation=parent_mutation,
                            parent_swap=int(parent["full_swap"]),
                            parent_depth=int(parent["full_depth"]),
                            second_mutation=second_mutation,
                            composed_mapping_name=name,
                            mapping="" if composed is None else stage37.mapping_text(composed),
                            policy=config.name,
                            swap=None,
                            depth=None,
                            runtime_ms=0.0,
                            valid=False,
                            skipped=True,
                            error="非法、重复或回到基线的组合",
                        )
                    )
                    continue
                seen.add(composed)
                generated += 1
                candidate = MappingCandidate(name, composed, 0.0)
                attempt = stage33.run_attempt(case, candidate, 0.0, config)
                routed += 1
                budget += attempt.runtime_ms
                all_attempts.append(
                    CompositionAttempt(
                        instance=case.name,
                        parent_mapping_name=parent["mapping_name"],
                        parent_mutation=parent_mutation,
                        parent_swap=int(parent["full_swap"]),
                        parent_depth=int(parent["full_depth"]),
                        second_mutation=second_mutation,
                        composed_mapping_name=name,
                        mapping=stage37.mapping_text(composed),
                        policy=config.name,
                        swap=attempt.swap,
                        depth=attempt.depth,
                        runtime_ms=attempt.runtime_ms,
                        valid=attempt.valid,
                        skipped=False,
                        error=attempt.error,
                    )
                )
                if attempt.valid:
                    valid_results.append(
                        (
                            int(attempt.swap),
                            int(attempt.depth),
                            name,
                            f"{parent_mutation} -> {second_mutation}",
                        )
                    )
                if routed % 5 == 0:
                    best_so_far = min(valid_results, key=lambda row: (row[0], row[1], row[2]))
                    print(
                        f"    routed={routed}, best={best_so_far[0]}/"
                        f"{best_so_far[1]}",
                        flush=True,
                    )

        best = min(valid_results, key=lambda row: (row[0], row[1], row[2]))
        best_parent = parents[0]
        lightsabre = (
            int(reference["lightsabre_swap"]),
            int(reference["lightsabre_depth"]),
        )
        ours = (best[0], best[1])
        result = CaseResult(
            instance=case.name,
            topology=case.topology,
            circuit_mode=case.circuit_mode,
            logical_qubits=case.num_qubits,
            physical_qubits=case.test_case.num_physical_qubits,
            cx_count=case.two_qubit_gate_count,
            policy=config.name,
            parents_requested=args.parents,
            parents_used=len(parents),
            mutation_library=len(mutation_library),
            compositions_generated=generated,
            compositions_routed=routed,
            stage37_swap=int(reference["refined_swap"]),
            stage37_depth=int(reference["refined_depth"]),
            best_parent_mutation=best_parent["mutation"],
            best_parent_swap=int(best_parent["full_swap"]),
            best_parent_depth=int(best_parent["full_depth"]),
            selected_mapping=best[2],
            selected_path=best[3],
            selected_swap=best[0],
            selected_depth=best[1],
            improvement=int(reference["refined_swap"]) - best[0],
            route_budget_ms=budget,
            lightsabre_swap=lightsabre[0],
            lightsabre_depth=lightsabre[1],
            swap_gap=best[0] - lightsabre[0],
            depth_gap=best[1] - lightsabre[1],
            outcome=outcome_text(ours, lightsabre),
        )
        case_results.append(result)
        print(
            f"  Stage37={result.stage37_swap}/{result.stage37_depth}, "
            f"Stage43={result.selected_swap}/{result.selected_depth}, "
            f"path={result.selected_path}, DeltaSWAP=-{result.improvement}"
        )
        print(
            f"  LightSABRE={result.lightsabre_swap}/{result.lightsabre_depth}, "
            f"gap={result.swap_gap:+d}, {result.outcome}, "
            f"budget={result.route_budget_ms:.1f} ms"
        )

        save_csv(
            args.attempt_output,
            all_attempts,
            CompositionAttempt.__annotations__.keys(),
        )
        save_csv(args.case_output, case_results, CaseResult.__annotations__.keys())
        args.summary_output.parent.mkdir(parents=True, exist_ok=True)
        args.summary_output.write_text(
            json.dumps(summarize(case_results), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    summary = summarize(case_results)
    print("\n===== Stage 43 汇总 =====")
    print(f"Stage 37 total SWAP：{summary['stage37_swap']}")
    print(f"Stage 43 total SWAP：{summary['stage43_swap']}")
    print(f"两步组合减少：{summary['improvement']}")
    print(f"LightSABRE total SWAP：{summary['lightsabre_swap']}")
    print(f"相对 LightSABRE gap：{summary['swap_gap']:+d}")
    print(
        f"组合 generated/routed：{summary['compositions_generated']}/"
        f"{summary['compositions_routed']}"
    )
    print(f"完整路由预算：{summary['route_budget_ms']:.1f} ms")
    print(f"组合尝试：{args.attempt_output.resolve()}")
    print(f"逐实例：{args.case_output.resolve()}")
    print(f"汇总：{args.summary_output.resolve()}")


if __name__ == "__main__":
    main()
