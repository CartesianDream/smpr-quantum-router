from __future__ import annotations

import argparse
import csv
import json
import re
import time
from collections import Counter
from dataclasses import asdict, dataclass
from pathlib import Path

try:
    from qiskit import qasm3, qpy, transpile
except ModuleNotFoundError:
    qasm3 = None
    qpy = None
    transpile = None

import stage21_policy_portfolio as stage21

from stage6_fixed_layout_benchmark import (
    build_coupling_map,
    build_qiskit_circuit,
    weighted_qiskit_depth,
)
from stage10_dev_benchmark import DevCase, load_cases


@dataclass
class AttemptRow:
    instance: str
    seed: int
    repeat: int
    raw_swap: int | None
    raw_depth: int | None
    optimized_cx: int | None
    optimized_total_gates: int | None
    optimized_depth: int | None
    effective_added_cx: int | None
    effective_added_total_basis_gates: int | None
    runtime_ms: float
    valid: bool
    error: str


@dataclass
class CaseRow:
    instance: str
    topology: str
    circuit_mode: str
    logical_qubits: int
    physical_qubits: int
    logical_gate_count: int
    logical_basis_cx: int
    logical_basis_total_gates: int
    best_seed: int
    best_repeat: int
    raw_swap: int
    raw_depth: int
    optimized_cx: int
    optimized_total_gates: int
    optimized_depth: int
    effective_added_cx: int
    effective_added_total_basis_gates: int
    qasm_path: str
    qpy_path: str
    layout_path: str
    total_runtime_ms: float


@dataclass
class CompiledAttempt:
    row: AttemptRow
    circuit: object | None
    layout_text: str


def require_qiskit() -> None:
    if transpile is None or qasm3 is None or qpy is None:
        raise ModuleNotFoundError(
            "Stage 45 需要 Qiskit；请在项目虚拟环境中安装 qiskit"
        )


def safe_name(name: str) -> str:
    value = re.sub(r"[^A-Za-z0-9_.-]+", "_", name)
    return value.strip("._") or "circuit"


def operation_counts(circuit) -> dict[str, int]:
    return {str(name): int(count) for name, count in circuit.count_ops().items()}


def assert_topology(circuit, case: DevCase) -> None:
    _dag, hardware, _ = case.test_case.build()
    for instruction in circuit.data:
        if len(instruction.qubits) != 2:
            continue
        left = circuit.find_bit(instruction.qubits[0]).index
        right = circuit.find_bit(instruction.qubits[1]).index
        if not hardware.adjacent(left, right):
            raise AssertionError(
                f"优化后出现非法双比特边："
                f"{instruction.operation.name}({left}, {right})"
            )


def logical_basis_counts(case: DevCase) -> tuple[int, int]:
    circuit = build_qiskit_circuit(case.test_case)
    basis = transpile(circuit, basis_gates=["u", "cx"], optimization_level=0)
    counts = operation_counts(basis)
    return int(counts.get("cx", 0)), int(basis.size())


def layout_description(raw_circuit) -> str:
    layout = getattr(raw_circuit, "layout", None)
    if layout is None:
        return ""
    payload = {"repr": str(layout)}
    final_index_layout = getattr(layout, "final_index_layout", None)
    if callable(final_index_layout):
        try:
            payload["final_index_layout"] = list(final_index_layout())
        except Exception as error:
            payload["final_index_layout_error"] = (
                f"{type(error).__name__}: {error}"
            )
    return json.dumps(payload, ensure_ascii=False, indent=2)


def compile_attempt(
    case: DevCase,
    seed: int,
    repeat: int,
    optimization_level: int,
    logical_basis_cx: int,
    logical_basis_total: int,
) -> CompiledAttempt:
    start = time.perf_counter()
    try:
        logical = build_qiskit_circuit(case.test_case)
        coupling = build_coupling_map(case.test_case)

        # 先只做 LightSABRE 布局与路由，保留原始 SWAP 统计。
        raw = transpile(
            logical,
            coupling_map=coupling,
            layout_method="sabre",
            routing_method="sabre",
            optimization_level=0,
            seed_transpiler=seed,
        )
        raw_counts = operation_counts(raw)
        raw_swap = int(raw_counts.get("swap", 0))
        raw_depth = int(weighted_qiskit_depth(raw))
        layout_text = layout_description(raw)

        # raw 已是物理线路；固定恒等布局，禁止再次路由，只做基础门分解与门优化。
        optimized = transpile(
            raw,
            basis_gates=["u", "cx"],
            coupling_map=coupling,
            initial_layout=list(range(raw.num_qubits)),
            layout_method="trivial",
            routing_method="none",
            optimization_level=optimization_level,
            seed_transpiler=seed,
        )
        assert_topology(optimized, case)
        counts = operation_counts(optimized)
        if int(counts.get("swap", 0)) != 0:
            raise AssertionError("优化后仍含 SWAP，基础门分解没有完成")

        optimized_cx = int(counts.get("cx", 0))
        optimized_total = int(optimized.size())
        row = AttemptRow(
            instance=case.name,
            seed=seed,
            repeat=repeat,
            raw_swap=raw_swap,
            raw_depth=raw_depth,
            optimized_cx=optimized_cx,
            optimized_total_gates=optimized_total,
            optimized_depth=int(optimized.depth()),
            effective_added_cx=optimized_cx - logical_basis_cx,
            effective_added_total_basis_gates=(
                optimized_total - logical_basis_total
            ),
            runtime_ms=(time.perf_counter() - start) * 1000.0,
            valid=True,
            error="",
        )
        return CompiledAttempt(row, optimized, layout_text)
    except Exception as error:
        row = AttemptRow(
            instance=case.name,
            seed=seed,
            repeat=repeat,
            raw_swap=None,
            raw_depth=None,
            optimized_cx=None,
            optimized_total_gates=None,
            optimized_depth=None,
            effective_added_cx=None,
            effective_added_total_basis_gates=None,
            runtime_ms=(time.perf_counter() - start) * 1000.0,
            valid=False,
            error=f"{type(error).__name__}: {error}",
        )
        return CompiledAttempt(row, None, "")


def attempt_key(attempt: CompiledAttempt) -> tuple:
    row = attempt.row
    if not row.valid:
        return (10**18,) * 7
    return (
        int(row.optimized_cx),
        int(row.optimized_depth),
        int(row.optimized_total_gates),
        int(row.raw_swap),
        row.runtime_ms,
        row.seed,
        row.repeat,
    )


def save_csv(path: Path, rows: list, fields) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=fields)
        writer.writeheader()
        writer.writerows(asdict(row) for row in rows)


def export_best(
    attempt: CompiledAttempt,
    output_dir: Path,
    instance: str,
) -> tuple[Path, Path, Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    stem = safe_name(instance)
    qasm_path = output_dir / f"{stem}.qasm"
    qpy_path = output_dir / f"{stem}.qpy"
    layout_path = output_dir / f"{stem}.layout.json"

    qasm_path.write_text(qasm3.dumps(attempt.circuit), encoding="utf-8")
    with qpy_path.open("wb") as file:
        qpy.dump(attempt.circuit, file)
    layout_path.write_text(attempt.layout_text, encoding="utf-8")
    return qasm_path, qpy_path, layout_path


def summarize(rows: list[CaseRow], attempts: list[AttemptRow]) -> dict:
    return {
        "case_count": len(rows),
        "selection_rule": [
            "optimized_cx",
            "optimized_depth",
            "optimized_total_gates",
            "raw_swap",
        ],
        "logical_basis_cx": sum(row.logical_basis_cx for row in rows),
        "optimized_cx": sum(row.optimized_cx for row in rows),
        "effective_added_cx": sum(row.effective_added_cx for row in rows),
        "logical_basis_total_gates": sum(
            row.logical_basis_total_gates for row in rows
        ),
        "optimized_total_gates": sum(row.optimized_total_gates for row in rows),
        "effective_added_total_basis_gates": sum(
            row.effective_added_total_basis_gates for row in rows
        ),
        "optimized_depth": sum(row.optimized_depth for row in rows),
        "raw_swap": sum(row.raw_swap for row in rows),
        "best_seed_counts": dict(Counter(row.best_seed for row in rows)),
        "attempt_count": len(attempts),
        "valid_attempt_count": sum(row.valid for row in attempts),
        "runtime_ms": sum(row.runtime_ms for row in attempts),
        "ceff_note": (
            "effective_added_cx = optimized_cx - logical_basis_cx; "
            "这是 Ncost=N2q 且 b(CX)=1 的版本，不替代未知的官方加权公式"
        ),
    }


def write_summary(
    path: Path,
    rows: list[CaseRow],
    attempts: list[AttemptRow],
) -> dict:
    result = summarize(rows, attempts)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    return result


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Stage 45：LightSABRE 路由、优化后选种子并导出 QASM/QPY"
    )
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--case-indices", type=str, default=None)
    parser.add_argument("--qiskit-seeds", type=int, default=20)
    parser.add_argument("--qiskit-repeats", type=int, default=1)
    parser.add_argument("--optimization-level", type=int, choices=(0, 1, 2, 3), default=3)
    parser.add_argument(
        "--circuit-output-dir", type=Path,
        default=Path("results/stage45_compiled_circuits"),
    )
    parser.add_argument(
        "--attempt-output", type=Path,
        default=Path("results/stage45_attempts.csv"),
    )
    parser.add_argument(
        "--case-output", type=Path,
        default=Path("results/stage45_cases.csv"),
    )
    parser.add_argument(
        "--summary-output", type=Path,
        default=Path("results/stage45_summary.json"),
    )
    args = parser.parse_args()

    require_qiskit()
    if not args.input.exists():
        raise FileNotFoundError(f"找不到输入：{args.input.resolve()}")
    if args.limit is not None and args.limit <= 0:
        raise ValueError("--limit 必须为正整数")
    if args.qiskit_seeds <= 0 or args.qiskit_repeats <= 0:
        raise ValueError("seeds/repeats 必须为正整数")

    cases = stage21.choose_cases(
        load_cases(args.input, limit=None),
        stage21.parse_indices(args.case_indices),
        args.limit,
    )
    print("===== Stage 45：LightSABRE 优化后选路与线路导出 =====")
    print(f"输入：{args.input.resolve()}")
    print(f"实例数：{len(cases)}")
    print(
        f"预算：{args.qiskit_seeds} seeds x {args.qiskit_repeats} repeats, "
        f"optimization_level={args.optimization_level}"
    )
    print("选择：optimized CX -> optimized depth -> total gates -> raw SWAP")

    attempt_rows: list[AttemptRow] = []
    case_rows: list[CaseRow] = []
    for index, case in enumerate(cases, start=1):
        dag, hardware, _ = case.test_case.build()
        logical_cx, logical_total = logical_basis_counts(case)
        local = [
            compile_attempt(
                case, seed, repeat, args.optimization_level,
                logical_cx, logical_total,
            )
            for seed in range(args.qiskit_seeds)
            for repeat in range(args.qiskit_repeats)
        ]
        attempt_rows.extend(item.row for item in local)
        valid = [item for item in local if item.row.valid]
        if not valid:
            raise RuntimeError(
                f"{case.name} 所有编译均失败："
                + " | ".join(item.row.error for item in local)
            )
        best = min(valid, key=attempt_key)
        row = best.row
        qasm_path, qpy_path, layout_path = export_best(
            best, args.circuit_output_dir, case.name
        )
        case_row = CaseRow(
            instance=case.name,
            topology=case.topology,
            circuit_mode=case.circuit_mode,
            logical_qubits=dag.num_logical_qubits,
            physical_qubits=hardware.num_qubits,
            logical_gate_count=len(dag.gates),
            logical_basis_cx=logical_cx,
            logical_basis_total_gates=logical_total,
            best_seed=row.seed,
            best_repeat=row.repeat,
            raw_swap=int(row.raw_swap),
            raw_depth=int(row.raw_depth),
            optimized_cx=int(row.optimized_cx),
            optimized_total_gates=int(row.optimized_total_gates),
            optimized_depth=int(row.optimized_depth),
            effective_added_cx=int(row.effective_added_cx),
            effective_added_total_basis_gates=int(
                row.effective_added_total_basis_gates
            ),
            qasm_path=str(qasm_path.resolve()),
            qpy_path=str(qpy_path.resolve()),
            layout_path=str(layout_path.resolve()),
            total_runtime_ms=sum(item.row.runtime_ms for item in local),
        )
        case_rows.append(case_row)
        save_csv(args.attempt_output, attempt_rows, AttemptRow.__annotations__.keys())
        save_csv(args.case_output, case_rows, CaseRow.__annotations__.keys())
        write_summary(args.summary_output, case_rows, attempt_rows)
        print(
            f"[{index}/{len(cases)}] {case.name}: seed={row.seed}, "
            f"raw={row.raw_swap}/{row.raw_depth}, "
            f"optimized CX/depth/gates="
            f"{row.optimized_cx}/{row.optimized_depth}/{row.optimized_total_gates}, "
            f"Ceff2q={row.effective_added_cx:+d}"
        )

    result = write_summary(args.summary_output, case_rows, attempt_rows)
    save_csv(args.attempt_output, attempt_rows, AttemptRow.__annotations__.keys())
    save_csv(args.case_output, case_rows, CaseRow.__annotations__.keys())
    print("\n===== Stage 45 汇总 =====")
    print(f"逻辑基础 CX：{result['logical_basis_cx']}")
    print(f"优化后 CX：{result['optimized_cx']}")
    print(f"有效附加 CX：{result['effective_added_cx']:+d}")
    print(f"优化后总深度：{result['optimized_depth']}")
    print(f"原始 SWAP：{result['raw_swap']}")
    print(f"总预算：{result['runtime_ms']:.1f} ms")
    print(f"编译线路目录：{args.circuit_output_dir.resolve()}")
    print(f"尝试明细：{args.attempt_output.resolve()}")
    print(f"逐实例结果：{args.case_output.resolve()}")
    print(f"汇总 JSON：{args.summary_output.resolve()}")


if __name__ == "__main__":
    main()
