from __future__ import annotations

import argparse
import csv
import json
import math
import random
import statistics
import time
from collections import Counter, deque
from dataclasses import asdict, dataclass
from pathlib import Path

import stage19_candidate_rollout_diagnosis as stage19

from stage1_core import (
    CircuitDAG,
    HardwareGraph,
    RoutingState,
    blocked_front_layer,
    drain,
)
from stage10_dev_benchmark import DevCase, load_cases
from stage21_policy_portfolio import parse_indices


EPSILON = 1e-10
INF = 10**18


@dataclass
class SimpleTESRun:
    instance: str
    seed: int
    mapping: str
    layout_score: int
    swap: int
    depth: int
    runtime_ms: float
    valid: bool
    error: str


@dataclass
class ThreeWayCase:
    instance: str
    topology: str
    circuit_mode: str
    num_qubits: int
    cx_count: int
    oaabr_swap: int
    oaabr_depth: int
    lightsabre_swap: int
    lightsabre_depth: int
    simpletes_seed: int
    simpletes_swap: int
    simpletes_depth: int
    simpletes_layout_score: int
    simpletes_runtime_ms: float
    oaabr_minus_lightsabre: int
    oaabr_minus_simpletes: int
    simpletes_minus_lightsabre: int


def normalize_edge(edge: tuple[int, int]) -> tuple[int, int]:
    return tuple(sorted(edge))


def choose_cases(
    cases: list[DevCase],
    indices: list[int] | None,
    limit: int | None,
) -> list[DevCase]:
    if indices:
        return [cases[index] for index in indices]
    if limit is not None:
        return cases[:limit]
    return cases


def all_distances(hardware: HardwareGraph) -> list[list[int]]:
    return [
        [
            0 if i == j else len(hardware.shortest_path(i, j)) - 1
            for j in range(hardware.num_qubits)
        ]
        for i in range(hardware.num_qubits)
    ]


def interaction_weights(dag: CircuitDAG) -> list[list[int]]:
    n = dag.num_logical_qubits
    weights = [[0] * n for _ in range(n)]
    for gate in dag.gates:
        if gate.is_two_qubit:
            a, b = gate.qubits
            weights[a][b] += 1
            weights[b][a] += 1
    return weights


def logical_components(weights: list[list[int]]) -> list[list[int]]:
    n = len(weights)
    unseen = set(range(n))
    output: list[list[int]] = []
    while unseen:
        start = min(unseen)
        unseen.remove(start)
        queue = deque([start])
        component: list[int] = []
        while queue:
            node = queue.popleft()
            component.append(node)
            for neighbor, value in enumerate(weights[node]):
                if value and neighbor in unseen:
                    unseen.remove(neighbor)
                    queue.append(neighbor)
        output.append(sorted(component))
    return output


def physical_components(hardware: HardwareGraph) -> list[list[int]]:
    unseen = set(range(hardware.num_qubits))
    output: list[list[int]] = []
    while unseen:
        start = min(unseen)
        unseen.remove(start)
        queue = deque([start])
        component: list[int] = []
        while queue:
            node = queue.popleft()
            component.append(node)
            for neighbor in sorted(hardware.adjacency[node]):
                if neighbor in unseen:
                    unseen.remove(neighbor)
                    queue.append(neighbor)
        output.append(sorted(component))
    return output


def connected_dense_subset(
    component: list[int],
    size: int,
    hardware: HardwareGraph,
    distances: list[list[int]],
) -> list[int]:
    """Deterministic substitute for the scaffold's dense_layout::best_subset.

    It is exact when ``size == len(component)``, which covers all V5 cases.
    For larger chips it grows a connected subset from the most central node.
    """
    if size > len(component):
        raise ValueError("logical component does not fit physical component")
    if size == len(component):
        return list(component)
    seed = min(
        component,
        key=lambda p: (
            sum(distances[p][q] for q in component),
            -len(hardware.adjacency[p]),
            p,
        ),
    )
    chosen = {seed}
    while len(chosen) < size:
        frontier = {
            neighbor
            for node in chosen
            for neighbor in hardware.adjacency[node]
            if neighbor in component and neighbor not in chosen
        }
        if not frontier:
            raise ValueError("failed to grow connected layout subset")
        candidate = min(
            frontier,
            key=lambda p: (
                sum(distances[p][q] for q in chosen),
                -len(hardware.adjacency[p]),
                p,
            ),
        )
        chosen.add(candidate)
    return sorted(chosen)


def deterministic_greedy_layout(
    dag: CircuitDAG,
    hardware: HardwareGraph,
    weights: list[list[int]],
    distances: list[list[int]],
) -> list[int]:
    logical = sorted(logical_components(weights), key=lambda c: (-len(c), c))
    physical = physical_components(hardware)
    order = sorted(range(len(physical)), key=lambda i: (-len(physical[i]), i))
    capacity = {index: len(physical[index]) for index in order}
    assignments: list[tuple[list[int], int]] = []
    for component in logical:
        target = next(
            (index for index in order if capacity[index] >= len(component)),
            None,
        )
        if target is None:
            raise ValueError("logical component cannot fit topology")
        capacity[target] -= len(component)
        assignments.append((component, target))

    mapping = [-1] * dag.num_logical_qubits
    globally_used: set[int] = set()
    logical_degree = [sum(row) for row in weights]
    for component, target_index in assignments:
        available_component = [
            p for p in physical[target_index] if p not in globally_used
        ]
        subset = connected_dense_subset(
            available_component,
            len(component),
            hardware,
            distances,
        )
        available = set(subset)
        placed: dict[int, int] = {}
        seed_logical = min(component, key=lambda q: (-logical_degree[q], q))
        seed_physical = min(
            available,
            key=lambda p: (
                sum(distances[p]),
                -len(hardware.adjacency[p]),
                p,
            ),
        )
        placed[seed_logical] = seed_physical
        available.remove(seed_physical)
        while len(placed) < len(component):
            remaining = [q for q in component if q not in placed]
            logical = min(
                remaining,
                key=lambda q: (
                    -sum(weights[q][other] for other in placed),
                    q,
                ),
            )
            physical_node = min(
                available,
                key=lambda p: (
                    sum(
                        weights[logical][other] * distances[p][placed_p]
                        for other, placed_p in placed.items()
                    ),
                    p,
                ),
            )
            placed[logical] = physical_node
            available.remove(physical_node)
        for logical, physical_node in placed.items():
            mapping[logical] = physical_node
            globally_used.add(physical_node)

    free = [p for p in range(hardware.num_qubits) if p not in globally_used]
    for logical, physical_node in enumerate(mapping):
        if physical_node < 0:
            mapping[logical] = free.pop(0)
    return mapping


def layout_score(
    layout: list[int],
    weights: list[list[int]],
    distances: list[list[int]],
) -> int:
    return sum(
        weights[i][j] * distances[layout[i]][layout[j]]
        for i in range(len(layout))
        for j in range(i + 1, len(layout))
    )


def swap_delta(
    layout: list[int],
    i: int,
    j: int,
    weights: list[list[int]],
    distances: list[list[int]],
) -> int:
    if i == j:
        return 0
    pi, pj = layout[i], layout[j]
    delta = 0
    for k in range(len(layout)):
        if k == i or k == j:
            continue
        pk = layout[k]
        delta += weights[i][k] * (distances[pj][pk] - distances[pi][pk])
        delta += weights[j][k] * (distances[pi][pk] - distances[pj][pk])
    return delta


def move_delta(
    layout: list[int],
    logical: int,
    new_physical: int,
    weights: list[list[int]],
    distances: list[list[int]],
) -> int:
    old = layout[logical]
    return sum(
        weights[logical][other]
        * (distances[new_physical][layout[other]] - distances[old][layout[other]])
        for other in range(len(layout))
        if other != logical
    )


def hill_climb(
    layout: list[int],
    score: int,
    physical_count: int,
    weights: list[list[int]],
    distances: list[list[int]],
    rng: random.Random,
    trials: int,
) -> tuple[list[int], int]:
    layout = list(layout)
    free = [p for p in range(physical_count) if p not in set(layout)]
    n = len(layout)
    if n <= 1:
        return layout, score
    for _ in range(trials):
        if free and rng.random() < 0.5:
            logical = rng.randrange(n)
            free_index = rng.randrange(len(free))
            new_physical = free[free_index]
            delta = move_delta(layout, logical, new_physical, weights, distances)
            if delta < 0:
                old = layout[logical]
                layout[logical] = new_physical
                free[free_index] = old
                score += delta
        else:
            i = rng.randrange(n)
            j = rng.randrange(n - 1)
            if j >= i:
                j += 1
            delta = swap_delta(layout, i, j, weights, distances)
            if delta < 0:
                layout[i], layout[j] = layout[j], layout[i]
                score += delta
    return layout, score


def simpletes_initial_layout(
    dag: CircuitDAG,
    hardware: HardwareGraph,
    rng: random.Random,
    restarts: int,
    trials: int,
) -> tuple[list[int], int, list[list[int]]]:
    distances = all_distances(hardware)
    weights = interaction_weights(dag)
    deterministic = deterministic_greedy_layout(
        dag, hardware, weights, distances
    )
    best_layout, best_score = hill_climb(
        deterministic,
        layout_score(deterministic, weights, distances),
        hardware.num_qubits,
        weights,
        distances,
        rng,
        trials,
    )
    candidates = [(list(best_layout), best_score)]
    physical = list(range(hardware.num_qubits))
    for _ in range(restarts):
        rng.shuffle(physical)
        random_layout = list(physical[: dag.num_logical_qubits])
        candidate = hill_climb(
            random_layout,
            layout_score(random_layout, weights, distances),
            hardware.num_qubits,
            weights,
            distances,
            rng,
            trials,
        )
        candidates.append(candidate)
    best_layout, best_score = min(candidates, key=lambda item: item[1])
    best_layout, best_score = hill_climb(
        best_layout,
        best_score,
        hardware.num_qubits,
        weights,
        distances,
        rng,
        trials,
    )

    if len(best_layout) <= 200:
        for _ in range(45):
            improved = False
            for i in range(len(best_layout)):
                for j in range(i + 1, len(best_layout)):
                    delta = swap_delta(
                        best_layout, i, j, weights, distances
                    )
                    if delta < 0:
                        best_layout[i], best_layout[j] = (
                            best_layout[j],
                            best_layout[i],
                        )
                        best_score += delta
                        improved = True
            if not improved:
                break
    return best_layout, best_score, distances


def make_state(
    dag: CircuitDAG,
    hardware: HardwareGraph,
    mapping: list[int],
) -> RoutingState:
    inverse: list[int | None] = [None] * hardware.num_qubits
    for logical, physical in enumerate(mapping):
        inverse[physical] = logical
    state = RoutingState(
        logical_to_physical=list(mapping),
        physical_to_logical=inverse,
        remaining_predecessors=[
            len(dag.predecessors[gate.gate_id]) for gate in dag.gates
        ],
        physical_depth=[0] * hardware.num_qubits,
    )
    state.assert_valid(dag, hardware)
    return state


def map_swap_node(node: int, swap: tuple[int, int]) -> int:
    if node == swap[0]:
        return swap[1]
    if node == swap[1]:
        return swap[0]
    return node


def front_delta(
    front_pairs: list[tuple[int, int]],
    swap: tuple[int, int],
    distances: list[list[int]],
) -> float:
    return float(
        sum(
            distances[map_swap_node(a, swap)][map_swap_node(b, swap)]
            - distances[a][b]
            for a, b in front_pairs
        )
    )


def extended_delta(
    extended_pairs: list[tuple[int, int, float]],
    swap: tuple[int, int],
    distances: list[list[int]],
) -> float:
    total = 0.0
    for a, b, weight in extended_pairs:
        if normalize_edge((a, b)) == swap:
            continue
        new_a = map_swap_node(a, swap)
        new_b = map_swap_node(b, swap)
        total += weight * (distances[new_a][new_b] - distances[a][b])
    return total


def candidate_edges(
    hardware: HardwareGraph,
    front_pairs: list[tuple[int, int]],
    extended_pairs: list[tuple[int, int, float]],
) -> list[tuple[int, int]]:
    relevant = {
        node
        for a, b in front_pairs
        for node in (a, b)
    }
    relevant.update(
        node
        for a, b, _ in extended_pairs
        for node in (a, b)
    )
    edges = {
        normalize_edge((node, neighbor))
        for node in relevant
        for neighbor in hardware.adjacency[node]
    }
    for a, b in front_pairs:
        path = hardware.shortest_path(a, b)
        edges.update(normalize_edge(edge) for edge in zip(path, path[1:]))
    for a, b, _ in extended_pairs:
        path = hardware.shortest_path(a, b)
        edges.update(normalize_edge(edge) for edge in zip(path, path[1:]))
    return sorted(edges)


def select_simpletes_swap(
    state: RoutingState,
    dag: CircuitDAG,
    hardware: HardwareGraph,
    distances: list[list[int]],
    decay: list[float],
    swaps_since_progress: int,
    last_swap: tuple[int, int] | None,
    rng: random.Random,
) -> tuple[int, int]:
    if swaps_since_progress == 0:
        decay[:] = [1.0] * len(decay)
    elif last_swap is not None:
        if swaps_since_progress % 5 == 0:
            decay[:] = [1.0] * len(decay)
        else:
            decay[last_swap[0]] += 0.03
            decay[last_swap[1]] += 0.03

    front = blocked_front_layer(state, dag)
    horizon = stage19.dynamic_lookahead_horizon(state, dag, hardware)
    extended = stage19.build_extended_gate_order(
        state, dag, front, horizon
    )
    front_pairs = [
        (
            state.logical_to_physical[dag.gates[gate_id].qubits[0]],
            state.logical_to_physical[dag.gates[gate_id].qubits[1]],
        )
        for gate_id in front
    ]
    extended_pairs = [
        (
            state.logical_to_physical[dag.gates[gate_id].qubits[0]],
            state.logical_to_physical[dag.gates[gate_id].qubits[1]],
            0.5**index,
        )
        for index, gate_id in enumerate(extended)
    ]
    candidates = candidate_edges(
        hardware, front_pairs, extended_pairs
    )
    if not candidates:
        raise RuntimeError("SimpleTES candidate set is empty")

    ext_nodes = {
        node for a, b, _ in extended_pairs for node in (a, b)
    }
    front_nodes = {
        node for a, b in front_pairs for node in (a, b)
    }
    base = sum(distances[a][b] for a, b in front_pairs)
    base += sum(
        weight * distances[a][b]
        for a, b, weight in extended_pairs
    )
    max_before = max(
        (distances[a][b] for a, b in front_pairs),
        default=0,
    )
    best_score = math.inf
    best_swaps: list[tuple[int, int]] = []
    best_front_delta = math.inf
    best_new_max = INF
    best_new_total = math.inf

    for swap in candidates:
        delta_front = front_delta(front_pairs, swap, distances)
        if delta_front < best_front_delta:
            best_front_delta = delta_front
        delta_ext = extended_delta(extended_pairs, swap, distances)

        saved_distance = 0.0
        # This deliberately mirrors the published best.rs initialization.
        # Consequently max-distance reduction cannot become negative here.
        new_max = max_before
        for a, b in front_pairs:
            new_a = map_swap_node(a, swap)
            new_b = map_swap_node(b, swap)
            old_distance = distances[a][b]
            new_distance = distances[new_a][new_b]
            if new_distance > new_max:
                new_max = new_distance
            if old_distance > 1 and new_distance == 1:
                saved_distance += old_distance - 1
        immediate_bonus = 2.0 * saved_distance
        if new_max < max_before:
            max_term = -3.0 * (max_before - new_max)
        elif new_max > max_before:
            max_term = 0.1 * (new_max - max_before)
        else:
            max_term = 0.0

        score = base + delta_front + delta_ext + max_term - immediate_bonus
        a_active = swap[0] in front_nodes
        b_active = swap[1] in front_nodes
        if a_active and b_active:
            score += 0.03
        elif swap[0] in ext_nodes or swap[1] in ext_nodes:
            score += 0.015
        else:
            score += 0.005
        if last_swap is not None and swap == last_swap:
            score += 2.5
        score *= max(decay[swap[0]], decay[swap[1]])

        if score + EPSILON < best_score:
            best_score = score
            best_swaps = [swap]
            best_front_delta = delta_front
            best_new_max = new_max
            best_new_total = base + delta_front + delta_ext - immediate_bonus
        elif abs(score - best_score) <= EPSILON:
            new_total = base + delta_front + delta_ext - immediate_bonus
            if new_max < best_new_max:
                best_swaps = [swap]
                best_new_max = new_max
                best_new_total = new_total
            elif new_max == best_new_max and new_total < best_new_total:
                best_swaps = [swap]
                best_new_total = new_total

    if best_front_delta >= -EPSILON and front_pairs:
        farthest = max(
            front_pairs,
            key=lambda pair: distances[pair[0]][pair[1]],
        )
        if distances[farthest[0]][farthest[1]] > 1:
            path = hardware.shortest_path(farthest[0], farthest[1])
            return normalize_edge((path[0], path[1]))
    return rng.choice(best_swaps)


def run_simpletes(
    case: DevCase,
    seed: int,
    restarts: int,
    trials: int,
    max_swaps: int,
) -> SimpleTESRun:
    start = time.perf_counter()
    try:
        dag, hardware, _ = case.test_case.build()
        rng = random.Random(seed)
        mapping, score, distances = simpletes_initial_layout(
            dag, hardware, rng, restarts, trials
        )
        state = make_state(dag, hardware, mapping)
        drain(state, dag, hardware)
        decay = [1.0] * hardware.num_qubits
        swaps_since_progress = 0
        last_swap: tuple[int, int] | None = None
        swap_count = 0
        while len(state.executed_gates) < len(dag.gates):
            swap = select_simpletes_swap(
                state,
                dag,
                hardware,
                distances,
                decay,
                swaps_since_progress,
                last_swap,
                rng,
            )
            state.apply_swap(swap[0], swap[1], hardware)
            swap_count += 1
            executed = drain(state, dag, hardware)
            swaps_since_progress = 0 if executed else swaps_since_progress + 1
            last_swap = swap
            if swap_count > max_swaps:
                raise RuntimeError("SimpleTES exceeded max_swaps")
        state.assert_valid(dag, hardware)
        runtime_ms = (time.perf_counter() - start) * 1000
        return SimpleTESRun(
            instance=case.name,
            seed=seed,
            mapping=" ".join(map(str, mapping)),
            layout_score=score,
            swap=swap_count,
            depth=state.current_depth(),
            runtime_ms=runtime_ms,
            valid=True,
            error="",
        )
    except Exception as exc:
        runtime_ms = (time.perf_counter() - start) * 1000
        return SimpleTESRun(
            instance=case.name,
            seed=seed,
            mapping="",
            layout_score=-1,
            swap=-1,
            depth=-1,
            runtime_ms=runtime_ms,
            valid=False,
            error=f"{type(exc).__name__}: {exc}",
        )


def load_reference(path: Path) -> dict[str, dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as file:
        return {row["instance"]: row for row in csv.DictReader(file)}


def write_rows(path: Path, rows: list[object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        return
    with path.open("w", encoding="utf-8-sig", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=asdict(rows[0]).keys())
        writer.writeheader()
        writer.writerows(asdict(row) for row in rows)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Fresh same-input comparison using a faithful Python port of SimpleTES best.rs"
    )
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--oaabr-cases", type=Path, required=True)
    parser.add_argument("--case-indices", type=str, default=None)
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--simpletes-seeds", type=int, default=3)
    parser.add_argument("--layout-restarts", type=int, default=30)
    parser.add_argument("--layout-trials", type=int, default=8000)
    parser.add_argument("--max-swaps", type=int, default=10000)
    parser.add_argument(
        "--attempt-output",
        type=Path,
        default=Path("fresh_results/stage46_simpletes_attempts.csv"),
    )
    parser.add_argument(
        "--case-output",
        type=Path,
        default=Path("fresh_results/stage46_threeway_cases.csv"),
    )
    parser.add_argument(
        "--summary-output",
        type=Path,
        default=Path("fresh_results/stage46_threeway_summary.json"),
    )
    args = parser.parse_args()

    cases = choose_cases(
        load_cases(args.input, limit=None),
        parse_indices(args.case_indices),
        args.limit,
    )
    reference = load_reference(args.oaabr_cases)
    attempts: list[SimpleTESRun] = []
    results: list[ThreeWayCase] = []
    print("===== Stage 46：全新同输入三方实验 =====")
    print(f"输入：{args.input.resolve()}")
    print(f"实例数：{len(cases)}")
    print(
        "SimpleTES：公开 best.rs 的忠实 Python 策略移植；"
        "非官方 Rust scaffold 原生运行"
    )
    print(
        f"布局预算：{args.layout_restarts} random restarts × "
        f"{args.layout_trials} hill-climb trials；seeds={args.simpletes_seeds}"
    )
    for index, case in enumerate(cases, start=1):
        if case.name not in reference:
            raise KeyError(f"OAABR reference missing {case.name}")
        print(f"[{index}/{len(cases)}] {case.name} ...", flush=True)
        case_attempts = [
            run_simpletes(
                case,
                seed,
                args.layout_restarts,
                args.layout_trials,
                args.max_swaps,
            )
            for seed in range(args.simpletes_seeds)
        ]
        attempts.extend(case_attempts)
        write_rows(args.attempt_output, attempts)
        valid = [row for row in case_attempts if row.valid]
        if not valid:
            raise RuntimeError(
                f"SimpleTES port failed for {case.name}: "
                + "; ".join(row.error for row in case_attempts)
            )
        best = min(valid, key=lambda row: (row.swap, row.depth, row.seed))
        ref = reference[case.name]
        oaabr_swap = int(ref["router_swap"])
        oaabr_depth = int(ref["router_depth"])
        lightsabre_swap = int(ref["lightsabre_swap"])
        lightsabre_depth = int(ref["lightsabre_depth"])
        result = ThreeWayCase(
            instance=case.name,
            topology=case.topology,
            circuit_mode=case.circuit_mode,
            num_qubits=case.num_qubits,
            cx_count=case.two_qubit_gate_count,
            oaabr_swap=oaabr_swap,
            oaabr_depth=oaabr_depth,
            lightsabre_swap=lightsabre_swap,
            lightsabre_depth=lightsabre_depth,
            simpletes_seed=best.seed,
            simpletes_swap=best.swap,
            simpletes_depth=best.depth,
            simpletes_layout_score=best.layout_score,
            simpletes_runtime_ms=sum(row.runtime_ms for row in case_attempts),
            oaabr_minus_lightsabre=oaabr_swap - lightsabre_swap,
            oaabr_minus_simpletes=oaabr_swap - best.swap,
            simpletes_minus_lightsabre=best.swap - lightsabre_swap,
        )
        results.append(result)
        write_rows(args.case_output, results)
        print(
            f"  OAABR={oaabr_swap}/{oaabr_depth}, "
            f"LightSABRE={lightsabre_swap}/{lightsabre_depth}, "
            f"SimpleTES-port={best.swap}/{best.depth} (seed={best.seed})"
        )

    totals = {
        "oaabr": sum(row.oaabr_swap for row in results),
        "lightsabre": sum(row.lightsabre_swap for row in results),
        "simpletes_port": sum(row.simpletes_swap for row in results),
    }
    summary = {
        "experiment_date": "2026-07-17",
        "dataset": str(args.input.resolve()),
        "case_count": len(results),
        "case_indices": args.case_indices,
        "metric": "inserted SWAP; depth is tie-break only",
        "qiskit_reference": str(args.oaabr_cases.resolve()),
        "simpletes_status": (
            "faithful Python port of the published best.rs EVOLVE block; "
            "not an official Rust-scaffold reproduction"
        ),
        "simpletes_layout_restarts": args.layout_restarts,
        "simpletes_layout_trials": args.layout_trials,
        "simpletes_seeds": args.simpletes_seeds,
        "totals": totals,
        "oaabr_gap_vs_lightsabre": totals["oaabr"] - totals["lightsabre"],
        "oaabr_relative_vs_lightsabre": (
            (totals["oaabr"] - totals["lightsabre"])
            / totals["lightsabre"]
        ),
        "oaabr_gap_vs_simpletes_port": totals["oaabr"] - totals["simpletes_port"],
        "oaabr_relative_vs_simpletes_port": (
            (totals["oaabr"] - totals["simpletes_port"])
            / totals["simpletes_port"]
        ),
        "simpletes_port_gap_vs_lightsabre": (
            totals["simpletes_port"] - totals["lightsabre"]
        ),
        "wins_by_swap": {
            "oaabr_vs_lightsabre": dict(
                Counter(
                    "win" if row.oaabr_swap < row.lightsabre_swap
                    else "tie" if row.oaabr_swap == row.lightsabre_swap
                    else "loss"
                    for row in results
                )
            ),
            "oaabr_vs_simpletes_port": dict(
                Counter(
                    "win" if row.oaabr_swap < row.simpletes_swap
                    else "tie" if row.oaabr_swap == row.simpletes_swap
                    else "loss"
                    for row in results
                )
            ),
            "simpletes_port_vs_lightsabre": dict(
                Counter(
                    "win" if row.simpletes_swap < row.lightsabre_swap
                    else "tie" if row.simpletes_swap == row.lightsabre_swap
                    else "loss"
                    for row in results
                )
            ),
        },
        "simpletes_total_runtime_ms": sum(
            row.simpletes_runtime_ms for row in results
        ),
    }
    args.summary_output.parent.mkdir(parents=True, exist_ok=True)
    args.summary_output.write_text(
        json.dumps(summary, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print()
    print("===== Stage 46 汇总 =====")
    print(f"OAABR total SWAP：{totals['oaabr']}")
    print(f"LightSABRE total SWAP：{totals['lightsabre']}")
    print(f"SimpleTES-port total SWAP：{totals['simpletes_port']}")
    print(
        "OAABR vs LightSABRE："
        f"{summary['oaabr_gap_vs_lightsabre']:+d} "
        f"({summary['oaabr_relative_vs_lightsabre']:+.2%})"
    )
    print(
        "OAABR vs SimpleTES-port："
        f"{summary['oaabr_gap_vs_simpletes_port']:+d} "
        f"({summary['oaabr_relative_vs_simpletes_port']:+.2%})"
    )
    print(f"尝试明细：{args.attempt_output.resolve()}")
    print(f"逐实例：{args.case_output.resolve()}")
    print(f"汇总：{args.summary_output.resolve()}")


if __name__ == "__main__":
    main()
