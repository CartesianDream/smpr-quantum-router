from __future__ import annotations

import argparse
import csv
import json
import time
from collections import Counter
from dataclasses import asdict, dataclass, replace
from pathlib import Path

import stage20_score_structure_ablation as stage20
import stage21_policy_portfolio as stage21
import stage33_large_topology_probe as stage33

from stage7_initial_mapping_pool import MappingCandidate
from stage10_dev_benchmark import DevCase, load_cases
from stage17_validation_select import run_qiskit_multiseed


@dataclass
class PolishRow:
    instance: str
    initial_mapping: str
    round_index: int
    direction: str
    policy: str
    start_mapping: str
    end_mapping: str
    swap: int
    depth: int
    runtime_ms: float


@dataclass
class RouteAttempt:
    instance: str
    mapping: str
    source: str
    policy: str
    swap: int | None
    depth: int | None
    runtime_ms: float
    valid: bool
    error: str


@dataclass
class CaseResult:
    instance: str
    topology: str
    circuit_mode: str
    logical_qubits: int
    physical_qubits: int
    cx_count: int
    initial_mappings: int
    fb_rounds: int
    layouts_generated: int
    layouts_unique: int
    polish_policies: str

    compact_mapping: str
    compact_policy: str
    compact_swap: int
    compact_depth: int

    selected_mapping: str
    selected_source: str
    selected_policy: str
    fb_swap: int
    fb_depth: int
    fb_improvement: int
    router_budget_ms: float

    lightsabre_seed: int
    lightsabre_swap: int
    lightsabre_depth: int
    lightsabre_budget_ms: float
    swap_gap: int
    depth_gap: int
    outcome: str


def mapping_text(mapping: tuple[int, ...] | list[int]) -> str:
    return ",".join(str(value) for value in mapping)


def reverse_case(case: DevCase) -> DevCase:
    return DevCase(
        test_case=replace(
            case.test_case,
            name=f"{case.name}_reversed",
            gate_specs=tuple(reversed(case.test_case.gate_specs)),
        ),
        split=case.split,
        topology=case.topology,
        circuit_mode=case.circuit_mode,
        source_seed=case.source_seed,
    )


def route_endpoint(
    case: DevCase,
    mapping: tuple[int, ...],
    config: stage20.StructuralConfig,
) -> tuple[tuple[int, ...], int, int, float]:
    dag, hardware, _ = case.test_case.build()
    start = time.perf_counter()
    state = stage20.run_router(
        dag=dag,
        hardware=hardware,
        initial_mapping=list(mapping),
        config=config,
    )
    elapsed_ms = (time.perf_counter() - start) * 1000.0
    state.assert_valid(dag, hardware)
    if len(state.executed_gates) != len(dag.gates):
        raise AssertionError("虚拟路由结束后仍有未执行门")
    swaps = sum(op[0] == "swap" for op in state.physical_operations)
    return (
        tuple(state.logical_to_physical),
        swaps,
        state.current_depth(),
        elapsed_ms,
    )


def generate_fb_layouts(
    case: DevCase,
    initials: list[tuple[MappingCandidate, float]],
    rounds: int,
    config: stage20.StructuralConfig,
) -> tuple[list[tuple[MappingCandidate, str]], list[PolishRow], float]:
    reversed_case = reverse_case(case)
    candidates: list[tuple[MappingCandidate, str]] = []
    polish_rows: list[PolishRow] = []
    total_runtime_ms = 0.0

    for initial, _proxy in initials:
        current = tuple(initial.mapping)
        candidates.append((initial, "compact"))
        for round_index in range(1, rounds + 1):
            forward_end, swaps, depth, runtime_ms = route_endpoint(
                case, current, config
            )
            total_runtime_ms += runtime_ms
            polish_rows.append(
                PolishRow(
                    instance=case.name,
                    initial_mapping=initial.name,
                    round_index=round_index,
                    direction="forward",
                    policy=config.name,
                    start_mapping=mapping_text(current),
                    end_mapping=mapping_text(forward_end),
                    swap=swaps,
                    depth=depth,
                    runtime_ms=runtime_ms,
                )
            )

            backward_end, swaps, depth, runtime_ms = route_endpoint(
                reversed_case, forward_end, config
            )
            total_runtime_ms += runtime_ms
            polish_rows.append(
                PolishRow(
                    instance=case.name,
                    initial_mapping=initial.name,
                    round_index=round_index,
                    direction="backward",
                    policy=config.name,
                    start_mapping=mapping_text(forward_end),
                    end_mapping=mapping_text(backward_end),
                    swap=swaps,
                    depth=depth,
                    runtime_ms=runtime_ms,
                )
            )
            current = backward_end
            candidates.append(
                (
                    MappingCandidate(
                        name=(
                            f"{initial.name}_fb_{config.name}_r{round_index}"
                        ),
                        mapping=current,
                        generation_ms=0.0,
                    ),
                    f"forward_backward_{config.name}_r{round_index}",
                )
            )

    unique: list[tuple[MappingCandidate, str]] = []
    seen: set[tuple[int, ...]] = set()
    for candidate, source in candidates:
        if candidate.mapping in seen:
            continue
        seen.add(candidate.mapping)
        unique.append((candidate, source))
    return unique, polish_rows, total_runtime_ms


def save_csv(path: Path, rows: list, fields) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=fields)
        writer.writeheader()
        writer.writerows(asdict(row) for row in rows)


def summarize(rows: list[CaseResult]) -> dict:
    compact = sum(row.compact_swap for row in rows)
    fb = sum(row.fb_swap for row in rows)
    lightsabre = sum(row.lightsabre_swap for row in rows)
    outcomes = Counter(row.outcome for row in rows)
    return {
        "case_count": len(rows),
        "compact_swap": compact,
        "fb_swap": fb,
        "fb_improvement": compact - fb,
        "lightsabre_swap": lightsabre,
        "swap_gap": fb - lightsabre,
        "wins": outcomes["OAABR胜"],
        "ties": outcomes["平局"],
        "losses": outcomes["LightSABRE胜"],
        "router_budget_ms": sum(row.router_budget_ms for row in rows),
        "lightsabre_budget_ms": sum(row.lightsabre_budget_ms for row in rows),
    }


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Stage 36：自研策略感知的正反虚拟路由初始布局"
    )
    parser.add_argument(
        "--input", type=Path, default=Path("data/benchmarks_large_v1/probe.json")
    )
    parser.add_argument("--case-indices", type=str, default="3,6")
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--anchor-trials", type=int, default=4)
    parser.add_argument("--initial-mappings", type=int, default=2)
    parser.add_argument("--fb-rounds", type=int, default=2)
    parser.add_argument(
        "--polish-policies",
        type=str,
        default="front_sum,simpletes_ordered",
        help="用于产生正反布局的策略列表；逗号分隔",
    )
    parser.add_argument("--policies", type=str, default=stage33.DEFAULT_POLICIES)
    parser.add_argument("--qiskit-seeds", type=int, default=5)
    parser.add_argument("--qiskit-repeats", type=int, default=1)
    parser.add_argument(
        "--polish-output", type=Path,
        default=Path("results/stage36_polish.csv"),
    )
    parser.add_argument(
        "--attempt-output", type=Path,
        default=Path("results/stage36_attempts.csv"),
    )
    parser.add_argument(
        "--case-output", type=Path,
        default=Path("results/stage36_cases.csv"),
    )
    parser.add_argument(
        "--summary-output", type=Path,
        default=Path("results/stage36_summary.json"),
    )
    args = parser.parse_args()
    if args.initial_mappings <= 0 or args.fb_rounds <= 0:
        raise ValueError("initial-mappings与fb-rounds必须为正数")

    stage33.configure_router()
    policies = stage33.parse_policies(args.policies)
    polish_configs = stage33.parse_policies(args.polish_policies)
    cases = stage21.choose_cases(
        load_cases(args.input, limit=None),
        stage21.parse_indices(args.case_indices),
        args.limit,
    )

    print("===== Stage 36：策略感知正反布局搜索 =====")
    print(f"输入：{args.input.resolve()}")
    print(f"实例数：{len(cases)}")
    print(
        f"布局：anchors={args.anchor_trials}, initial={args.initial_mappings}, "
        f"fb-rounds={args.fb_rounds}, "
        f"polish={[config.name for config in polish_configs]}"
    )
    print(f"最终路由策略：{[config.name for config in policies]}")
    print(
        f"LightSABRE：{args.qiskit_seeds} seeds x "
        f"{args.qiskit_repeats} repeats"
    )

    all_polish: list[PolishRow] = []
    all_attempts: list[RouteAttempt] = []
    case_rows: list[CaseResult] = []
    for index, case in enumerate(cases, start=1):
        print(f"[{index}/{len(cases)}] {case.name} ...", flush=True)
        pool, _generated = stage33.compact_mapping_pool(case, args.anchor_trials)
        initials = pool[: args.initial_mappings]
        generated_layouts: list[tuple[MappingCandidate, str]] = []
        generation_budget = 0.0
        for polish_config in polish_configs:
            layouts, polish_rows, policy_budget = generate_fb_layouts(
                case=case,
                initials=initials,
                rounds=args.fb_rounds,
                config=polish_config,
            )
            generated_layouts.extend(layouts)
            all_polish.extend(polish_rows)
            generation_budget += policy_budget

        layouts: list[tuple[MappingCandidate, str]] = []
        seen_layouts: set[tuple[int, ...]] = set()
        for mapping, source in generated_layouts:
            if mapping.mapping in seen_layouts:
                continue
            seen_layouts.add(mapping.mapping)
            layouts.append((mapping, source))

        route_budget = 0.0
        evaluated: list[tuple] = []
        for mapping, source in layouts:
            for config in policies:
                attempt = stage33.run_attempt(
                    case=case,
                    mapping=mapping,
                    proxy_cost=0.0,
                    config=config,
                )
                route_budget += attempt.runtime_ms
                all_attempts.append(
                    RouteAttempt(
                        instance=case.name,
                        mapping=mapping.name,
                        source=source,
                        policy=config.name,
                        swap=attempt.swap,
                        depth=attempt.depth,
                        runtime_ms=attempt.runtime_ms,
                        valid=attempt.valid,
                        error=attempt.error,
                    )
                )
                if attempt.valid:
                    evaluated.append((attempt, source))
        if not evaluated:
            raise RuntimeError(f"{case.name}: 所有自主布局路由失败")

        compact_rows = [row for row in evaluated if row[1] == "compact"]
        compact_best, _ = min(compact_rows, key=lambda row: stage33.quality(row[0]))
        fb_best, fb_source = min(evaluated, key=lambda row: stage33.quality(row[0]))

        qiskit_best, qiskit_budget = run_qiskit_multiseed(
            case, args.qiskit_seeds, args.qiskit_repeats
        )
        if qiskit_best.swap_count is None or qiskit_best.weighted_depth is None:
            raise RuntimeError(f"{case.name}: LightSABRE无合法结果")

        ours_pair = (int(fb_best.swap), int(fb_best.depth))
        qiskit_pair = (
            int(qiskit_best.swap_count),
            int(qiskit_best.weighted_depth),
        )
        if ours_pair < qiskit_pair:
            outcome = "OAABR胜"
        elif ours_pair == qiskit_pair:
            outcome = "平局"
        else:
            outcome = "LightSABRE胜"

        row = CaseResult(
            instance=case.name,
            topology=case.topology,
            circuit_mode=case.circuit_mode,
            logical_qubits=case.num_qubits,
            physical_qubits=case.test_case.num_physical_qubits,
            cx_count=case.two_qubit_gate_count,
            initial_mappings=len(initials),
            fb_rounds=args.fb_rounds,
            layouts_generated=(
                len(initials)
                * (1 + len(polish_configs) * args.fb_rounds)
            ),
            layouts_unique=len(layouts),
            polish_policies=",".join(
                config.name for config in polish_configs
            ),
            compact_mapping=compact_best.mapping,
            compact_policy=compact_best.policy,
            compact_swap=int(compact_best.swap),
            compact_depth=int(compact_best.depth),
            selected_mapping=fb_best.mapping,
            selected_source=fb_source,
            selected_policy=fb_best.policy,
            fb_swap=int(fb_best.swap),
            fb_depth=int(fb_best.depth),
            fb_improvement=int(compact_best.swap) - int(fb_best.swap),
            router_budget_ms=generation_budget + route_budget,
            lightsabre_seed=int(qiskit_best.seed),
            lightsabre_swap=int(qiskit_best.swap_count),
            lightsabre_depth=int(qiskit_best.weighted_depth),
            lightsabre_budget_ms=qiskit_budget,
            swap_gap=int(fb_best.swap) - int(qiskit_best.swap_count),
            depth_gap=int(fb_best.depth) - int(qiskit_best.weighted_depth),
            outcome=outcome,
        )
        case_rows.append(row)
        print(
            f"  compact={row.compact_swap}/{row.compact_depth} "
            f"({row.compact_mapping}, {row.compact_policy})"
        )
        print(
            f"  FB={row.fb_swap}/{row.fb_depth} "
            f"({row.selected_source}, {row.selected_policy}), "
            f"DeltaSWAP=-{row.fb_improvement}"
        )
        print(
            f"  LightSABRE={row.lightsabre_swap}/{row.lightsabre_depth}, "
            f"gap={row.swap_gap:+d}, {row.outcome}, "
            f"budget={row.router_budget_ms:.1f}/{row.lightsabre_budget_ms:.1f} ms"
        )

        save_csv(args.polish_output, all_polish, PolishRow.__annotations__.keys())
        save_csv(args.attempt_output, all_attempts, RouteAttempt.__annotations__.keys())
        save_csv(args.case_output, case_rows, CaseResult.__annotations__.keys())
        args.summary_output.parent.mkdir(parents=True, exist_ok=True)
        args.summary_output.write_text(
            json.dumps(summarize(case_rows), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    summary = summarize(case_rows)
    print("\n===== Stage 36 汇总 =====")
    print(f"compact total SWAP：{summary['compact_swap']}")
    print(f"FB total SWAP：{summary['fb_swap']}")
    print(f"自主布局减少：{summary['fb_improvement']}")
    print(f"LightSABRE total SWAP：{summary['lightsabre_swap']}")
    print(f"相对LightSABRE gap：{summary['swap_gap']:+d}")
    print(
        f"逐实例胜/平/负：{summary['wins']}/"
        f"{summary['ties']}/{summary['losses']}"
    )
    print(
        f"预算 router/LightSABRE：{summary['router_budget_ms']:.1f}/"
        f"{summary['lightsabre_budget_ms']:.1f} ms"
    )
    print(f"正反轨迹：{args.polish_output.resolve()}")
    print(f"路由尝试：{args.attempt_output.resolve()}")
    print(f"逐实例：{args.case_output.resolve()}")
    print(f"汇总：{args.summary_output.resolve()}")


if __name__ == "__main__":
    main()
