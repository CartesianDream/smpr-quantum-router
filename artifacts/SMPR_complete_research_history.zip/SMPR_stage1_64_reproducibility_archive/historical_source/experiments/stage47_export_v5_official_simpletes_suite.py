from __future__ import annotations

from collections import Counter
from hashlib import sha256
from pathlib import Path
import json
import re

INPUT = Path("data/benchmarks_v5/final_test.json")
OUTPUT_ROOT = Path("data/benchmarks_v5/official_simpletes_rust_v1")
CIRCUIT_DIR = OUTPUT_ROOT / "circuits"
TOPOLOGY_DIR = OUTPUT_ROOT / "topologies"
FULL_SUITE = OUTPUT_ROOT / "v5_suite.json"
SMOKE_SUITE = OUTPUT_ROOT / "v5_suite_smoke.json"

raw = INPUT.read_bytes()
root = json.loads(raw.decode("utf-8"))
cases = root["cases"]

if len(cases) != 60:
    raise RuntimeError(f"expected 60 cases, got {len(cases)}")

gate_shapes = Counter()
for case in cases:
    for spec in case["gate_specs"]:
        if not isinstance(spec, list) or not spec:
            raise RuntimeError(
                f"{case['name']}: invalid gate spec {spec!r}"
            )
        gate_shapes[(str(spec[0]).lower(), len(spec) - 1)] += 1

print("gate shapes:")
for shape, count in sorted(gate_shapes.items()):
    print(f"  {shape}: {count}")

# V5 当前设计应严格是 H + CX；遇到其他门立即停止，避免错误转换。
supported_shapes = {("h", 1), ("cx", 2)}
unsupported = sorted(set(gate_shapes) - supported_shapes)
if unsupported:
    raise RuntimeError(f"unsupported gate shapes: {unsupported}")

CIRCUIT_DIR.mkdir(parents=True, exist_ok=True)
TOPOLOGY_DIR.mkdir(parents=True, exist_ok=True)

suite_cases = []

for index, case in enumerate(cases):
    name = str(case["name"])
    safe_name = re.sub(r"[^A-Za-z0-9_.-]+", "_", name)
    num_qubits = int(case["num_qubits"])

    edges = []
    seen_edges = set()

    for raw_edge in case["edges"]:
        if not isinstance(raw_edge, list) or len(raw_edge) != 2:
            raise RuntimeError(f"{name}: invalid edge {raw_edge!r}")

        a, b = map(int, raw_edge)

        if not (0 <= a < num_qubits and 0 <= b < num_qubits):
            raise RuntimeError(f"{name}: out-of-range edge {(a, b)}")
        if a == b:
            raise RuntimeError(f"{name}: self-loop {(a, b)}")

        normalized = (min(a, b), max(a, b))
        if normalized in seen_edges:
            raise RuntimeError(f"{name}: duplicate edge {normalized}")

        seen_edges.add(normalized)
        edges.append([a, b])

    qasm_lines = [
        "OPENQASM 3.0;",
        'include "stdgates.inc";',
        f"qubit[{num_qubits}] q;",
    ]

    cx_count = 0

    for gate_index, spec in enumerate(case["gate_specs"]):
        op = str(spec[0]).lower()

        if op == "h" and len(spec) == 2:
            q = int(spec[1])
            if not 0 <= q < num_qubits:
                raise RuntimeError(
                    f"{name}: gate {gate_index} has invalid qubit {q}"
                )
            qasm_lines.append(f"h q[{q}];")

        elif op == "cx" and len(spec) == 3:
            control, target = int(spec[1]), int(spec[2])
            if not (
                0 <= control < num_qubits
                and 0 <= target < num_qubits
                and control != target
            ):
                raise RuntimeError(
                    f"{name}: gate {gate_index} has invalid "
                    f"CX {(control, target)}"
                )
            qasm_lines.append(
                f"cx q[{control}], q[{target}];"
            )
            cx_count += 1

        else:
            raise RuntimeError(
                f"{name}: unsupported gate {spec!r}"
            )

    declared_cx = int(case["two_qubit_gate_count"])
    if cx_count != declared_cx:
        raise RuntimeError(
            f"{name}: declared CX={declared_cx}, exported={cx_count}"
        )

    circuit_rel = Path("circuits") / f"{index:03d}_{safe_name}.qasm"
    topology_rel = Path("topologies") / f"{index:03d}_{safe_name}.json"

    circuit_path = OUTPUT_ROOT / circuit_rel
    topology_path = OUTPUT_ROOT / topology_rel

    circuit_path.write_text(
        "\n".join(qasm_lines) + "\n",
        encoding="utf-8",
    )
    topology_path.write_text(
        json.dumps(
            {
                "num_qubits": num_qubits,
                "edges": edges,
            },
            indent=2,
        ) + "\n",
        encoding="utf-8",
    )

    suite_cases.append(
        {
            "id": name,
            "qasm3_path": circuit_rel.as_posix(),
            "topology_path": topology_rel.as_posix(),
            # 与官方 suite 使用同一固定基准种子。
            "seed": 42,
            # 以下为追溯字段；router_cli 会安全忽略。
            "source_seed": int(case["seed"]),
            "source_initial_mapping": case["initial_mapping"],
            "source_two_qubit_gate_count": declared_cx,
        }
    )

suite_metadata = {
    "format": "SimpleTES router_cli suite",
    "source": INPUT.as_posix(),
    "source_sha256": sha256(raw).hexdigest(),
    "notes": (
        "V5 gate order and topology preserved; "
        "source initial_mapping intentionally not imposed."
    ),
}

full_payload = {
    **suite_metadata,
    "cases": suite_cases,
}
smoke_payload = {
    **suite_metadata,
    "cases": suite_cases[:1],
}

FULL_SUITE.write_text(
    json.dumps(full_payload, indent=2, ensure_ascii=False) + "\n",
    encoding="utf-8",
)
SMOKE_SUITE.write_text(
    json.dumps(smoke_payload, indent=2, ensure_ascii=False) + "\n",
    encoding="utf-8",
)

print("\n===== Export completed =====")
print("cases:", len(suite_cases))
print("circuits:", len(list(CIRCUIT_DIR.glob("*.qasm"))))
print("topologies:", len(list(TOPOLOGY_DIR.glob("*.json"))))
print("full suite:", FULL_SUITE.resolve())
print("smoke suite:", SMOKE_SUITE.resolve())
print("source sha256:", suite_metadata["source_sha256"])
print("initial_mapping: intentionally not imposed")