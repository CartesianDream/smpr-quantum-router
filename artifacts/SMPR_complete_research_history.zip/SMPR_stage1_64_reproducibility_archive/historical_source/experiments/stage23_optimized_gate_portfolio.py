from __future__ import annotations

import argparse
import csv
import json
import statistics
import time
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass
from pathlib import Path

try:
    from qiskit import QuantumCircuit, transpile
    from qiskit.transpiler import CouplingMap
except ModuleNotFoundError:
    QuantumCircuit = None
    transpile = None
    CouplingMap = None

import stage20_score_structure_ablation as stage20
import stage21_policy_portfolio as stage21

from stage1_core import HardwareGraph, RoutingState
from stage7_initial_mapping_pool import MappingCandidate, generate_base_mapping_pool
from stage10_dev_benchmark import DevCase, load_cases


# ============================================================
# 1. 冻结的三策略与结果结构
# ============================================================

DEFAULT_POLICIES = ("v1", "simpletes_ordered", "front_sum")


@dataclass
class OptimizedAttemptRow:
    instance: str
    topology: str
    circuit_mode: str
    num_qubits: int
    logical_cx_count: int
    policy: str
    mapping: str

    raw_swap_count: int | None
    raw_weighted_depth: int | None
    raw_physical_operation_count: int | None

    optimized_cx_count: int | None
    optimized_cx_overhead: int | None
    optimized_total_gate_count: int | None
    optimized_depth: int | None

    routing_ms: float
    optimization_ms: float
    total_ms: float
    valid: bool
    error: str


@dataclass
class OptimizedCaseRow:
    instance: str
    topology: str
    circuit_mode: str
    num_qubits: int
    logical_cx_count: int
    mapping_count: int
    policy_count: int
    primary_metric: str

    v1_policy: str
    v1_mapping: str
    v1_raw_swap: int
    v1_optimized_cx: int
    v1_optimized_total_gates: int
    v1_optimized_depth: int

    raw_portfolio_policy: str
    raw_portfolio_mapping: str
    raw_portfolio_swap: int
    raw_portfolio_optimized_cx: int
    raw_portfolio_optimized_total_gates: int
    raw_portfolio_optimized_depth: int

    optimized_policy: str
    optimized_mapping: str
    optimized_raw_swap: int
    optimized_cx: int
    optimized_total_gates: int
    optimized_depth: int

    primary_improvement_vs_v1: int
    primary_improvement_vs_raw_portfolio: int
    selection_changed_from_raw_portfolio: bool
    total_budget_ms: float


def require_qiskit() -> None:
    if QuantumCircuit is None or transpile is None or CouplingMap is None:
        raise ModuleNotFoundError(
            "Stage 23 需要 Qiskit。请先执行：pip install -r requirements.txt"
        )


# ============================================================
# 2. 物理线路构造、优化和合法性检查
# ============================================================

def state_to_qiskit_circuit(
    state: RoutingState,
    num_qubits: int,
) -> QuantumCircuit:
    require_qiskit()
    circuit = QuantumCircuit(num_qubits)

    for operation in state.physical_operations:
        name = str(operation[0])

        if name == "h":
            circuit.h(int(operation[1]))
        elif name == "x":
            circuit.x(int(operation[1]))
        elif name == "cx":
            circuit.cx(int(operation[1]), int(operation[2]))
        elif name == "swap":
            circuit.swap(int(operation[1]), int(operation[2]))
        else:
            raise ValueError(f"不支持的物理门类型：{name}")

    return circuit


def build_bidirectional_coupling(hardware: HardwareGraph) -> CouplingMap:
    require_qiskit()
    directed: list[tuple[int, int]] = []
    for u, v in hardware.edges:
        directed.append((int(u), int(v)))
        directed.append((int(v), int(u)))
    return CouplingMap(directed)


def assert_optimized_topology(
    circuit: QuantumCircuit,
    hardware: HardwareGraph,
) -> None:
    for instruction in circuit.data:
        qubits = instruction.qubits
        if len(qubits) != 2:
            continue

        u = circuit.find_bit(qubits[0]).index
        v = circuit.find_bit(qubits[1]).index
        if not hardware.adjacent(u, v):
            raise AssertionError(
                f"优化后出现非法双比特边：{instruction.operation.name}({u}, {v})"
            )


def optimize_physical_circuit(
    state: RoutingState,
    hardware: HardwareGraph,
    optimization_level: int,
    seed: int,
) -> tuple[int, int, int, float]:
    circuit = state_to_qiskit_circuit(state, hardware.num_qubits)
    coupling = build_bidirectional_coupling(hardware)
    start = time.perf_counter()

    optimized = transpile(
        circuit,
        basis_gates=["u", "cx"],
        coupling_map=coupling,
        initial_layout=list(range(hardware.num_qubits)),
        layout_method="trivial",
        routing_method="none",
        optimization_level=optimization_level,
        seed_transpiler=seed,
    )

    elapsed_ms = (time.perf_counter() - start) * 1000.0
    assert_optimized_topology(optimized, hardware)
    operations = dict(optimized.count_ops())

    if int(operations.get("swap", 0)) != 0:
        raise AssertionError("优化后仍含 SWAP，说明基础门分解未生效")

    return (
        int(operations.get("cx", 0)),
        int(optimized.size()),
        int(optimized.depth()),
        elapsed_ms,
    )


# ============================================================
# 3. 路由尝试与选择
# ============================================================

def run_optimized_attempt(
    case: DevCase,
    mapping: MappingCandidate,
    policy: stage20.StructuralConfig,
    optimization_level: int,
    optimization_seed: int,
) -> OptimizedAttemptRow:
    dag, hardware, _ = case.test_case.build()
    routing_start = time.perf_counter()

    try:
        state = stage20.run_router(
            dag=dag,
            hardware=hardware,
            initial_mapping=list(mapping.mapping),
            config=policy,
        )
        routing_ms = (time.perf_counter() - routing_start) * 1000.0
        state.assert_valid(dag, hardware)

        if len(state.executed_gates) != len(dag.gates):
            raise AssertionError("路由结束后仍有未执行逻辑门")

        raw_swap = sum(
            operation[0] == "swap" for operation in state.physical_operations
        )
        optimized_cx, optimized_gates, optimized_depth, optimization_ms = (
            optimize_physical_circuit(
                state=state,
                hardware=hardware,
                optimization_level=optimization_level,
                seed=optimization_seed,
            )
        )

        return OptimizedAttemptRow(
            instance=case.name,
            topology=case.topology,
            circuit_mode=case.circuit_mode,
            num_qubits=case.num_qubits,
            logical_cx_count=case.two_qubit_gate_count,
            policy=policy.name,
            mapping=mapping.name,
            raw_swap_count=raw_swap,
            raw_weighted_depth=state.current_depth(),
            raw_physical_operation_count=len(state.physical_operations),
            optimized_cx_count=optimized_cx,
            optimized_cx_overhead=optimized_cx - case.two_qubit_gate_count,
            optimized_total_gate_count=optimized_gates,
            optimized_depth=optimized_depth,
            routing_ms=routing_ms,
            optimization_ms=optimization_ms,
            total_ms=routing_ms + optimization_ms,
            valid=True,
            error="",
        )
    except Exception as error:
        routing_ms = (time.perf_counter() - routing_start) * 1000.0
        return OptimizedAttemptRow(
            instance=case.name,
            topology=case.topology,
            circuit_mode=case.circuit_mode,
            num_qubits=case.num_qubits,
            logical_cx_count=case.two_qubit_gate_count,
            policy=policy.name,
            mapping=mapping.name,
            raw_swap_count=None,
            raw_weighted_depth=None,
            raw_physical_operation_count=None,
            optimized_cx_count=None,
            optimized_cx_overhead=None,
            optimized_total_gate_count=None,
            optimized_depth=None,
            routing_ms=routing_ms,
            optimization_ms=0.0,
            total_ms=routing_ms,
            valid=False,
            error=f"{type(error).__name__}: {error}",
        )


def raw_key(row: OptimizedAttemptRow) -> tuple:
    if not row.valid:
        return (10**9, 10**9, 10**9, row.policy, row.mapping)
    return (
        int(row.raw_swap_count),
        int(row.raw_weighted_depth),
        row.total_ms,
        row.policy,
        row.mapping,
    )


def optimized_key(row: OptimizedAttemptRow, primary_metric: str) -> tuple:
    if not row.valid:
        return (10**9, 10**9, 10**9, 10**9, row.policy, row.mapping)

    if primary_metric == "cx":
        primary = int(row.optimized_cx_count)
    elif primary_metric == "total_gates":
        primary = int(row.optimized_total_gate_count)
    else:
        raise ValueError(f"未知 primary metric：{primary_metric}")

    return (
        primary,
        int(row.optimized_depth),
        int(row.optimized_cx_count),
        int(row.raw_swap_count),
        row.policy,
        row.mapping,
    )


def primary_value(row: OptimizedAttemptRow, primary_metric: str) -> int:
    if primary_metric == "cx":
        return int(row.optimized_cx_count)
    return int(row.optimized_total_gate_count)


def best_valid(
    rows: list[OptimizedAttemptRow],
    primary_metric: str,
) -> OptimizedAttemptRow:
    valid = [row for row in rows if row.valid]
    if not valid:
        raise RuntimeError("没有合法尝试：" + " | ".join(row.error for row in rows))
    return min(valid, key=lambda row: optimized_key(row, primary_metric))


def build_case_row(
    case: DevCase,
    mappings: list[MappingCandidate],
    policies: list[stage20.StructuralConfig],
    attempts: list[OptimizedAttemptRow],
    primary_metric: str,
) -> OptimizedCaseRow:
    v1 = best_valid(
        [row for row in attempts if row.policy == "v1"],
        primary_metric,
    )
    raw_portfolio = min((row for row in attempts if row.valid), key=raw_key)
    optimized = best_valid(attempts, primary_metric)

    return OptimizedCaseRow(
        instance=case.name,
        topology=case.topology,
        circuit_mode=case.circuit_mode,
        num_qubits=case.num_qubits,
        logical_cx_count=case.two_qubit_gate_count,
        mapping_count=len(mappings),
        policy_count=len(policies),
        primary_metric=primary_metric,
        v1_policy=v1.policy,
        v1_mapping=v1.mapping,
        v1_raw_swap=int(v1.raw_swap_count),
        v1_optimized_cx=int(v1.optimized_cx_count),
        v1_optimized_total_gates=int(v1.optimized_total_gate_count),
        v1_optimized_depth=int(v1.optimized_depth),
        raw_portfolio_policy=raw_portfolio.policy,
        raw_portfolio_mapping=raw_portfolio.mapping,
        raw_portfolio_swap=int(raw_portfolio.raw_swap_count),
        raw_portfolio_optimized_cx=int(raw_portfolio.optimized_cx_count),
        raw_portfolio_optimized_total_gates=int(
            raw_portfolio.optimized_total_gate_count
        ),
        raw_portfolio_optimized_depth=int(raw_portfolio.optimized_depth),
        optimized_policy=optimized.policy,
        optimized_mapping=optimized.mapping,
        optimized_raw_swap=int(optimized.raw_swap_count),
        optimized_cx=int(optimized.optimized_cx_count),
        optimized_total_gates=int(optimized.optimized_total_gate_count),
        optimized_depth=int(optimized.optimized_depth),
        primary_improvement_vs_v1=(
            primary_value(v1, primary_metric)
            - primary_value(optimized, primary_metric)
        ),
        primary_improvement_vs_raw_portfolio=(
            primary_value(raw_portfolio, primary_metric)
            - primary_value(optimized, primary_metric)
        ),
        selection_changed_from_raw_portfolio=(
            (optimized.policy, optimized.mapping)
            != (raw_portfolio.policy, raw_portfolio.mapping)
        ),
        total_budget_ms=sum(row.total_ms for row in attempts),
    )


# ============================================================
# 4. 输出与汇总
# ============================================================

def write_csv(path: Path, rows: list, fields) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=fields)
        writer.writeheader()
        writer.writerows(asdict(row) for row in rows)


def optional_int(text: str) -> int | None:
    value = text.strip()
    if value in {"", "None"}:
        return None
    return int(value)


def read_attempt_csv(path: Path) -> list[OptimizedAttemptRow]:
    if not path.exists():
        raise FileNotFoundError(f"找不到复用缓存：{path.resolve()}")

    rows: list[OptimizedAttemptRow] = []
    with path.open("r", encoding="utf-8-sig", newline="") as file:
        for raw in csv.DictReader(file):
            rows.append(
                OptimizedAttemptRow(
                    instance=raw["instance"],
                    topology=raw["topology"],
                    circuit_mode=raw["circuit_mode"],
                    num_qubits=int(raw["num_qubits"]),
                    logical_cx_count=int(raw["logical_cx_count"]),
                    policy=raw["policy"],
                    mapping=raw["mapping"],
                    raw_swap_count=optional_int(raw["raw_swap_count"]),
                    raw_weighted_depth=optional_int(raw["raw_weighted_depth"]),
                    raw_physical_operation_count=optional_int(
                        raw["raw_physical_operation_count"]
                    ),
                    optimized_cx_count=optional_int(raw["optimized_cx_count"]),
                    optimized_cx_overhead=optional_int(
                        raw["optimized_cx_overhead"]
                    ),
                    optimized_total_gate_count=optional_int(
                        raw["optimized_total_gate_count"]
                    ),
                    optimized_depth=optional_int(raw["optimized_depth"]),
                    routing_ms=float(raw["routing_ms"]),
                    optimization_ms=float(raw["optimization_ms"]),
                    total_ms=float(raw["total_ms"]),
                    valid=raw["valid"].strip().lower() == "true",
                    error=raw["error"],
                )
            )
    return rows


def parse_policy_names(text: str | None) -> tuple[str, ...]:
    names = DEFAULT_POLICIES if not text else tuple(
        name.strip() for name in text.split(",") if name.strip()
    )
    unknown = [name for name in names if name not in stage20.CONFIG_BY_NAME]
    if unknown:
        raise ValueError(
            f"未知策略：{unknown}；可选值：{sorted(stage20.CONFIG_BY_NAME)}"
        )
    if "v1" not in names:
        raise ValueError("为保证不退化，策略集合必须包含 v1")
    return names


def summarize(rows: list[OptimizedCaseRow]) -> dict:
    if not rows:
        return {}

    primary_metric = rows[0].primary_metric

    def primary(row: OptimizedCaseRow, prefix: str) -> int:
        if primary_metric == "cx":
            return int(getattr(row, f"{prefix}_optimized_cx"))
        return int(getattr(row, f"{prefix}_optimized_total_gates"))

    v1_primary = sum(primary(row, "v1") for row in rows)
    raw_primary = sum(primary(row, "raw_portfolio") for row in rows)
    optimized_primary = sum(
        row.optimized_cx if primary_metric == "cx"
        else row.optimized_total_gates
        for row in rows
    )

    by_topology: dict[str, list[OptimizedCaseRow]] = defaultdict(list)
    for row in rows:
        by_topology[row.topology].append(row)

    return {
        "primary_metric": primary_metric,
        "case_count": len(rows),
        "v1_primary_total": v1_primary,
        "raw_portfolio_primary_total": raw_primary,
        "optimized_portfolio_primary_total": optimized_primary,
        "improvement_vs_v1": v1_primary - optimized_primary,
        "improvement_vs_raw_portfolio": raw_primary - optimized_primary,
        "relative_improvement_vs_v1": (
            (v1_primary - optimized_primary) / v1_primary if v1_primary else 0.0
        ),
        "v1_optimized_cx_total": sum(row.v1_optimized_cx for row in rows),
        "raw_portfolio_optimized_cx_total": sum(
            row.raw_portfolio_optimized_cx for row in rows
        ),
        "optimized_cx_total": sum(row.optimized_cx for row in rows),
        "optimized_total_gate_count": sum(
            row.optimized_total_gates for row in rows
        ),
        "optimized_depth_total": sum(row.optimized_depth for row in rows),
        "raw_swap_total_of_optimized_selection": sum(
            row.optimized_raw_swap for row in rows
        ),
        "selection_changed_cases": sum(
            row.selection_changed_from_raw_portfolio for row in rows
        ),
        "strictly_improved_vs_v1_cases": sum(
            row.primary_improvement_vs_v1 > 0 for row in rows
        ),
        "selected_policy_counts": dict(Counter(row.optimized_policy for row in rows)),
        "total_budget_ms": sum(row.total_budget_ms for row in rows),
        "mean_budget_ms": statistics.mean(row.total_budget_ms for row in rows),
        "by_topology": {
            topology: {
                "case_count": len(group),
                "improvement_vs_v1": sum(
                    row.primary_improvement_vs_v1 for row in group
                ),
                "improvement_vs_raw_portfolio": sum(
                    row.primary_improvement_vs_raw_portfolio for row in group
                ),
            }
            for topology, group in sorted(by_topology.items())
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Stage 23：优化后门成本驱动的三策略 Portfolio"
    )
    parser.add_argument("--stage-label", type=str, default="Stage 23")
    parser.add_argument(
        "--input",
        type=Path,
        default=Path("data/benchmarks_v3/dev.json"),
    )
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--case-indices", type=str, default=None)
    parser.add_argument(
        "--primary-metric",
        choices=("cx", "total_gates"),
        default="cx",
    )
    parser.add_argument(
        "--optimization-level",
        type=int,
        choices=(0, 1, 2, 3),
        default=3,
    )
    parser.add_argument("--optimization-seed", type=int, default=20260716)
    parser.add_argument(
        "--policies",
        type=str,
        default=None,
        help="逗号分隔；默认 v1,simpletes_ordered,front_sum",
    )
    parser.add_argument(
        "--resume-attempts",
        type=Path,
        default=None,
        help=(
            "复用已有 Stage 23 attempts CSV。仅运行缓存中缺少的"
            "实例—策略—映射组合；应保持相同 optimization level/seed。"
        ),
    )
    parser.add_argument(
        "--attempt-output",
        type=Path,
        default=Path("results/stage23_optimized_attempts.csv"),
    )
    parser.add_argument(
        "--case-output",
        type=Path,
        default=Path("results/stage23_optimized_cases.csv"),
    )
    parser.add_argument(
        "--summary-output",
        type=Path,
        default=Path("results/stage23_optimized_summary.json"),
    )
    args = parser.parse_args()

    require_qiskit()
    stage20.stage2.THETA = 5
    stage20.stage2.W_FUTURE = 0.5
    stage20.stage2.GAMMA = 0.5
    stage20.stage2.ALPHA = 0.5
    stage20.stage2.LAMBDA_DEPTH = 0.0

    cases = stage21.choose_cases(
        load_cases(args.input, limit=None),
        stage21.parse_indices(args.case_indices),
        args.limit,
    )
    policy_names = parse_policy_names(args.policies)
    policies = [stage20.CONFIG_BY_NAME[name] for name in policy_names]

    cache: dict[tuple[str, str, str], OptimizedAttemptRow] = {}
    if args.resume_attempts is not None:
        for row in read_attempt_csv(args.resume_attempts):
            cache[(row.instance, row.policy, row.mapping)] = row

    print(f"===== {args.stage_label}：优化后门成本 Portfolio =====")
    print(f"输入：{args.input.resolve()}")
    print(f"实例数：{len(cases)}")
    print(f"策略：{', '.join(policy_names)}")
    print(f"主指标：{args.primary_metric}")
    print(f"Qiskit optimization_level：{args.optimization_level}")
    if args.resume_attempts is not None:
        print(f"复用缓存：{args.resume_attempts.resolve()}，{len(cache)} 条")

    all_attempts: list[OptimizedAttemptRow] = []
    case_rows: list[OptimizedCaseRow] = []

    for index, case in enumerate(cases, start=1):
        mappings = generate_base_mapping_pool(case.test_case)
        attempts: list[OptimizedAttemptRow] = []
        reused = 0
        newly_run = 0

        for policy in policies:
            for mapping in mappings:
                key = (case.name, policy.name, mapping.name)
                cached = cache.get(key)

                if cached is not None and cached.valid:
                    attempts.append(cached)
                    reused += 1
                    continue

                result = run_optimized_attempt(
                    case=case,
                    mapping=mapping,
                    policy=policy,
                    optimization_level=args.optimization_level,
                    optimization_seed=args.optimization_seed,
                )
                attempts.append(result)
                cache[key] = result
                newly_run += 1
        row = build_case_row(
            case,
            mappings,
            policies,
            attempts,
            args.primary_metric,
        )
        all_attempts.extend(attempts)
        case_rows.append(row)

        print(
            f"[{index}/{len(cases)}] {case.name}: "
            f"v1 optCX={row.v1_optimized_cx}, "
            f"raw-choice optCX={row.raw_portfolio_optimized_cx}, "
            f"optimized-choice optCX={row.optimized_cx}, "
            f"depth={row.optimized_depth}, "
            f"policy={row.optimized_policy}, mapping={row.optimized_mapping}, "
            f"changed={row.selection_changed_from_raw_portfolio}, "
            f"cache/new={reused}/{newly_run}"
        )

        write_csv(
            args.attempt_output,
            all_attempts,
            OptimizedAttemptRow.__annotations__.keys(),
        )
        write_csv(
            args.case_output,
            case_rows,
            OptimizedCaseRow.__annotations__.keys(),
        )
        args.summary_output.parent.mkdir(parents=True, exist_ok=True)
        args.summary_output.write_text(
            json.dumps(summarize(case_rows), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    summary = summarize(case_rows)
    print()
    print(f"===== {args.stage_label} 汇总 =====")
    print(f"主指标：{summary['primary_metric']}")
    print(f"v1 优化后总成本：{summary['v1_primary_total']}")
    print(
        "按原始 SWAP 选路后的优化成本："
        f"{summary['raw_portfolio_primary_total']}"
    )
    print(
        "直接按优化后成本选路："
        f"{summary['optimized_portfolio_primary_total']}"
    )
    print(f"相对 v1 改善：{summary['improvement_vs_v1']}")
    print(
        "相对原始 SWAP Portfolio 再改善："
        f"{summary['improvement_vs_raw_portfolio']}"
    )
    print(
        "选择发生变化的实例："
        f"{summary['selection_changed_cases']}/{summary['case_count']}"
    )
    print(f"策略被选次数：{summary['selected_policy_counts']}")
    print(f"总预算：{summary['total_budget_ms']:.1f} ms")
    print()
    print(f"尝试明细：{args.attempt_output.resolve()}")
    print(f"逐实例结果：{args.case_output.resolve()}")
    print(f"汇总 JSON：{args.summary_output.resolve()}")


if __name__ == "__main__":
    main()
