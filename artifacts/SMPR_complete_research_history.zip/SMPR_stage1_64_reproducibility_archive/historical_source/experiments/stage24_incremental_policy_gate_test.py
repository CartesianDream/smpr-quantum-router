"""Stage 24：复用 Stage 23 缓存，增量测试两个额外评分策略。"""

from __future__ import annotations

import sys

from stage23_optimized_gate_portfolio import main


EXPANDED_POLICIES = (
    "v1,simpletes_ordered,front_sum,beta2,beta2_no_undo"
)


if __name__ == "__main__":
    if "--policies" not in sys.argv:
        sys.argv.extend(["--policies", EXPANDED_POLICIES])
    if "--stage-label" not in sys.argv:
        sys.argv.extend(["--stage-label", "Stage 24"])
    main()
