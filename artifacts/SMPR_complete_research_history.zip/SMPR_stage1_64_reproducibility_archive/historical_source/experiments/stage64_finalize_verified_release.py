from __future__ import annotations

import argparse
import csv
import hashlib
import json
from collections import Counter
from pathlib import Path, PureWindowsPath
from typing import Any


EXPECTED = {
    "v5": {
        "cases": 60,
        "lightsabre_swap": 1691,
        "independent_rollout_swap": 1843,
        "baseline_rollout_safe_swap": 1670,
        "selected_swap": 1641,
        "swap_record": (20, 40, 0),
    },
    "v6": {
        "cases": 120,
        "lightsabre_swap": 3176,
        "independent_rollout_swap": 3386,
        "baseline_rollout_safe_swap": 3119,
        "selected_swap": 3051,
        "swap_record": (50, 70, 0),
    },
}

HEADER_RENAMES = {
    "oaabr_variant": "independent_rollout_variant",
    "oaabr_swap": "independent_rollout_swap",
    "oaabr_depth": "independent_rollout_depth",
    "safe_dual_backend": "baseline_rollout_backend",
    "safe_dual_swap": "baseline_rollout_safe_swap",
    "safe_dual_depth": "baseline_rollout_safe_depth",
    "hybrid_swap": "cross_layout_swap",
    "hybrid_depth": "cross_layout_depth",
    "hybrid_attempts": "cross_layout_attempts",
    "gain_vs_safe_dual": "gain_vs_baseline_rollout",
}

BACKEND_RENAMES = {
    "lightsabre": "lightsabre",
    "oaabr": "independent_rollout",
    "hybrid": "cross_layout",
}

EXCLUDED_PUBLIC_COLUMNS = {"qasm", "qpy", "manifest"}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_csv(path: Path) -> tuple[list[str], list[dict[str, str]]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames is None:
            raise ValueError(f"CSV has no header: {path}")
        return list(reader.fieldnames), list(reader)


def write_csv(
    path: Path,
    fieldnames: list[str],
    rows: list[dict[str, Any]],
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def true_value(value: str) -> bool:
    return value.strip().lower() in {"1", "true", "yes"}


def verify_uploaded_manifest(evidence_root: Path) -> list[str]:
    failures: list[str] = []
    manifest = evidence_root / "SHA256SUMS_ALL.csv"
    _, rows = read_csv(manifest)
    seen: set[Path] = set()
    for row in rows:
        windows_path = PureWindowsPath(row["Path"])
        parts = list(windows_path.parts)
        lowered = [part.lower() for part in parts]
        markers = [
            index
            for index, part in enumerate(lowered)
            if part.startswith("stage63_verified_evidence_")
        ]
        if len(markers) != 1:
            failures.append(f"manifest path has no evidence root: {row['Path']}")
            continue
        offset = markers[0]
        local = evidence_root.joinpath(*parts[offset + 1 :])
        if local in seen:
            failures.append(f"duplicate manifest target: {local}")
            continue
        seen.add(local)
        if not local.is_file():
            failures.append(f"missing evidence file: {local}")
            continue
        actual = sha256(local).upper()
        if actual != row["Hash"].upper():
            failures.append(f"evidence hash mismatch: {local}")
    if len(rows) != 18:
        failures.append(f"expected 18 evidence hashes, found {len(rows)}")
    return failures


def dataset_metrics(rows: list[dict[str, str]]) -> dict[str, Any]:
    baseline = sum(int(row["lightsabre_swap"]) for row in rows)
    independent = sum(int(row["oaabr_swap"]) for row in rows)
    baseline_rollout = sum(int(row["safe_dual_swap"]) for row in rows)
    selected = sum(int(row["selected_swap"]) for row in rows)
    differences = [
        int(row["lightsabre_swap"]) - int(row["selected_swap"])
        for row in rows
    ]
    wins = sum(value > 0 for value in differences)
    ties = sum(value == 0 for value in differences)
    losses = sum(value < 0 for value in differences)
    quality_wins = sum(
        (int(row["selected_swap"]), int(row["selected_depth"]))
        < (int(row["lightsabre_swap"]), int(row["lightsabre_depth"]))
        for row in rows
    )
    quality_ties = sum(
        (int(row["selected_swap"]), int(row["selected_depth"]))
        == (int(row["lightsabre_swap"]), int(row["lightsabre_depth"]))
        for row in rows
    )
    quality_losses = len(rows) - quality_wins - quality_ties
    branches = Counter(
        BACKEND_RENAMES.get(row["selected_backend"], row["selected_backend"])
        for row in rows
    )
    return {
        "cases": len(rows),
        "lightsabre_swap": baseline,
        "independent_rollout_swap": independent,
        "baseline_rollout_safe_swap": baseline_rollout,
        "selected_swap": selected,
        "gain_vs_lightsabre": baseline - selected,
        "relative_gain_pct": 100.0 * (baseline - selected) / baseline,
        "swap_wins": wins,
        "swap_ties": ties,
        "swap_losses": losses,
        "quality_wins": quality_wins,
        "quality_ties": quality_ties,
        "quality_losses": quality_losses,
        "selected_branches": dict(sorted(branches.items())),
        "semantic_passed": sum(true_value(row["semantic_equivalent"]) for row in rows),
        "topology_passed": sum(true_value(row["topology_valid"]) for row in rows),
        "metric_passed": sum(true_value(row["metric_valid"]) for row in rows),
    }


def publicize_cases(
    source_fields: list[str],
    rows: list[dict[str, str]],
) -> tuple[list[str], list[dict[str, str]]]:
    fields = [
        HEADER_RENAMES.get(field, field)
        for field in source_fields
        if field not in EXCLUDED_PUBLIC_COLUMNS
    ]
    output: list[dict[str, str]] = []
    for row in rows:
        public: dict[str, str] = {}
        for field in source_fields:
            if field in EXCLUDED_PUBLIC_COLUMNS:
                continue
            target = HEADER_RENAMES.get(field, field)
            value = row[field]
            if field in {"safe_dual_backend", "selected_backend"}:
                value = BACKEND_RENAMES.get(value, value)
            elif field == "selected_label":
                if value.startswith("hybrid:"):
                    value = "cross_layout:" + value.split(":", 1)[1]
                elif value.startswith("native:"):
                    value = "independent_rollout:" + value.split(":", 1)[1]
            public[target] = value
        output.append(public)
    return fields, output


def compare_expected(
    name: str,
    metrics: dict[str, Any],
    failures: list[str],
) -> None:
    expected = EXPECTED[name]
    for field in (
        "cases",
        "lightsabre_swap",
        "independent_rollout_swap",
        "baseline_rollout_safe_swap",
        "selected_swap",
    ):
        if metrics[field] != expected[field]:
            failures.append(
                f"{name} {field}: expected {expected[field]}, found {metrics[field]}"
            )
    record = (
        metrics["swap_wins"],
        metrics["swap_ties"],
        metrics["swap_losses"],
    )
    if record != expected["swap_record"]:
        failures.append(
            f"{name} swap record: expected {expected['swap_record']}, found {record}"
        )
    for audit in ("semantic_passed", "topology_passed", "metric_passed"):
        if metrics[audit] != expected["cases"]:
            failures.append(
                f"{name} {audit}: expected {expected['cases']}, "
                f"found {metrics[audit]}"
            )


def make_report(summary: dict[str, Any]) -> str:
    v5 = summary["datasets"]["v5"]
    v6 = summary["datasets"]["v6"]
    reproduction = summary["reproduction"]
    iid = summary["statistics"]["iid_bootstrap_95_ci"]
    cluster = summary["statistics"]["cluster_bootstrap_95_ci"]
    status = "PASSED" if summary["passed"] else "FAILED"
    return f"""# SMPR Stage 64 最终复现与发布审计

## 结论

本次独立安装复现的最终结论为 **{status}**。上传证据包的外层
SHA-256 与提交值一致，内部 18 个文件全部通过逐文件 SHA-256 校验。

V5 的 60 个实例在严格逐字段策略下与冻结参考一致；V6 的 120 个实例在
主质量字段策略下与冻结参考一致。两组数据的语义、拓扑和指标审计均全部
通过。

## 质量结果

| 数据集 | 实例 | LightSABRE | 独立展开 | 双分支安全选择 | SMPR | 改善 |
|---|---:|---:|---:|---:|---:|---:|
| V5 | {v5['cases']} | {v5['lightsabre_swap']} | {v5['independent_rollout_swap']} | {v5['baseline_rollout_safe_swap']} | {v5['selected_swap']} | {v5['relative_gain_pct']:.4f}% |
| V6 | {v6['cases']} | {v6['lightsabre_swap']} | {v6['independent_rollout_swap']} | {v6['baseline_rollout_safe_swap']} | {v6['selected_swap']} | {v6['relative_gain_pct']:.4f}% |

V6 的逐实例 SWAP 胜/平/负为
{v6['swap_wins']}/{v6['swap_ties']}/{v6['swap_losses']}，质量胜/平/负为
{v6['quality_wins']}/{v6['quality_ties']}/{v6['quality_losses']}。

## 统计稳健性

- 实例级 bootstrap 95% 区间：[{iid[0]:.6f}, {iid[1]:.6f}]；
- 因子单元 cluster bootstrap 95% 区间：
  [{cluster[0]:.6f}, {cluster[1]:.6f}]；
- 两个区间的上端均小于 0；
- 所有留一层级分析的改善均为正。

## 独立复现环境与执行

- Python：{reproduction['python']};
- Qiskit：{reproduction['qiskit']};
- OpenQASM 3 导入器：{reproduction['qasm3_import']};
- V5 墙钟：{reproduction['v5_parallel_wall_seconds']:.3f} s；
- V6 墙钟：{reproduction['v6_parallel_wall_seconds']:.3f} s；
- V5/V6 质量差异数：0/0。

上述墙钟来自本次无逐例时间参考的独立复现，用于确认可执行性，不替换论文
中同一机器、已冻结计时口径下的执行器加速结果。

## 命名与兼容

正式方法统一称为 Safe Multi-Layout Portfolio Router（SMPR）。公开结果表
使用“独立展开”和“跨布局”分支名称。原始冻结 CSV 保留历史字段，仅用于
哈希证据和逐字段复现；不作为论文术语。
"""


def make_latex_table(summary: dict[str, Any]) -> str:
    v5 = summary["datasets"]["v5"]
    v6 = summary["datasets"]["v6"]
    reproduction = summary["reproduction"]
    return f"""% Generated by stage64_finalize_verified_release.py
\\begin{{table}}[H]
\\centering
\\small
\\caption{{Stage 64 独立环境复现}}
\\label{{tab:stage64-reproduction}}
\\begin{{tabular}}{{lrrrrrr}}
\\toprule
数据集 & 实例 & LightSABRE & SMPR & 减少 & 墙钟/s & 差异数 \\\\
\\midrule
V5 & {v5['cases']} & {v5['lightsabre_swap']} & {v5['selected_swap']} &
{v5['gain_vs_lightsabre']} & {reproduction['v5_parallel_wall_seconds']:.3f} & 0 \\\\
V6 & {v6['cases']} & {v6['lightsabre_swap']} & {v6['selected_swap']} &
{v6['gain_vs_lightsabre']} & {reproduction['v6_parallel_wall_seconds']:.3f} & 0 \\\\
\\bottomrule
\\end{{tabular}}
\\end{{table}}
"""


def write_sums(output_dir: Path) -> None:
    files = sorted(
        path
        for path in output_dir.rglob("*")
        if path.is_file() and path.name != "SHA256SUMS.txt"
    )
    lines = [
        f"{sha256(path)}  {path.relative_to(output_dir).as_posix()}"
        for path in files
    ]
    (output_dir / "SHA256SUMS.txt").write_text(
        "\n".join(lines) + "\n",
        encoding="utf-8",
    )


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Build the Stage 64 verified public evidence set"
    )
    parser.add_argument("--evidence-root", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    evidence_root = args.evidence_root.resolve()
    output_dir = args.output_dir.resolve()
    if output_dir.exists():
        raise FileExistsError(f"output directory already exists: {output_dir}")
    output_dir.mkdir(parents=True)

    failures = verify_uploaded_manifest(evidence_root)
    source: dict[str, tuple[list[str], list[dict[str, str]]]] = {}
    metrics: dict[str, dict[str, Any]] = {}
    run_summaries: dict[str, dict[str, Any]] = {}
    for name in ("v5", "v6"):
        source[name] = read_csv(evidence_root / name / "cases.csv")
        metrics[name] = dataset_metrics(source[name][1])
        compare_expected(name, metrics[name], failures)
        run_summaries[name] = load_json(evidence_root / name / "summary.json")
        totals = run_summaries[name]["totals"]
        if totals["selected_swap"] != metrics[name]["selected_swap"]:
            failures.append(f"{name} run summary selected total mismatch")
        if run_summaries[name]["quality_mismatches"] != 0:
            failures.append(f"{name} has frozen quality mismatches")
        if not run_summaries[name]["safe_quality_floor"]:
            failures.append(f"{name} safe quality floor failed")

    audit = load_json(evidence_root / "audit" / "summary.json")
    if not audit.get("passed"):
        failures.append("Stage 61 joint audit did not pass")
    checks = audit.get("checks", {})
    for name, passed in checks.items():
        if not passed:
            failures.append(f"Stage 61 check failed: {name}")

    iid = list(audit["v6"]["iid_bootstrap_95_ci"])
    cluster = list(audit["v6"]["cluster_bootstrap_95_ci"])
    if iid[1] >= 0:
        failures.append("iid bootstrap upper bound is not below zero")
    if cluster[1] >= 0:
        failures.append("cluster bootstrap upper bound is not below zero")

    versions = (
        evidence_root / "environment" / "qiskit-versions.txt"
    ).read_text(encoding="utf-8-sig")
    python_version = (
        evidence_root / "environment" / "python-version.txt"
    ).read_text(encoding="utf-8-sig").strip()
    if "Qiskit: 2.4.2" not in versions:
        failures.append("Qiskit 2.4.2 was not recorded")
    if "qiskit-qasm3-import: 0.6.0" not in versions:
        failures.append("qiskit-qasm3-import 0.6.0 was not recorded")

    summary: dict[str, Any] = {
        "stage": 64,
        "purpose": "independent reproduction and public evidence finalization",
        "passed": not failures,
        "failures": failures,
        "datasets": metrics,
        "statistics": {
            "iid_bootstrap_95_ci": iid,
            "cluster_bootstrap_95_ci": cluster,
            "all_leave_one_level_out_gains_positive": checks.get(
                "all_leave_one_level_out_gains_positive",
                False,
            ),
        },
        "reproduction": {
            "python": python_version,
            "qiskit": "2.4.2",
            "qasm3_import": "0.6.0",
            "v5_parallel_wall_seconds": run_summaries["v5"][
                "parallel_wall_seconds"
            ],
            "v6_parallel_wall_seconds": run_summaries["v6"][
                "parallel_wall_seconds"
            ],
            "v5_effective_parallelism": run_summaries["v5"][
                "effective_parallelism"
            ],
            "v6_effective_parallelism": run_summaries["v6"][
                "effective_parallelism"
            ],
            "v5_quality_policy": run_summaries["v5"]["quality_policy"],
            "v6_quality_policy": run_summaries["v6"]["quality_policy"],
        },
        "source_hashes": {
            "uploaded_evidence_zip": (
                "6c7f38aecea6318b3a8407a73d8f5ae67223ea8853e8f2bc3839261c9af3a85d"
            ),
            "v5_cases": sha256(evidence_root / "v5" / "cases.csv"),
            "v6_cases": sha256(evidence_root / "v6" / "cases.csv"),
            "stage61_summary": sha256(
                evidence_root / "audit" / "summary.json"
            ),
        },
    }

    for name in ("v5", "v6"):
        fields, rows = publicize_cases(*source[name])
        target = output_dir / f"{name}_public_cases.csv"
        write_csv(target, fields, rows)
        public_text = target.read_text(encoding="utf-8").lower()
        if "oaabr" in public_text or "hybrid" in public_text:
            failures.append(f"legacy internal name leaked into {target.name}")

    summary["passed"] = not failures
    summary["failures"] = failures
    (output_dir / "summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    (output_dir / "FINAL_VERIFIED_REPORT.md").write_text(
        make_report(summary),
        encoding="utf-8",
    )
    (output_dir / "paper_reproduction_table.tex").write_text(
        make_latex_table(summary),
        encoding="utf-8",
    )
    write_sums(output_dir)

    print("===== Stage 64 verified evidence finalization =====")
    print("V5 selected / LightSABRE:", metrics["v5"]["selected_swap"], "/", metrics["v5"]["lightsabre_swap"])
    print("V6 selected / LightSABRE:", metrics["v6"]["selected_swap"], "/", metrics["v6"]["lightsabre_swap"])
    print("evidence hashes:", "18/18")
    print("public legacy-name leaks:", sum("legacy internal name" in item for item in failures))
    print("PASSED:", summary["passed"])
    print("report:", (output_dir / "FINAL_VERIFIED_REPORT.md").resolve())
    print("summary:", (output_dir / "summary.json").resolve())
    print("hashes:", (output_dir / "SHA256SUMS.txt").resolve())
    if failures:
        for failure in failures:
            print("  -", failure)
        raise RuntimeError(f"Stage 64 finalization failed with {len(failures)} errors")


if __name__ == "__main__":
    main()
