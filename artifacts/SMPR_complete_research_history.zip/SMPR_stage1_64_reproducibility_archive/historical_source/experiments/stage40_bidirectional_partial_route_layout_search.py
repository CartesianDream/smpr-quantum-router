from __future__ import annotations

import argparse
import csv
import json
import math
import time
from dataclasses import asdict, dataclass, replace
from pathlib import Path

import stage20_score_structure_ablation as stage20
import stage21_policy_portfolio as stage21
import stage33_large_topology_probe as stage33
import stage36_policy_aware_fb_layout as stage36
import stage37_proxy_local_layout_refinement as stage37
import stage39_layout_router_cross_decomposition as stage39

from stage7_initial_mapping_pool import MappingCandidate
from stage10_dev_benchmark import DevCase, load_cases


@dataclass
class CandidateProbe:
    instance: str
    round_index: int
    mapping_name: str
    mutation: str
    mapping: str
    selected_by_static: str
    partial_forward_swap: int | None
    partial_forward_depth: int | None
    partial_backward_swap: int | None
    partial_backward_depth: int | None
    partial_swap: int | None
    partial_depth: int | None
    partial_runtime_ms: float
    selected_for_full_route: bool
    full_swap: int | None
    full_depth: int | None
    full_runtime_ms: float
    valid: bool
    error: str


@dataclass
class CaseResult:
    instance: str
    topology: str
    circuit_mode: str
    logical_qubits: int
    physical_qubits: int
    cx_count: int
    search_policy: str
    search_rounds_requested: int
    search_rounds_completed: int
    proxy_top: int
    partial_fraction: float
    partial_top: int

    stage37_mapping: str
    stage37_swap: int
    stage37_depth: int
    selected_mapping: str
    selected_mutations: str
    searched_swap: int
    searched_depth: int
    improvement: int

    static_candidates: int
    partial_candidates: int
    full_candidates: int
    partial_budget_ms: float
    full_budget_ms: float
    total_budget_ms: float

    lightsabre_swap: int
    lightsabre_depth: int
    swap_gap: int
    depth_gap: int
    outcome: str


def read_csv(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        raise FileNotFoundError(f"找不到文件：{path.resolve()}")
    with path.open("r", encoding="utf-8-sig", newline="") as file:
        return list(csv.DictReader(file))


def save_csv(path: Path, rows: list, fields) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=fields)
        writer.writeheader()
        writer.writerows(asdict(row) for row in rows)


def partial_case(
    case: DevCase,
    gate_specs: tuple[tuple, ...],
    suffix: str,
) -> DevCase:
    return DevCase(
        test_case=replace(
            case.test_case,
            name=f"{case.name}_{suffix}",
            gate_specs=gate_specs,
        ),
        split=case.split,
        topology=case.topology,
        circuit_mode=case.circuit_mode,
        source_seed=case.source_seed,
    )


def build_partial_cases(
    case: DevCase,
    fraction: float,
) -> tuple[DevCase, DevCase, int]:
    gates = tuple(case.test_case.gate_specs)
    count = max(1, min(len(gates), math.ceil(len(gates) * fraction)))
    forward = partial_case(case, gates[:count], f"prefix_{count}")
    backward = partial_case(
        case,
        tuple(reversed(gates[-count:])),
        f"reverse_suffix_{count}",
    )
    return forward, backward, count


def outcome_text(ours: tuple[int, int], qiskit: tuple[int, int]) -> str:
    if ours < qiskit:
        return "OAABR胜"
    if ours == qiskit:
        return "平局"
    return "LightSABRE胜"


def summarize(rows: list[CaseResult]) -> dict:
    old = sum(row.stage37_swap for row in rows)
    searched = sum(row.searched_swap for row in rows)
    lightsabre = sum(row.lightsabre_swap for row in rows)
    return {
        "case_count": len(rows),
        "stage37_swap": old,
        "stage40_swap": searched,
        "improvement": old - searched,
        "lightsabre_swap": lightsabre,
        "swap_gap": searched - lightsabre,
        "improved_cases": sum(row.improvement > 0 for row in rows),
        "partial_budget_ms": sum(row.partial_budget_ms for row in rows),
        "full_budget_ms": sum(row.full_budget_ms for row in rows),
        "total_budget_ms": sum(row.total_budget_ms for row in rows),
    }


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Stage 40：双向短路由代理驱动的多轮布局搜索"
    )
    parser.add_argument(
        "--input", type=Path, default=Path("data/benchmarks_large_v1/probe.json")
    )
    parser.add_argument("--case-indices", type=str, default="7")
    parser.add_argument(
        "--stage36-cases", type=Path,
        default=Path("results/stage38_alternating_stage36_cases.csv"),
    )
    parser.add_argument(
        "--stage36-polish", type=Path,
        default=Path("results/stage38_alternating_polish.csv"),
    )
    parser.add_argument(
        "--stage37-cases", type=Path,
        default=Path("results/stage38_alternating_stage37_cases.csv"),
    )
    parser.add_argument(
        "--stage37-candidates", type=Path,
        default=Path("results/stage38_alternating_candidates.csv"),
    )
    parser.add_argument("--anchor-trials", type=int, default=4)
    parser.add_argument("--search-policy", type=str, default="front_sum")
    parser.add_argument("--search-rounds", type=int, default=2)
    parser.add_argument("--proxy-top", type=int, default=10)
    parser.add_argument("--early-weight", type=float, default=2.0)
    parser.add_argument("--partial-fraction", type=float, default=0.25)
    parser.add_argument("--partial-top", type=int, default=6)
    parser.add_argument(
        "--probe-output", type=Path,
        default=Path("results/stage40_probes.csv"),
    )
    parser.add_argument(
        "--case-output", type=Path,
        default=Path("results/stage40_cases.csv"),
    )
    parser.add_argument(
        "--summary-output", type=Path,
        default=Path("results/stage40_summary.json"),
    )
    args = parser.parse_args()
    if args.search_rounds <= 0 or args.proxy_top <= 0 or args.partial_top <= 0:
        raise ValueError("search-rounds、proxy-top、partial-top必须为正数")
    if not 0.0 < args.partial_fraction <= 0.5:
        raise ValueError("partial-fraction必须在(0, 0.5]内")
    if args.early_weight < 0 or args.anchor_trials <= 0:
        raise ValueError("early-weight必须非负，anchor-trials必须为正")
    if args.search_policy not in stage20.CONFIG_BY_NAME:
        raise ValueError(f"未知search-policy：{args.search_policy}")

    stage33.configure_router()
    config = stage20.CONFIG_BY_NAME[args.search_policy]
    cases = stage21.choose_cases(
        load_cases(args.input, limit=None),
        stage21.parse_indices(args.case_indices),
        None,
    )
    stage36_rows = {row["instance"]: row for row in read_csv(args.stage36_cases)}
    polish_rows = read_csv(args.stage36_polish)
    stage37_rows = {row["instance"]: row for row in read_csv(args.stage37_cases)}
    candidate_rows = {
        (row["instance"], row["mapping_name"]): row
        for row in read_csv(args.stage37_candidates)
    }
    missing = [case.name for case in cases if case.name not in stage37_rows]
    if missing:
        raise ValueError("Stage 37 cases CSV缺少实例：" + ", ".join(missing))

    print("===== Stage 40：双向短路由代理布局搜索 =====")
    print(f"输入：{args.input.resolve()}")
    print(f"实例数：{len(cases)}")
    print(
        f"搜索：rounds={args.search_rounds}, static-top={args.proxy_top}/proxy, "
        f"partial={args.partial_fraction:.2f}, partial-top={args.partial_top}"
    )
    print(f"短路由与完整路由策略：{config.name}")
    print("每轮保留旧布局；若没有严格改善则提前停止。")

    all_probes: list[CandidateProbe] = []
    results: list[CaseResult] = []
    for case_index, case in enumerate(cases, start=1):
        print(f"[{case_index}/{len(cases)}] {case.name} ...", flush=True)
        reference = stage37_rows[case.name]
        parent = stage39.recover_ours_mapping(
            case=case,
            stage37_row=reference,
            candidate_rows=candidate_rows,
            stage36_rows=stage36_rows,
            polish_rows=polish_rows,
            anchor_trials=args.anchor_trials,
        )
        current_swap = int(reference["refined_swap"])
        current_depth = int(reference["refined_depth"])
        current_name = reference["selected_mapping"]
        mutations: list[str] = []
        forward_case, backward_case, partial_gate_count = build_partial_cases(
            case, args.partial_fraction
        )

        static_count = 0
        partial_count = 0
        full_count = 0
        partial_budget = 0.0
        full_budget = 0.0
        completed_rounds = 0

        for round_index in range(1, args.search_rounds + 1):
            neighbors = stage37.build_neighbors(case, parent)
            proxy_candidates, selected = stage37.proxy_rows(
                case=case,
                neighbors=neighbors,
                proxy_top=args.proxy_top,
                early_weight=args.early_weight,
            )
            static_count += len(neighbors)
            by_mapping = {
                stage37.parse_mapping(row.mapping): row
                for row in proxy_candidates
            }
            round_probes: list[tuple[tuple[int, ...], CandidateProbe]] = []
            for candidate_index, mapping in enumerate(
                sorted(selected, key=lambda item: (by_mapping[item].mutation, item))
            ):
                source = by_mapping[mapping]
                name = f"stage40_r{round_index}_n{candidate_index}_{source.mutation}"
                start = time.perf_counter()
                try:
                    _end, forward_swap, forward_depth, _ = stage36.route_endpoint(
                        forward_case, mapping, config
                    )
                    _end, backward_swap, backward_depth, _ = stage36.route_endpoint(
                        backward_case, mapping, config
                    )
                    elapsed = (time.perf_counter() - start) * 1000.0
                    probe = CandidateProbe(
                        instance=case.name,
                        round_index=round_index,
                        mapping_name=name,
                        mutation=source.mutation,
                        mapping=stage37.mapping_text(mapping),
                        selected_by_static=source.selected_by,
                        partial_forward_swap=forward_swap,
                        partial_forward_depth=forward_depth,
                        partial_backward_swap=backward_swap,
                        partial_backward_depth=backward_depth,
                        partial_swap=forward_swap + backward_swap,
                        partial_depth=forward_depth + backward_depth,
                        partial_runtime_ms=elapsed,
                        selected_for_full_route=False,
                        full_swap=None,
                        full_depth=None,
                        full_runtime_ms=0.0,
                        valid=True,
                        error="",
                    )
                except Exception as error:
                    elapsed = (time.perf_counter() - start) * 1000.0
                    probe = CandidateProbe(
                        instance=case.name,
                        round_index=round_index,
                        mapping_name=name,
                        mutation=source.mutation,
                        mapping=stage37.mapping_text(mapping),
                        selected_by_static=source.selected_by,
                        partial_forward_swap=None,
                        partial_forward_depth=None,
                        partial_backward_swap=None,
                        partial_backward_depth=None,
                        partial_swap=None,
                        partial_depth=None,
                        partial_runtime_ms=elapsed,
                        selected_for_full_route=False,
                        full_swap=None,
                        full_depth=None,
                        full_runtime_ms=0.0,
                        valid=False,
                        error=f"{type(error).__name__}: {error}",
                    )
                partial_budget += elapsed
                partial_count += 1
                round_probes.append((mapping, probe))
                all_probes.append(probe)

            valid_partial = [
                item for item in round_probes
                if item[1].valid and item[1].partial_swap is not None
            ]
            ranked = sorted(
                valid_partial,
                key=lambda item: (
                    int(item[1].partial_swap),
                    int(item[1].partial_depth),
                    item[1].mutation,
                    item[0],
                ),
            )[: args.partial_top]

            round_best = (
                current_swap,
                current_depth,
                parent,
                current_name,
                "stage37_fallback",
            )
            for mapping, probe in ranked:
                probe.selected_for_full_route = True
                candidate = MappingCandidate(probe.mapping_name, mapping, 0.0)
                attempt = stage33.run_attempt(case, candidate, 0.0, config)
                probe.full_runtime_ms = attempt.runtime_ms
                full_budget += attempt.runtime_ms
                full_count += 1
                if attempt.valid:
                    probe.full_swap = int(attempt.swap)
                    probe.full_depth = int(attempt.depth)
                    value = (
                        int(attempt.swap),
                        int(attempt.depth),
                        mapping,
                        candidate.name,
                        probe.mutation,
                    )
                    if (value[0], value[1], value[3]) < (
                        round_best[0], round_best[1], round_best[3]
                    ):
                        round_best = value
                else:
                    probe.valid = False
                    probe.error = attempt.error

            completed_rounds = round_index
            improved = (round_best[0], round_best[1]) < (
                current_swap, current_depth
            )
            print(
                f"  round {round_index}: static={len(neighbors)}, "
                f"partial={len(selected)}, full={len(ranked)}, "
                f"best={round_best[0]}/{round_best[1]}, "
                f"improved={improved}",
                flush=True,
            )
            if not improved:
                break
            current_swap, current_depth = round_best[0], round_best[1]
            parent, current_name = round_best[2], round_best[3]
            mutations.append(round_best[4])

            save_csv(
                args.probe_output,
                all_probes,
                CandidateProbe.__annotations__.keys(),
            )

        lightsabre = (
            int(reference["lightsabre_swap"]),
            int(reference["lightsabre_depth"]),
        )
        ours = (current_swap, current_depth)
        row = CaseResult(
            instance=case.name,
            topology=case.topology,
            circuit_mode=case.circuit_mode,
            logical_qubits=case.num_qubits,
            physical_qubits=case.test_case.num_physical_qubits,
            cx_count=case.two_qubit_gate_count,
            search_policy=config.name,
            search_rounds_requested=args.search_rounds,
            search_rounds_completed=completed_rounds,
            proxy_top=args.proxy_top,
            partial_fraction=args.partial_fraction,
            partial_top=args.partial_top,
            stage37_mapping=reference["selected_mapping"],
            stage37_swap=int(reference["refined_swap"]),
            stage37_depth=int(reference["refined_depth"]),
            selected_mapping=current_name,
            selected_mutations=";".join(mutations) if mutations else "fallback",
            searched_swap=current_swap,
            searched_depth=current_depth,
            improvement=int(reference["refined_swap"]) - current_swap,
            static_candidates=static_count,
            partial_candidates=partial_count,
            full_candidates=full_count,
            partial_budget_ms=partial_budget,
            full_budget_ms=full_budget,
            total_budget_ms=partial_budget + full_budget,
            lightsabre_swap=lightsabre[0],
            lightsabre_depth=lightsabre[1],
            swap_gap=current_swap - lightsabre[0],
            depth_gap=current_depth - lightsabre[1],
            outcome=outcome_text(ours, lightsabre),
        )
        results.append(row)
        print(
            f"  Stage37={row.stage37_swap}/{row.stage37_depth}, "
            f"Stage40={row.searched_swap}/{row.searched_depth}, "
            f"DeltaSWAP=-{row.improvement}"
        )
        print(
            f"  LightSABRE={row.lightsabre_swap}/{row.lightsabre_depth}, "
            f"gap={row.swap_gap:+d}, {row.outcome}, "
            f"partial-gates={partial_gate_count}, "
            f"budget={row.total_budget_ms:.1f} ms"
        )

        save_csv(
            args.probe_output,
            all_probes,
            CandidateProbe.__annotations__.keys(),
        )
        save_csv(args.case_output, results, CaseResult.__annotations__.keys())
        args.summary_output.parent.mkdir(parents=True, exist_ok=True)
        args.summary_output.write_text(
            json.dumps(summarize(results), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    summary = summarize(results)
    print("\n===== Stage 40 汇总 =====")
    print(f"Stage 37 total SWAP：{summary['stage37_swap']}")
    print(f"Stage 40 total SWAP：{summary['stage40_swap']}")
    print(f"双向短路由搜索减少：{summary['improvement']}")
    print(f"LightSABRE total SWAP：{summary['lightsabre_swap']}")
    print(f"相对 LightSABRE gap：{summary['swap_gap']:+d}")
    print(
        f"预算 partial/full/total：{summary['partial_budget_ms']:.1f}/"
        f"{summary['full_budget_ms']:.1f}/{summary['total_budget_ms']:.1f} ms"
    )
    print(f"探针明细：{args.probe_output.resolve()}")
    print(f"逐实例：{args.case_output.resolve()}")
    print(f"汇总：{args.summary_output.resolve()}")


if __name__ == "__main__":
    main()
