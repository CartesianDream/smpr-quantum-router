from __future__ import annotations

import argparse
import csv
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Row:
    instance: str
    method: str
    seed: int | None
    mapping: str
    swap_count: int
    added_two_qubit_count: int
    weighted_depth: int
    generation_ms: float
    routing_ms: float
    total_ms: float
    valid: bool
    error: str

    @property
    def score(self) -> tuple[int, int]:
        return (
            self.added_two_qubit_count,
            self.weighted_depth,
        )

    @property
    def is_oaabr(self) -> bool:
        return self.method.startswith("OAABR:")

    @property
    def is_qiskit(self) -> bool:
        return self.method == "QiskitSABRE:auto"

    @property
    def mapping_name(self) -> str:
        if not self.is_oaabr:
            return self.method
        return self.method.split(":", 1)[1]

    @property
    def is_fb(self) -> bool:
        return self.mapping_name.endswith("_fb")


def parse_optional_int(value: str) -> int | None:
    value = value.strip()
    if value == "":
        return None
    return int(value)


def load_rows(path: Path) -> list[Row]:
    rows: list[Row] = []

    with path.open(
        "r",
        encoding="utf-8-sig",
        newline="",
    ) as file:
        reader = csv.DictReader(file)

        for raw in reader:
            valid = raw["valid"].strip().lower() == "true"

            if not valid:
                continue

            rows.append(
                Row(
                    instance=raw["instance"],
                    method=raw["method"],
                    seed=parse_optional_int(raw["seed"]),
                    mapping=raw["mapping"],
                    swap_count=int(raw["swap_count"]),
                    added_two_qubit_count=int(
                        raw["added_two_qubit_count"]
                    ),
                    weighted_depth=int(raw["weighted_depth"]),
                    generation_ms=float(raw["generation_ms"]),
                    routing_ms=float(raw["routing_ms"]),
                    total_ms=float(raw["total_ms"]),
                    valid=valid,
                    error=raw.get("error", ""),
                )
            )

    return rows


def best_row(rows: list[Row]) -> Row:
    if not rows:
        raise ValueError("无法从空集合选择最优结果")

    return min(
        rows,
        key=lambda row: (
            row.score,
            row.total_ms,
            row.seed if row.seed is not None else -1,
        ),
    )


def compare_scores(
    left: tuple[int, int],
    right: tuple[int, int],
) -> str:
    if left < right:
        return "OAABR胜"
    if left > right:
        return "Qiskit胜"
    return "平局"


def estimate_oaabr_pool_budget(
    rows: list[Row],
) -> float:
    """
    估计完整映射池的总计算预算。

    stage7 的每个 _fb 候选 generation_ms 包含：
        对应基础映射生成时间 + 正反虚拟路由时间。

    为避免把基础映射生成时间重复计算：
    1. 基础候选的 generation_ms 全部相加一次；
    2. _fb 候选只加超出对应基础候选的部分；
    3. 所有候选的真实路由时间都相加。
    """

    base_generation: dict[str, float] = {}

    for row in rows:
        if row.is_fb:
            continue

        base_generation[row.mapping_name] = row.generation_ms

    generation_budget = sum(base_generation.values())

    for row in rows:
        if not row.is_fb:
            continue

        base_name = row.mapping_name.removesuffix("_fb")
        already_counted = base_generation.get(base_name, 0.0)

        generation_budget += max(
            0.0,
            row.generation_ms - already_counted,
        )

    routing_budget = sum(row.routing_ms for row in rows)

    return generation_budget + routing_budget


def write_summary_csv(
    output_path: Path,
    summary_rows: list[dict[str, object]],
) -> None:
    output_path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    fieldnames = [
        "instance",
        "oaabr_best_method",
        "oaabr_swap",
        "oaabr_added_2q",
        "oaabr_depth",
        "qiskit_best_seed",
        "qiskit_swap",
        "qiskit_added_2q",
        "qiskit_depth",
        "quality_result",
        "oaabr_pool_budget_ms",
        "qiskit_multiseed_budget_ms",
        "budget_ratio_oaabr_over_qiskit",
        "base_pool_added_2q",
        "base_pool_depth",
        "fb_improved",
    ]

    with output_path.open(
        "w",
        encoding="utf-8-sig",
        newline="",
    ) as file:
        writer = csv.DictWriter(
            file,
            fieldnames=fieldnames,
        )
        writer.writeheader()
        writer.writerows(summary_rows)


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "公平分析 stage7：比较完整映射池总预算与 "
            "Qiskit SABRE 多随机种子总预算"
        )
    )

    parser.add_argument(
        "--input",
        type=Path,
        default=Path(
            "results/stage7_initial_mapping_pool_20seeds.csv"
        ),
        help="stage7 CSV 文件路径",
    )

    parser.add_argument(
        "--output",
        type=Path,
        default=Path(
            "results/stage8_budget_summary.csv"
        ),
        help="汇总 CSV 输出路径",
    )

    args = parser.parse_args()

    if not args.input.exists():
        raise FileNotFoundError(
            f"找不到输入文件：{args.input.resolve()}"
        )

    rows = load_rows(args.input)

    grouped: dict[str, list[Row]] = defaultdict(list)

    for row in rows:
        grouped[row.instance].append(row)

    summary_rows: list[dict[str, object]] = []
    outcomes: Counter[str] = Counter()
    best_mapping_counter: Counter[str] = Counter()
    fb_improvement_count = 0

    total_oaabr_budget = 0.0
    total_qiskit_budget = 0.0

    print("=" * 112)
    print("Stage 8：质量—计算预算公平分析")
    print("质量比较采用字典序：(附加双比特门数, 加权深度)")
    print("=" * 112)

    for instance in sorted(grouped):
        instance_rows = grouped[instance]

        oaabr_rows = [
            row
            for row in instance_rows
            if row.is_oaabr
        ]

        qiskit_rows = [
            row
            for row in instance_rows
            if row.is_qiskit
        ]

        if not oaabr_rows or not qiskit_rows:
            raise RuntimeError(
                f"{instance} 缺少 OAABR 或 Qiskit 结果"
            )

        oaabr_best = best_row(oaabr_rows)
        qiskit_best = best_row(qiskit_rows)

        base_rows = [
            row
            for row in oaabr_rows
            if not row.is_fb
        ]
        base_best = best_row(base_rows)

        quality_result = compare_scores(
            oaabr_best.score,
            qiskit_best.score,
        )

        fb_improved = oaabr_best.score < base_best.score

        if fb_improved:
            fb_improvement_count += 1

        outcomes[quality_result] += 1
        best_mapping_counter[
            oaabr_best.mapping_name
        ] += 1

        oaabr_budget = estimate_oaabr_pool_budget(
            oaabr_rows
        )
        qiskit_budget = sum(
            row.total_ms
            for row in qiskit_rows
        )

        total_oaabr_budget += oaabr_budget
        total_qiskit_budget += qiskit_budget

        budget_ratio = (
            oaabr_budget / qiskit_budget
            if qiskit_budget > 0
            else float("inf")
        )

        print()
        print(f"[{instance}]")
        print(
            "OAABR 最优："
            f"{oaabr_best.mapping_name}, "
            f"SWAP={oaabr_best.swap_count}, "
            f"附加2q={oaabr_best.added_two_qubit_count}, "
            f"深度={oaabr_best.weighted_depth}"
        )
        print(
            "Qiskit 最优："
            f"seed={qiskit_best.seed}, "
            f"SWAP={qiskit_best.swap_count}, "
            f"附加2q={qiskit_best.added_two_qubit_count}, "
            f"深度={qiskit_best.weighted_depth}"
        )
        print("质量结论：", quality_result)
        print(
            "OAABR 映射池总预算："
            f"{oaabr_budget:.3f} ms"
        )
        print(
            "Qiskit 多种子总预算："
            f"{qiskit_budget:.3f} ms"
        )
        print(
            "预算比 OAABR/Qiskit："
            f"{budget_ratio:.3f}"
        )
        print(
            "正反遍历是否改善基础池最优质量：",
            fb_improved,
        )

        summary_rows.append(
            {
                "instance": instance,
                "oaabr_best_method": (
                    oaabr_best.mapping_name
                ),
                "oaabr_swap": oaabr_best.swap_count,
                "oaabr_added_2q": (
                    oaabr_best.added_two_qubit_count
                ),
                "oaabr_depth": (
                    oaabr_best.weighted_depth
                ),
                "qiskit_best_seed": qiskit_best.seed,
                "qiskit_swap": qiskit_best.swap_count,
                "qiskit_added_2q": (
                    qiskit_best.added_two_qubit_count
                ),
                "qiskit_depth": (
                    qiskit_best.weighted_depth
                ),
                "quality_result": quality_result,
                "oaabr_pool_budget_ms": (
                    f"{oaabr_budget:.3f}"
                ),
                "qiskit_multiseed_budget_ms": (
                    f"{qiskit_budget:.3f}"
                ),
                "budget_ratio_oaabr_over_qiskit": (
                    f"{budget_ratio:.6f}"
                ),
                "base_pool_added_2q": (
                    base_best.added_two_qubit_count
                ),
                "base_pool_depth": (
                    base_best.weighted_depth
                ),
                "fb_improved": fb_improved,
            }
        )

    write_summary_csv(
        output_path=args.output,
        summary_rows=summary_rows,
    )

    print()
    print("=" * 112)
    print("总体结论")
    print("=" * 112)
    print("OAABR 胜：", outcomes["OAABR胜"])
    print("平局：", outcomes["平局"])
    print("Qiskit 胜：", outcomes["Qiskit胜"])
    print(
        "正反遍历改善基础映射池的实例数：",
        fb_improvement_count,
        "/",
        len(grouped),
    )
    print(
        "OAABR 最优映射来源：",
        dict(best_mapping_counter),
    )
    print(
        "OAABR 全部实例总预算："
        f"{total_oaabr_budget:.3f} ms"
    )
    print(
        "Qiskit 全部实例多种子总预算："
        f"{total_qiskit_budget:.3f} ms"
    )

    if total_qiskit_budget > 0:
        print(
            "总体预算比 OAABR/Qiskit："
            f"{total_oaabr_budget / total_qiskit_budget:.3f}"
        )

    print()
    print("汇总 CSV 已保存到：", args.output.resolve())


if __name__ == "__main__":
    main()
