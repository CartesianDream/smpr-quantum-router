from __future__ import annotations

import argparse
import csv
import json
import time
from collections import Counter, defaultdict, deque
from dataclasses import asdict, dataclass
from pathlib import Path

import stage20_score_structure_ablation as stage20
import stage21_policy_portfolio as stage21

from stage1_core import CircuitDAG, HardwareGraph
from stage7_initial_mapping_pool import MappingCandidate, build_interaction_matrices
from stage10_dev_benchmark import DevCase, load_cases
from stage17_validation_select import run_qiskit_multiseed


DEFAULT_POLICIES = "simpletes_ordered,front_sum"


@dataclass
class Attempt:
    instance: str
    topology: str
    logical_qubits: int
    physical_qubits: int
    mapping: str
    policy: str
    proxy_cost: float
    swap: int | None
    depth: int | None
    runtime_ms: float
    valid: bool
    error: str


@dataclass
class CaseResult:
    instance: str
    topology: str
    circuit_mode: str
    logical_qubits: int
    physical_qubits: int
    cx_count: int
    topology_is_exact_hardware: bool
    mappings_generated: int
    mappings_routed: int
    policies: str
    selected_mapping: str
    selected_policy: str
    router_swap: int
    router_depth: int
    router_budget_ms: float
    lightsabre_seed: int
    lightsabre_swap: int
    lightsabre_depth: int
    lightsabre_budget_ms: float
    swap_gap: int
    depth_gap: int
    outcome: str


def configure_router() -> None:
    stage20.stage2.THETA = 5
    stage20.stage2.W_FUTURE = 0.5
    stage20.stage2.GAMMA = 0.5
    stage20.stage2.ALPHA = 0.5
    stage20.stage2.LAMBDA_DEPTH = 0.0


def parse_policies(text: str) -> list[stage20.StructuralConfig]:
    names = [value.strip() for value in text.split(",") if value.strip()]
    if not names:
        raise ValueError("至少需要一个策略")
    unknown = [name for name in names if name not in stage20.CONFIG_BY_NAME]
    if unknown:
        raise ValueError(f"未知策略：{unknown}")
    return [stage20.CONFIG_BY_NAME[name] for name in names]


def all_pairs_distances(hardware: HardwareGraph) -> list[list[int]]:
    n = hardware.num_qubits
    result = [[10**9] * n for _ in range(n)]
    for source in range(n):
        result[source][source] = 0
        queue: deque[int] = deque([source])
        while queue:
            u = queue.popleft()
            for v in hardware.adjacency[u]:
                if result[source][v] == 10**9:
                    result[source][v] = result[source][u] + 1
                    queue.append(v)
    if any(value == 10**9 for row in result for value in row):
        raise ValueError("硬件图不连通")
    return result


def matrix_cost(
    mapping: list[int] | tuple[int, ...],
    matrix: list[list[float]],
    distances: list[list[int]],
) -> float:
    value = 0.0
    for i in range(len(mapping)):
        for j in range(i + 1, len(mapping)):
            if matrix[i][j]:
                value += matrix[i][j] * (distances[mapping[i]][mapping[j]] - 1)
    return value


def choose_anchors(
    hardware: HardwareGraph,
    distances: list[list[int]],
    count: int,
) -> list[int]:
    center_cost = [sum(row) for row in distances]
    ranked = sorted(
        range(hardware.num_qubits),
        key=lambda p: (center_cost[p], -len(hardware.adjacency[p]), p),
    )
    anchors: list[int] = []
    for candidate in ranked:
        # 避免所有 trial 都落在几乎相同的中心点。
        if all(distances[candidate][old] >= 2 for old in anchors):
            anchors.append(candidate)
        if len(anchors) == count:
            break
    if len(anchors) < count:
        for candidate in ranked:
            if candidate not in anchors:
                anchors.append(candidate)
            if len(anchors) == count:
                break
    return anchors


def compact_region(
    anchor: int,
    logical_qubits: int,
    hardware: HardwareGraph,
    distances: list[list[int]],
) -> list[int]:
    center_cost = [sum(row) for row in distances]
    return sorted(
        range(hardware.num_qubits),
        key=lambda p: (
            distances[anchor][p],
            -len(hardware.adjacency[p]),
            center_cost[p],
            p,
        ),
    )[:logical_qubits]


def greedy_mapping_in_region(
    matrix: list[list[float]],
    region: list[int],
    anchor: int,
    hardware: HardwareGraph,
    distances: list[list[int]],
) -> list[int]:
    logical_n = len(matrix)
    logical_degree = [sum(row) for row in matrix]
    first_logical = min(range(logical_n), key=lambda q: (-logical_degree[q], q))
    first_physical = anchor if anchor in region else region[0]
    mapping = [-1] * logical_n
    mapping[first_logical] = first_physical
    placed = {first_logical}
    used = {first_physical}

    while len(placed) < logical_n:
        remaining = [q for q in range(logical_n) if q not in placed]
        logical = min(
            remaining,
            key=lambda q: (
                -sum(matrix[q][other] for other in placed),
                -logical_degree[q],
                q,
            ),
        )
        free = [p for p in region if p not in used]
        physical = min(
            free,
            key=lambda p: (
                sum(
                    matrix[logical][other] * distances[p][mapping[other]]
                    for other in placed
                ),
                -len(hardware.adjacency[p]),
                distances[anchor][p],
                p,
            ),
        )
        mapping[logical] = physical
        placed.add(logical)
        used.add(physical)
    return mapping


def compact_mapping_pool(
    case: DevCase,
    anchor_trials: int,
) -> tuple[list[tuple[MappingCandidate, float]], int]:
    dag, hardware, _ = case.test_case.build()
    distances = all_pairs_distances(hardware)
    matrices = build_interaction_matrices(dag)
    anchors = choose_anchors(hardware, distances, anchor_trials)
    all_matrix = matrices["all"]
    generated: list[tuple[MappingCandidate, float]] = []
    seen: set[tuple[int, ...]] = set()

    for matrix_name in ("all", "early", "late"):
        matrix = matrices[matrix_name]
        for trial, anchor in enumerate(anchors):
            start = time.perf_counter()
            region = compact_region(
                anchor, dag.num_logical_qubits, hardware, distances
            )
            mapping = tuple(
                greedy_mapping_in_region(
                    matrix, region, anchor, hardware, distances
                )
            )
            elapsed_ms = (time.perf_counter() - start) * 1000.0
            if mapping in seen:
                continue
            seen.add(mapping)
            generated.append(
                (
                    MappingCandidate(
                        name=f"compact_{matrix_name}_a{trial}",
                        mapping=mapping,
                        generation_ms=elapsed_ms,
                    ),
                    matrix_cost(mapping, all_matrix, distances),
                )
            )
    generated.sort(key=lambda row: (row[1], row[0].name))
    return generated, len(generated)


def run_attempt(
    case: DevCase,
    mapping: MappingCandidate,
    proxy_cost: float,
    config: stage20.StructuralConfig,
) -> Attempt:
    dag, hardware, _ = case.test_case.build()
    start = time.perf_counter()
    try:
        state = stage20.run_router(
            dag=dag,
            hardware=hardware,
            initial_mapping=list(mapping.mapping),
            config=config,
        )
        state.assert_valid(dag, hardware)
        swap = sum(op[0] == "swap" for op in state.physical_operations)
        return Attempt(
            case.name,
            case.topology,
            case.num_qubits,
            hardware.num_qubits,
            mapping.name,
            config.name,
            proxy_cost,
            swap,
            state.current_depth(),
            (time.perf_counter() - start) * 1000.0,
            True,
            "",
        )
    except Exception as error:
        return Attempt(
            case.name,
            case.topology,
            case.num_qubits,
            hardware.num_qubits,
            mapping.name,
            config.name,
            proxy_cost,
            None,
            None,
            (time.perf_counter() - start) * 1000.0,
            False,
            f"{type(error).__name__}: {error}",
        )


def quality(row: Attempt) -> tuple[int, int, float, str, str]:
    return (
        int(row.swap) if row.swap is not None else 10**9,
        int(row.depth) if row.depth is not None else 10**9,
        row.runtime_ms,
        row.policy,
        row.mapping,
    )


def save_csv(path: Path, rows: list, fields) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=fields)
        writer.writeheader()
        writer.writerows(asdict(row) for row in rows)


def summarize(rows: list[CaseResult]) -> dict:
    def one_group(group: list[CaseResult]) -> dict:
        ours = sum(row.router_swap for row in group)
        lightsabre = sum(row.lightsabre_swap for row in group)
        outcomes = Counter(row.outcome for row in group)
        return {
            "case_count": len(group),
            "router_swap": ours,
            "lightsabre_swap": lightsabre,
            "swap_gap": ours - lightsabre,
            "relative_gap": (ours - lightsabre) / lightsabre if lightsabre else 0.0,
            "wins": outcomes["OAABR胜"],
            "ties": outcomes["平局"],
            "losses": outcomes["LightSABRE胜"],
            "router_budget_ms": sum(row.router_budget_ms for row in group),
            "lightsabre_budget_ms": sum(row.lightsabre_budget_ms for row in group),
        }

    result = one_group(rows)
    groups: dict[str, list[CaseResult]] = defaultdict(list)
    for row in rows:
        groups[row.topology].append(row)
    result["by_topology"] = {
        key: one_group(group) for key, group in sorted(groups.items())
    }
    return result


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Stage 33：大拓扑紧凑布局路由器 vs LightSABRE"
    )
    parser.add_argument(
        "--input", type=Path, default=Path("data/benchmarks_large_v1/probe.json")
    )
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--case-indices", type=str, default=None)
    parser.add_argument("--anchor-trials", type=int, default=4)
    parser.add_argument("--mapping-trials", type=int, default=2)
    parser.add_argument("--policies", type=str, default=DEFAULT_POLICIES)
    parser.add_argument("--qiskit-seeds", type=int, default=20)
    parser.add_argument("--qiskit-repeats", type=int, default=2)
    parser.add_argument(
        "--attempt-output", type=Path,
        default=Path("results/stage33_large_attempts.csv"),
    )
    parser.add_argument(
        "--case-output", type=Path,
        default=Path("results/stage33_large_cases.csv"),
    )
    parser.add_argument(
        "--summary-output", type=Path,
        default=Path("results/stage33_large_summary.json"),
    )
    args = parser.parse_args()
    if args.anchor_trials <= 0 or args.mapping_trials <= 0:
        raise ValueError("anchor-trials 与 mapping-trials 必须为正数")

    configure_router()
    policies = parse_policies(args.policies)
    cases = stage21.choose_cases(
        load_cases(args.input, limit=None),
        stage21.parse_indices(args.case_indices),
        args.limit,
    )
    metadata_payload = json.loads(args.input.read_text(encoding="utf-8"))
    metadata = {case["name"]: case for case in metadata_payload["cases"]}

    print("===== Stage 33：大拓扑紧凑布局探针 =====")
    print(f"输入：{args.input.resolve()}")
    print(f"实例数：{len(cases)}")
    print(f"策略：{[config.name for config in policies]}")
    print(
        f"布局预算：anchors={args.anchor_trials}, "
        f"完整路由 mappings={args.mapping_trials}"
    )
    print(
        f"LightSABRE：{args.qiskit_seeds} seeds x "
        f"{args.qiskit_repeats} repeats"
    )
    print("本阶段不使用完整 rollout；逻辑/物理比特数已分离。")

    attempts: list[Attempt] = []
    case_rows: list[CaseResult] = []
    for index, case in enumerate(cases, start=1):
        dag, hardware, _ = case.test_case.build()
        print(
            f"[{index}/{len(cases)}] {case.name} "
            f"(L={dag.num_logical_qubits}, P={hardware.num_qubits}) ...",
            flush=True,
        )
        start = time.perf_counter()
        pool, generated_count = compact_mapping_pool(case, args.anchor_trials)
        selected_pool = pool[: args.mapping_trials]
        local_attempts = [
            run_attempt(case, mapping, proxy, config)
            for mapping, proxy in selected_pool
            for config in policies
        ]
        attempts.extend(local_attempts)
        valid = [row for row in local_attempts if row.valid]
        if not valid:
            raise RuntimeError(
                f"{case.name} 所有路由失败："
                + " | ".join(row.error for row in local_attempts)
            )
        best = min(valid, key=quality)
        router_budget = (time.perf_counter() - start) * 1000.0
        qiskit_best, qiskit_budget = run_qiskit_multiseed(
            case, args.qiskit_seeds, args.qiskit_repeats
        )
        if qiskit_best.swap_count is None or qiskit_best.weighted_depth is None:
            raise RuntimeError(f"{case.name}: LightSABRE 无合法结果")
        swap_gap = int(best.swap) - int(qiskit_best.swap_count)
        depth_gap = int(best.depth) - int(qiskit_best.weighted_depth)
        if (int(best.swap), int(best.depth)) < (
            int(qiskit_best.swap_count), int(qiskit_best.weighted_depth)
        ):
            outcome = "OAABR胜"
        elif (int(best.swap), int(best.depth)) == (
            int(qiskit_best.swap_count), int(qiskit_best.weighted_depth)
        ):
            outcome = "平局"
        else:
            outcome = "LightSABRE胜"
        raw_meta = metadata[case.name]
        row = CaseResult(
            instance=case.name,
            topology=case.topology,
            circuit_mode=case.circuit_mode,
            logical_qubits=dag.num_logical_qubits,
            physical_qubits=hardware.num_qubits,
            cx_count=case.two_qubit_gate_count,
            topology_is_exact_hardware=bool(
                raw_meta.get("topology_is_exact_hardware", False)
            ),
            mappings_generated=generated_count,
            mappings_routed=len(selected_pool),
            policies=",".join(config.name for config in policies),
            selected_mapping=best.mapping,
            selected_policy=best.policy,
            router_swap=int(best.swap),
            router_depth=int(best.depth),
            router_budget_ms=router_budget,
            lightsabre_seed=int(qiskit_best.seed),
            lightsabre_swap=int(qiskit_best.swap_count),
            lightsabre_depth=int(qiskit_best.weighted_depth),
            lightsabre_budget_ms=qiskit_budget,
            swap_gap=swap_gap,
            depth_gap=depth_gap,
            outcome=outcome,
        )
        case_rows.append(row)
        print(
            f"  router={row.router_swap}/{row.router_depth} "
            f"({row.selected_mapping}, {row.selected_policy}), "
            f"LightSABRE={row.lightsabre_swap}/{row.lightsabre_depth}, "
            f"gap={row.swap_gap:+d}, {row.outcome}, "
            f"budget={row.router_budget_ms:.1f}/{row.lightsabre_budget_ms:.1f} ms"
        )

        save_csv(args.attempt_output, attempts, Attempt.__annotations__.keys())
        save_csv(args.case_output, case_rows, CaseResult.__annotations__.keys())
        args.summary_output.parent.mkdir(parents=True, exist_ok=True)
        args.summary_output.write_text(
            json.dumps(summarize(case_rows), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    summary = summarize(case_rows)
    print("\n===== Stage 33 汇总 =====")
    print(f"OAABR total SWAP：{summary['router_swap']}")
    print(f"LightSABRE total SWAP：{summary['lightsabre_swap']}")
    print(f"SWAP gap：{summary['swap_gap']:+d}")
    print(f"相对差：{summary['relative_gap']:+.2%}")
    print(
        f"逐实例胜/平/负：{summary['wins']}/"
        f"{summary['ties']}/{summary['losses']}"
    )
    print(
        f"总预算 router/LightSABRE：{summary['router_budget_ms']:.1f}/"
        f"{summary['lightsabre_budget_ms']:.1f} ms"
    )
    print(f"尝试明细：{args.attempt_output.resolve()}")
    print(f"逐实例结果：{args.case_output.resolve()}")
    print(f"汇总 JSON：{args.summary_output.resolve()}")


if __name__ == "__main__":
    main()
