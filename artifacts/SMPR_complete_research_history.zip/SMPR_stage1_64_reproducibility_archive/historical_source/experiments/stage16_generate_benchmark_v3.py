from __future__ import annotations

import argparse
import json
import random
from collections import Counter
from dataclasses import asdict, dataclass
from pathlib import Path

from stage9_generate_benchmark import (
    CIRCUIT_MODES,
    QUBIT_SIZES,
    TOPOLOGIES,
    generate_gate_specs,
    make_topology,
)


LENGTH_FACTORS = (3, 6, 12)

SPLIT_CODE = {
    "dev": 1,
    "validation": 2,
    "test": 3,
}


@dataclass(frozen=True)
class StratifiedProfile:
    profile_id: int
    topology_index: int
    circuit_mode_index: int
    length_factor_index: int
    topology: str
    circuit_mode: str
    length_factor: int
    num_qubits: int
    split: str


@dataclass(frozen=True)
class StratifiedCase:
    name: str
    split: str
    seed: int
    profile_id: int
    num_qubits: int
    topology: str
    circuit_mode: str
    length_factor: int
    two_qubit_gate_count: int
    edges: tuple[tuple[int, int], ...]
    gate_specs: tuple[tuple, ...]
    initial_mapping: tuple[int, ...]


def choose_split(
    topology_index: int,
    circuit_mode_index: int,
    length_factor_index: int,
) -> str:
    """
    令

        r = (topology_index
             + circuit_mode_index
             + length_factor_index) mod 4.

    r=0,1 -> dev
    r=2   -> validation
    r=3   -> test

    由于固定线路模式或固定长度因子时，
    topology_index=0,1,2,3 会遍历全部模 4 余数，
    因而可严格保证：

        每个线路模式：
            dev 6, validation 3, test 3；

        每个长度因子：
            dev 10, validation 5, test 5。
    """

    residue = (
        topology_index
        + circuit_mode_index
        + length_factor_index
    ) % 4

    if residue in (0, 1):
        return "dev"

    if residue == 2:
        return "validation"

    return "test"


def choose_num_qubits(
    circuit_mode_index: int,
    length_factor_index: int,
) -> int:
    """
    用 (mode_index + factor_index) mod 3 分配 6/8/10 比特。

    该规则在三个 split 中分别严格产生：

        dev:        10 / 10 / 10
        validation:  5 /  5 /  5
        test:        5 /  5 /  5

    同时避免把量子比特数直接绑定到长度因子。
    """

    index = (
        circuit_mode_index
        + length_factor_index
    ) % len(QUBIT_SIZES)

    return QUBIT_SIZES[index]


def build_profiles() -> list[StratifiedProfile]:
    profiles: list[StratifiedProfile] = []

    profile_id = 0

    for topology_index, topology in enumerate(
        TOPOLOGIES
    ):
        for circuit_mode_index, circuit_mode in enumerate(
            CIRCUIT_MODES
        ):
            for length_factor_index, length_factor in enumerate(
                LENGTH_FACTORS
            ):
                split = choose_split(
                    topology_index=topology_index,
                    circuit_mode_index=circuit_mode_index,
                    length_factor_index=length_factor_index,
                )

                num_qubits = choose_num_qubits(
                    circuit_mode_index=circuit_mode_index,
                    length_factor_index=length_factor_index,
                )

                profiles.append(
                    StratifiedProfile(
                        profile_id=profile_id,
                        topology_index=topology_index,
                        circuit_mode_index=circuit_mode_index,
                        length_factor_index=length_factor_index,
                        topology=topology,
                        circuit_mode=circuit_mode,
                        length_factor=length_factor,
                        num_qubits=num_qubits,
                        split=split,
                    )
                )

                profile_id += 1

    return profiles


def build_case(
    profile: StratifiedProfile,
    split_index: int,
    master_seed: int,
) -> StratifiedCase:
    case_seed = (
        master_seed
        + 100_000 * SPLIT_CODE[profile.split]
        + 1009 * profile.profile_id
    )

    rng = random.Random(case_seed)

    edges = make_topology(
        topology=profile.topology,
        n=profile.num_qubits,
        rng=rng,
    )

    two_qubit_gate_count = (
        profile.length_factor
        * profile.num_qubits
    )

    gate_specs = generate_gate_specs(
        n=profile.num_qubits,
        num_two_qubit_gates=two_qubit_gate_count,
        circuit_mode=profile.circuit_mode,
        edges=edges,
        rng=rng,
    )

    case = StratifiedCase(
        name=(
            f"{profile.split}_v3_{split_index:03d}_"
            f"{profile.topology}_"
            f"n{profile.num_qubits}_"
            f"{profile.circuit_mode}_"
            f"f{profile.length_factor}_"
            f"cx{two_qubit_gate_count}"
        ),
        split=profile.split,
        seed=case_seed,
        profile_id=profile.profile_id,
        num_qubits=profile.num_qubits,
        topology=profile.topology,
        circuit_mode=profile.circuit_mode,
        length_factor=profile.length_factor,
        two_qubit_gate_count=two_qubit_gate_count,
        edges=edges,
        gate_specs=gate_specs,
        initial_mapping=tuple(
            range(profile.num_qubits)
        ),
    )

    validate_case(case)
    return case


def validate_case(
    case: StratifiedCase,
) -> None:
    if len(case.initial_mapping) != case.num_qubits:
        raise ValueError(
            f"{case.name} 初始映射长度错误"
        )

    if set(case.initial_mapping) != set(
        range(case.num_qubits)
    ):
        raise ValueError(
            f"{case.name} 初始映射不是排列"
        )

    cx_count = sum(
        gate[0] == "cx"
        for gate in case.gate_specs
    )

    if cx_count != case.two_qubit_gate_count:
        raise ValueError(
            f"{case.name} 的 CX 数不一致"
        )

    expected = (
        case.length_factor
        * case.num_qubits
    )

    if cx_count != expected:
        raise ValueError(
            f"{case.name} 未满足 CX=factor*n"
        )


def group_profiles(
    profiles: list[StratifiedProfile],
) -> dict[str, list[StratifiedProfile]]:
    grouped = {
        "dev": [],
        "validation": [],
        "test": [],
    }

    for profile in profiles:
        grouped[profile.split].append(profile)

    for split in grouped:
        grouped[split].sort(
            key=lambda profile: profile.profile_id
        )

    return grouped


def validate_stratification(
    grouped_profiles: dict[
        str,
        list[StratifiedProfile],
    ],
) -> None:
    expected_sizes = {
        "dev": 30,
        "validation": 15,
        "test": 15,
    }

    expected_mode_counts = {
        "dev": 6,
        "validation": 3,
        "test": 3,
    }

    expected_factor_counts = {
        "dev": 10,
        "validation": 5,
        "test": 5,
    }

    expected_qubit_counts = {
        "dev": 10,
        "validation": 5,
        "test": 5,
    }

    all_profile_ids: list[int] = []

    for split, profiles in grouped_profiles.items():
        if len(profiles) != expected_sizes[split]:
            raise RuntimeError(
                f"{split} 数量错误："
                f"{len(profiles)} != "
                f"{expected_sizes[split]}"
            )

        all_profile_ids.extend(
            profile.profile_id
            for profile in profiles
        )

        mode_counts = Counter(
            profile.circuit_mode
            for profile in profiles
        )

        factor_counts = Counter(
            profile.length_factor
            for profile in profiles
        )

        qubit_counts = Counter(
            profile.num_qubits
            for profile in profiles
        )

        topology_counts = Counter(
            profile.topology
            for profile in profiles
        )

        for mode in CIRCUIT_MODES:
            if (
                mode_counts[mode]
                != expected_mode_counts[split]
            ):
                raise RuntimeError(
                    f"{split} 的模式 {mode} "
                    "未达到严格平衡"
                )

        for factor in LENGTH_FACTORS:
            if (
                factor_counts[factor]
                != expected_factor_counts[split]
            ):
                raise RuntimeError(
                    f"{split} 的长度因子 {factor} "
                    "未达到严格平衡"
                )

        for num_qubits in QUBIT_SIZES:
            if (
                qubit_counts[num_qubits]
                != expected_qubit_counts[split]
            ):
                raise RuntimeError(
                    f"{split} 的规模 {num_qubits} "
                    "未达到严格平衡"
                )

        topology_values = [
            topology_counts[topology]
            for topology in TOPOLOGIES
        ]

        if (
            max(topology_values)
            - min(topology_values)
            > 1
        ):
            raise RuntimeError(
                f"{split} 的拓扑分布不平衡："
                f"{dict(topology_counts)}"
            )

    if len(all_profile_ids) != 60:
        raise RuntimeError(
            "总 profile 数不是 60"
        )

    if len(set(all_profile_ids)) != 60:
        raise RuntimeError(
            "三个数据划分之间存在重复 profile"
        )


def case_to_dict(
    case: StratifiedCase,
) -> dict:
    data = asdict(case)

    data["edges"] = [
        list(edge)
        for edge in case.edges
    ]

    data["gate_specs"] = [
        list(gate)
        for gate in case.gate_specs
    ]

    data["initial_mapping"] = list(
        case.initial_mapping
    )

    return data


def save_split(
    cases: list[StratifiedCase],
    path: Path,
    master_seed: int,
) -> None:
    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    payload = {
        "schema_version": 3,
        "master_seed": master_seed,
        "case_count": len(cases),
        "design": {
            "topologies": list(TOPOLOGIES),
            "circuit_modes": list(
                CIRCUIT_MODES
            ),
            "length_factors": list(
                LENGTH_FACTORS
            ),
            "qubit_sizes": list(
                QUBIT_SIZES
            ),
            "split_rule": (
                "(topology_index + "
                "circuit_mode_index + "
                "length_factor_index) mod 4"
            ),
            "qubit_rule": (
                "(circuit_mode_index + "
                "length_factor_index) mod 3"
            ),
            "two_qubit_gate_rule": (
                "two_qubit_gate_count = "
                "length_factor * num_qubits"
            ),
        },
        "cases": [
            case_to_dict(case)
            for case in cases
        ],
    }

    path.write_text(
        json.dumps(
            payload,
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )


def save_manifest(
    profiles: list[StratifiedProfile],
    path: Path,
    master_seed: int,
) -> None:
    payload = {
        "schema_version": 3,
        "master_seed": master_seed,
        "profiles": [
            asdict(profile)
            for profile in profiles
        ],
    }

    path.write_text(
        json.dumps(
            payload,
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )


def print_distribution(
    split: str,
    cases: list[StratifiedCase],
) -> None:
    print()
    print(f"[{split}] 实例数：{len(cases)}")

    for attribute, title in (
        ("topology", "拓扑"),
        ("circuit_mode", "线路模式"),
        ("length_factor", "长度因子"),
        ("num_qubits", "量子比特数"),
        (
            "two_qubit_gate_count",
            "CX 数量",
        ),
    ):
        counts = Counter(
            getattr(case, attribute)
            for case in cases
        )

        print(
            f"  {title}："
            f"{dict(sorted(counts.items(), key=lambda item: str(item[0])))}"
        )


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Stage 16：生成严格分层的 Benchmark V3。"
        )
    )

    parser.add_argument(
        "--master-seed",
        type=int,
        default=20260716,
    )

    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path(
            "data/benchmarks_v3"
        ),
    )

    args = parser.parse_args()

    profiles = build_profiles()
    grouped_profiles = group_profiles(
        profiles
    )

    validate_stratification(
        grouped_profiles
    )

    split_cases: dict[
        str,
        list[StratifiedCase],
    ] = {}

    for split in (
        "dev",
        "validation",
        "test",
    ):
        split_cases[split] = [
            build_case(
                profile=profile,
                split_index=index,
                master_seed=args.master_seed,
            )
            for index, profile in enumerate(
                grouped_profiles[split]
            )
        ]

        save_split(
            cases=split_cases[split],
            path=(
                args.output_dir
                / f"{split}.json"
            ),
            master_seed=args.master_seed,
        )

    args.output_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    save_manifest(
        profiles=profiles,
        path=args.output_dir / "manifest.json",
        master_seed=args.master_seed,
    )

    print("生成完成：")

    for filename in (
        "dev.json",
        "validation.json",
        "test.json",
        "manifest.json",
    ):
        print(
            "  ",
            (
                args.output_dir
                / filename
            ).resolve(),
        )

    print()
    print("=" * 92)
    print("Benchmark V3 严格分层汇总")
    print("=" * 92)

    for split in (
        "dev",
        "validation",
        "test",
    ):
        print_distribution(
            split,
            split_cases[split],
        )

    all_profile_ids = [
        case.profile_id
        for cases in split_cases.values()
        for case in cases
    ]

    print()
    print(
        "不同 profile 数：",
        len(set(all_profile_ids)),
        "/",
        len(all_profile_ids),
    )

    print()
    print("严格平衡检查：通过")
    print(
        "  每个线路模式："
        "dev=6, validation=3, test=3"
    )
    print(
        "  每个长度因子："
        "dev=10, validation=5, test=5"
    )
    print(
        "  每个量子比特规模："
        "dev=10, validation=5, test=5"
    )
    print(
        "  每个拓扑在各 split 内数量差不超过 1"
    )


if __name__ == "__main__":
    main()
