from __future__ import annotations

import argparse
import csv
import json
import math
import statistics
from dataclasses import asdict, dataclass
from pathlib import Path

import stage20_score_structure_ablation as stage20
import stage21_policy_portfolio as stage21
import stage33_large_topology_probe as stage33
import stage37_proxy_local_layout_refinement as stage37
import stage39_layout_router_cross_decomposition as stage39
import stage41_multiwindow_proxy_calibration as stage41

from stage7_initial_mapping_pool import MappingCandidate, build_interaction_matrices
from stage10_dev_benchmark import load_cases


@dataclass
class LabelRow:
    instance: str
    mapping_name: str
    mutation: str
    mapping: str
    is_baseline: bool
    static_all: float
    static_early: float
    static_late: float
    static_blend: float
    stage40_partial_swap: int | None
    stage40_partial_depth: int | None
    stage41_window_swap: int | None
    stage41_window_depth: int | None
    full_swap: int
    full_depth: int
    full_result_source: str
    full_runtime_ms: float


@dataclass
class CaseResult:
    instance: str
    topology: str
    circuit_mode: str
    logical_qubits: int
    physical_qubits: int
    cx_count: int
    policy: str
    candidates: int
    reused_full_results: int
    new_full_routes: int
    new_full_budget_ms: float

    stage37_swap: int
    stage37_depth: int
    selected_mapping: str
    selected_mutation: str
    selected_swap: int
    selected_depth: int
    improvement: int

    pearson_static_all: float | None
    spearman_static_all: float | None
    pearson_static_early: float | None
    spearman_static_early: float | None
    pearson_static_late: float | None
    spearman_static_late: float | None
    pearson_static_blend: float | None
    spearman_static_blend: float | None
    pearson_stage40_partial: float | None
    spearman_stage40_partial: float | None
    pearson_stage41_window: float | None
    spearman_stage41_window: float | None

    lightsabre_swap: int
    lightsabre_depth: int
    swap_gap: int
    depth_gap: int
    outcome: str


def read_csv(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        raise FileNotFoundError(f"找不到文件：{path.resolve()}")
    with path.open("r", encoding="utf-8-sig", newline="") as file:
        return list(csv.DictReader(file))


def save_csv(path: Path, rows: list, fields) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=fields)
        writer.writeheader()
        writer.writerows(asdict(row) for row in rows)


def optional_int(value: str | None) -> int | None:
    if value in (None, ""):
        return None
    return int(value)


def average_ranks(values: list[float]) -> list[float]:
    order = sorted(range(len(values)), key=lambda index: (values[index], index))
    ranks = [0.0] * len(values)
    position = 0
    while position < len(order):
        end = position + 1
        while end < len(order) and values[order[end]] == values[order[position]]:
            end += 1
        rank = 0.5 * ((position + 1) + end)
        for cursor in range(position, end):
            ranks[order[cursor]] = rank
        position = end
    return ranks


def pearson(left: list[float], right: list[float]) -> float | None:
    if len(left) < 2:
        return None
    left_mean = statistics.fmean(left)
    right_mean = statistics.fmean(right)
    numerator = sum(
        (x - left_mean) * (y - right_mean) for x, y in zip(left, right)
    )
    left_norm = math.sqrt(sum((x - left_mean) ** 2 for x in left))
    right_norm = math.sqrt(sum((y - right_mean) ** 2 for y in right))
    if left_norm == 0.0 or right_norm == 0.0:
        return None
    return numerator / (left_norm * right_norm)


def correlations(
    rows: list[LabelRow],
    feature: str,
) -> tuple[float | None, float | None]:
    paired = [row for row in rows if getattr(row, feature) is not None]
    left = [float(getattr(row, feature)) for row in paired]
    right = [float(row.full_swap) for row in paired]
    return (
        pearson(left, right),
        pearson(average_ranks(left), average_ranks(right)),
    )


def outcome_text(ours: tuple[int, int], qiskit: tuple[int, int]) -> str:
    if ours < qiskit:
        return "OAABR胜"
    if ours == qiskit:
        return "平局"
    return "LightSABRE胜"


def summarize(rows: list[CaseResult]) -> dict:
    old = sum(row.stage37_swap for row in rows)
    selected = sum(row.selected_swap for row in rows)
    lightsabre = sum(row.lightsabre_swap for row in rows)
    return {
        "case_count": len(rows),
        "stage37_swap": old,
        "stage42_swap": selected,
        "improvement": old - selected,
        "lightsabre_swap": lightsabre,
        "swap_gap": selected - lightsabre,
        "new_full_routes": sum(row.new_full_routes for row in rows),
        "new_full_budget_ms": sum(row.new_full_budget_ms for row in rows),
        "correlations": {
            row.instance: {
                "static_all": [row.pearson_static_all, row.spearman_static_all],
                "static_early": [
                    row.pearson_static_early, row.spearman_static_early
                ],
                "static_late": [row.pearson_static_late, row.spearman_static_late],
                "static_blend": [
                    row.pearson_static_blend, row.spearman_static_blend
                ],
                "stage40_partial": [
                    row.pearson_stage40_partial,
                    row.spearman_stage40_partial,
                ],
                "stage41_window": [
                    row.pearson_stage41_window,
                    row.spearman_stage41_window,
                ],
            }
            for row in rows
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Stage 42：补齐当前候选池的完整路由标签"
    )
    parser.add_argument(
        "--input", type=Path, default=Path("data/benchmarks_large_v1/probe.json")
    )
    parser.add_argument("--case-indices", type=str, default="7")
    parser.add_argument(
        "--stage36-cases", type=Path,
        default=Path("results/stage38_alternating_stage36_cases.csv"),
    )
    parser.add_argument(
        "--stage36-polish", type=Path,
        default=Path("results/stage38_alternating_polish.csv"),
    )
    parser.add_argument(
        "--stage37-cases", type=Path,
        default=Path("results/stage38_alternating_stage37_cases.csv"),
    )
    parser.add_argument(
        "--stage37-candidates", type=Path,
        default=Path("results/stage38_alternating_candidates.csv"),
    )
    parser.add_argument(
        "--stage40-probes", type=Path,
        default=Path("results/stage40_heron_probes.csv"),
    )
    parser.add_argument(
        "--stage41-calibration", type=Path,
        default=Path("results/stage41_heron_calibration.csv"),
    )
    parser.add_argument("--anchor-trials", type=int, default=4)
    parser.add_argument("--policy", type=str, default="front_sum")
    parser.add_argument("--early-weight", type=float, default=2.0)
    parser.add_argument(
        "--label-output", type=Path,
        default=Path("results/stage42_labels.csv"),
    )
    parser.add_argument(
        "--case-output", type=Path,
        default=Path("results/stage42_cases.csv"),
    )
    parser.add_argument(
        "--summary-output", type=Path,
        default=Path("results/stage42_summary.json"),
    )
    args = parser.parse_args()
    if args.anchor_trials <= 0 or args.early_weight < 0:
        raise ValueError("anchor-trials必须为正，early-weight必须非负")
    if args.policy not in stage20.CONFIG_BY_NAME:
        raise ValueError(f"未知policy：{args.policy}")

    stage33.configure_router()
    config = stage20.CONFIG_BY_NAME[args.policy]
    cases = stage21.choose_cases(
        load_cases(args.input, limit=None),
        stage21.parse_indices(args.case_indices),
        None,
    )
    stage36_rows = {row["instance"]: row for row in read_csv(args.stage36_cases)}
    polish_rows = read_csv(args.stage36_polish)
    stage37_rows = {row["instance"]: row for row in read_csv(args.stage37_cases)}
    stage37_candidates = {
        (row["instance"], row["mapping_name"]): row
        for row in read_csv(args.stage37_candidates)
    }
    stage40_rows = read_csv(args.stage40_probes)
    stage41_rows = read_csv(args.stage41_calibration)

    print("===== Stage 42：完整候选标签补齐 =====")
    print(f"输入：{args.input.resolve()}")
    print(f"实例数：{len(cases)}")
    print(f"完整路由策略：{config.name}")
    print("复用Stage 37基线、Stage 40/41完整结果；只补跑缺失候选。")

    all_labels: list[LabelRow] = []
    case_results: list[CaseResult] = []
    for case_index, case in enumerate(cases, start=1):
        print(f"[{case_index}/{len(cases)}] {case.name} ...", flush=True)
        if case.name not in stage37_rows:
            raise ValueError(f"Stage 37 cases CSV缺少 {case.name}")
        reference = stage37_rows[case.name]
        baseline_mapping = stage39.recover_ours_mapping(
            case=case,
            stage37_row=reference,
            candidate_rows=stage37_candidates,
            stage36_rows=stage36_rows,
            polish_rows=polish_rows,
            anchor_trials=args.anchor_trials,
        )
        old40 = {
            stage37.parse_mapping(row["mapping"]): row
            for row in stage40_rows if row["instance"] == case.name
        }
        old41 = {
            stage37.parse_mapping(row["mapping"]): row
            for row in stage41_rows if row["instance"] == case.name
        }
        if not old41:
            raise ValueError(f"Stage 41 calibration CSV缺少 {case.name}")

        dag, hardware, _ = case.test_case.build()
        distances = stage33.all_pairs_distances(hardware)
        matrices = build_interaction_matrices(dag)
        labels: list[LabelRow] = []
        reused = 0
        new_routes = 0
        new_budget = 0.0
        for mapping, row41 in old41.items():
            is_baseline = mapping == baseline_mapping
            full_swap = optional_int(row41.get("full_swap"))
            full_depth = optional_int(row41.get("full_depth"))
            source = row41.get("full_result_source", "")
            runtime = float(row41.get("full_runtime_ms") or 0.0)
            if full_swap is not None and full_depth is not None:
                reused += 1
            else:
                candidate = MappingCandidate(row41["mapping_name"], mapping, 0.0)
                attempt = stage33.run_attempt(case, candidate, 0.0, config)
                if not attempt.valid:
                    raise RuntimeError(
                        f"{case.name}/{candidate.name}: 完整路由失败：{attempt.error}"
                    )
                full_swap = int(attempt.swap)
                full_depth = int(attempt.depth)
                runtime = attempt.runtime_ms
                source = "stage42_new"
                new_routes += 1
                new_budget += runtime

            all_cost = stage33.matrix_cost(mapping, matrices["all"], distances)
            early_cost = stage33.matrix_cost(mapping, matrices["early"], distances)
            late_cost = stage33.matrix_cost(mapping, matrices["late"], distances)
            row40 = old40.get(mapping)
            labels.append(
                LabelRow(
                    instance=case.name,
                    mapping_name=row41["mapping_name"],
                    mutation=row41["mutation"],
                    mapping=stage37.mapping_text(mapping),
                    is_baseline=is_baseline,
                    static_all=all_cost,
                    static_early=early_cost,
                    static_late=late_cost,
                    static_blend=all_cost + args.early_weight * early_cost,
                    stage40_partial_swap=(
                        optional_int(row40.get("partial_swap")) if row40 else None
                    ),
                    stage40_partial_depth=(
                        optional_int(row40.get("partial_depth")) if row40 else None
                    ),
                    stage41_window_swap=optional_int(row41.get("window_swap_sum")),
                    stage41_window_depth=optional_int(row41.get("window_depth_sum")),
                    full_swap=full_swap,
                    full_depth=full_depth,
                    full_result_source=source,
                    full_runtime_ms=runtime,
                )
            )

        best = min(
            labels,
            key=lambda row: (row.full_swap, row.full_depth, row.mapping_name),
        )
        correlation_values = {
            feature: correlations(labels, feature)
            for feature in (
                "static_all",
                "static_early",
                "static_late",
                "static_blend",
                "stage40_partial_swap",
                "stage41_window_swap",
            )
        }
        lightsabre = (
            int(reference["lightsabre_swap"]),
            int(reference["lightsabre_depth"]),
        )
        ours = (best.full_swap, best.full_depth)
        result = CaseResult(
            instance=case.name,
            topology=case.topology,
            circuit_mode=case.circuit_mode,
            logical_qubits=case.num_qubits,
            physical_qubits=case.test_case.num_physical_qubits,
            cx_count=case.two_qubit_gate_count,
            policy=config.name,
            candidates=len(labels),
            reused_full_results=reused,
            new_full_routes=new_routes,
            new_full_budget_ms=new_budget,
            stage37_swap=int(reference["refined_swap"]),
            stage37_depth=int(reference["refined_depth"]),
            selected_mapping=best.mapping_name,
            selected_mutation=best.mutation,
            selected_swap=best.full_swap,
            selected_depth=best.full_depth,
            improvement=int(reference["refined_swap"]) - best.full_swap,
            pearson_static_all=correlation_values["static_all"][0],
            spearman_static_all=correlation_values["static_all"][1],
            pearson_static_early=correlation_values["static_early"][0],
            spearman_static_early=correlation_values["static_early"][1],
            pearson_static_late=correlation_values["static_late"][0],
            spearman_static_late=correlation_values["static_late"][1],
            pearson_static_blend=correlation_values["static_blend"][0],
            spearman_static_blend=correlation_values["static_blend"][1],
            pearson_stage40_partial=correlation_values["stage40_partial_swap"][0],
            spearman_stage40_partial=correlation_values["stage40_partial_swap"][1],
            pearson_stage41_window=correlation_values["stage41_window_swap"][0],
            spearman_stage41_window=correlation_values["stage41_window_swap"][1],
            lightsabre_swap=lightsabre[0],
            lightsabre_depth=lightsabre[1],
            swap_gap=best.full_swap - lightsabre[0],
            depth_gap=best.full_depth - lightsabre[1],
            outcome=outcome_text(ours, lightsabre),
        )
        all_labels.extend(labels)
        case_results.append(result)
        print(
            f"  labels={len(labels)}, reused/new={reused}/{new_routes}, "
            f"budget={new_budget:.1f} ms"
        )
        for feature, values in correlation_values.items():
            print(
                f"  correlation {feature}: pearson={values[0]}, "
                f"spearman={values[1]}"
            )
        print(
            f"  Stage37={result.stage37_swap}/{result.stage37_depth}, "
            f"best={result.selected_swap}/{result.selected_depth} "
            f"({result.selected_mutation}), DeltaSWAP=-{result.improvement}"
        )
        print(
            f"  LightSABRE={result.lightsabre_swap}/{result.lightsabre_depth}, "
            f"gap={result.swap_gap:+d}, {result.outcome}"
        )

        save_csv(args.label_output, all_labels, LabelRow.__annotations__.keys())
        save_csv(args.case_output, case_results, CaseResult.__annotations__.keys())
        args.summary_output.parent.mkdir(parents=True, exist_ok=True)
        args.summary_output.write_text(
            json.dumps(summarize(case_results), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    summary = summarize(case_results)
    print("\n===== Stage 42 汇总 =====")
    print(f"Stage 37 total SWAP：{summary['stage37_swap']}")
    print(f"Stage 42 total SWAP：{summary['stage42_swap']}")
    print(f"完整标签池减少：{summary['improvement']}")
    print(f"LightSABRE total SWAP：{summary['lightsabre_swap']}")
    print(f"相对 LightSABRE gap：{summary['swap_gap']:+d}")
    print(
        f"新增完整路由：{summary['new_full_routes']}，"
        f"预算={summary['new_full_budget_ms']:.1f} ms"
    )
    print(f"完整标签：{args.label_output.resolve()}")
    print(f"逐实例：{args.case_output.resolve()}")
    print(f"汇总：{args.summary_output.resolve()}")


if __name__ == "__main__":
    main()
