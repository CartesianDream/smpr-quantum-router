from __future__ import annotations

# 导入即安装 RoutingState.__deepcopy__ fast clone。
import stage48_fast_clone_profile  # noqa: F401
import stage32_frozen_final_benchmark as stage32


if __name__ == "__main__":
    stage32.main()