from __future__ import annotations

import argparse
from pathlib import Path

import stage12_scale_probe as stage12
import stage13_score_ablation as stage13

from stage7_initial_mapping_pool import generate_base_mapping_pool


# ============================================================
# 1. 小型联合参数网格
# ============================================================

JOINT_CONFIGS: tuple[stage13.ScoreConfig, ...] = (
    # 三个锚点：便于和 Stage 13 直接比较。
    stage13.ScoreConfig(
        name="baseline",
        beta_unlock=2.0,
        lambda_depth=0.2,
        alpha=0.5,
    ),
    stage13.ScoreConfig(
        name="anchor_d0_b2",
        beta_unlock=2.0,
        lambda_depth=0.0,
        alpha=0.5,
    ),
    stage13.ScoreConfig(
        name="anchor_d005_b2",
        beta_unlock=2.0,
        lambda_depth=0.05,
        alpha=0.5,
    ),

    # 主网格：降低深度权重，同时细化解锁收益。
    stage13.ScoreConfig(
        name="d0_b025",
        beta_unlock=0.25,
        lambda_depth=0.0,
        alpha=0.5,
    ),
    stage13.ScoreConfig(
        name="d0_b05",
        beta_unlock=0.5,
        lambda_depth=0.0,
        alpha=0.5,
    ),
    stage13.ScoreConfig(
        name="d0_b075",
        beta_unlock=0.75,
        lambda_depth=0.0,
        alpha=0.5,
    ),
    stage13.ScoreConfig(
        name="d0_b1",
        beta_unlock=1.0,
        lambda_depth=0.0,
        alpha=0.5,
    ),
    stage13.ScoreConfig(
        name="d005_b025",
        beta_unlock=0.25,
        lambda_depth=0.05,
        alpha=0.5,
    ),
    stage13.ScoreConfig(
        name="d005_b05",
        beta_unlock=0.5,
        lambda_depth=0.05,
        alpha=0.5,
    ),
    stage13.ScoreConfig(
        name="d005_b075",
        beta_unlock=0.75,
        lambda_depth=0.05,
        alpha=0.5,
    ),
    stage13.ScoreConfig(
        name="d005_b1",
        beta_unlock=1.0,
        lambda_depth=0.05,
        alpha=0.5,
    ),

    # Stage 13 中 alpha=0 略优于 baseline。
    # 只在最有希望的 beta 区间与两种深度权重组合。
    stage13.ScoreConfig(
        name="d0_b05_a0",
        beta_unlock=0.5,
        lambda_depth=0.0,
        alpha=0.0,
    ),
    stage13.ScoreConfig(
        name="d0_b075_a0",
        beta_unlock=0.75,
        lambda_depth=0.0,
        alpha=0.0,
    ),
    stage13.ScoreConfig(
        name="d005_b05_a0",
        beta_unlock=0.5,
        lambda_depth=0.05,
        alpha=0.0,
    ),
    stage13.ScoreConfig(
        name="d005_b075_a0",
        beta_unlock=0.75,
        lambda_depth=0.05,
        alpha=0.0,
    ),
)


# ============================================================
# 2. 主程序
# ============================================================

def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Stage 14：围绕 Stage 13 的两个有效方向，"
            "联合搜索 lambda_depth、beta_unlock 和少量 alpha。"
        )
    )

    parser.add_argument(
        "--factors",
        type=str,
        default="6,12",
        help="默认使用 6n 和 12n 个 CX",
    )

    parser.add_argument(
        "--limit-families",
        type=int,
        default=None,
        help="只运行前若干个线路族，用于快速测试",
    )

    parser.add_argument(
        "--qiskit-csv",
        type=Path,
        default=Path(
            "results/stage12_scale_probe.csv"
        ),
    )

    parser.add_argument(
        "--case-output",
        type=Path,
        default=Path(
            "results/stage14_joint_grid_raw.csv"
        ),
    )

    parser.add_argument(
        "--summary-output",
        type=Path,
        default=Path(
            "results/stage14_joint_grid_summary.csv"
        ),
    )

    args = parser.parse_args()

    factors = stage12.parse_factors(
        args.factors
    )

    selected_families = stage12.FAMILIES

    if args.limit_families is not None:
        if args.limit_families <= 0:
            raise ValueError(
                "--limit-families 必须为正整数"
            )

        selected_families = stage12.FAMILIES[
            :args.limit_families
        ]

    original_stage12_families = (
        stage12.FAMILIES
    )

    original_stage13_configs = (
        stage13.CONFIGS
    )

    baseline_config = JOINT_CONFIGS[0]

    try:
        # Stage 12 的生成器从模块全局 FAMILIES 读取线路族。
        stage12.FAMILIES = selected_families

        scale_cases = (
            stage12.build_scale_cases(
                factors
            )
        )

        # Stage 13 的汇总函数从模块全局 CONFIGS 查参数。
        stage13.CONFIGS = JOINT_CONFIGS

        qiskit_baseline = (
            stage13.load_qiskit_baseline(
                args.qiskit_csv
            )
        )

        # 初始映射池与评分参数无关，只生成一次。
        mapping_pools = {
            case.name: (
                generate_base_mapping_pool(
                    case
                )
            )
            for _, _, case in scale_cases
        }

        case_rows: list[
            stage13.CaseResult
        ] = []

        print(
            "===== Stage 14：联合参数搜索 ====="
        )
        print(
            "线路族数：",
            len(selected_families),
        )
        print("长度因子：", factors)
        print("配置数：", len(JOINT_CONFIGS))
        print(
            "总配置—实例组合：",
            (
                len(JOINT_CONFIGS)
                * len(scale_cases)
            ),
        )

        for config_index, config in enumerate(
            JOINT_CONFIGS,
            start=1,
        ):
            stage13.apply_config(config)

            print()
            print(
                f"[配置 {config_index}/"
                f"{len(JOINT_CONFIGS)}] "
                f"{config.name}"
            )

            for case_index, (
                family,
                factor,
                case,
            ) in enumerate(
                scale_cases,
                start=1,
            ):
                baseline_key = (
                    family.name,
                    factor,
                )

                if (
                    baseline_key
                    not in qiskit_baseline
                ):
                    raise KeyError(
                        "Stage 12 CSV 缺少 "
                        f"Qiskit 基线："
                        f"{baseline_key}"
                    )

                (
                    qiskit_swap,
                    qiskit_depth,
                ) = qiskit_baseline[
                    baseline_key
                ]

                (
                    best_mapping,
                    swap_count,
                    weighted_depth,
                    runtime_ms,
                ) = stage13.run_pool(
                    case=case,
                    candidates=(
                        mapping_pools[
                            case.name
                        ]
                    ),
                )

                outcome = stage13.compare(
                    swap_count=swap_count,
                    depth=weighted_depth,
                    qiskit_swap=(
                        qiskit_swap
                    ),
                    qiskit_depth=(
                        qiskit_depth
                    ),
                )

                case_rows.append(
                    stage13.CaseResult(
                        config=config.name,
                        family=family.name,
                        factor=factor,
                        cx_count=(
                            factor
                            * family.num_qubits
                        ),
                        topology=(
                            family.topology
                        ),
                        circuit_mode=(
                            family.circuit_mode
                        ),
                        best_mapping=(
                            best_mapping
                        ),
                        swap_count=(
                            swap_count
                        ),
                        added_two_qubit_count=(
                            3 * swap_count
                        ),
                        weighted_depth=(
                            weighted_depth
                        ),
                        runtime_ms=(
                            runtime_ms
                        ),
                        qiskit_swap=(
                            qiskit_swap
                        ),
                        qiskit_depth=(
                            qiskit_depth
                        ),
                        outcome=outcome,
                    )
                )

                print(
                    f"  [{case_index}/"
                    f"{len(scale_cases)}] "
                    f"{family.name}, "
                    f"f={factor}: "
                    f"SWAP={swap_count}, "
                    f"depth={weighted_depth}, "
                    f"{outcome}"
                )

            summaries = (
                stage13.build_summaries(
                    case_rows
                )
            )

            stage13.save_case_results(
                args.case_output,
                case_rows,
            )

            stage13.save_summaries(
                args.summary_output,
                summaries,
            )

        summaries = (
            stage13.build_summaries(
                case_rows
            )
        )

        stage13.print_summaries(
            summaries
        )

        print()
        print(
            "原始结果：",
            args.case_output.resolve(),
        )
        print(
            "汇总结果：",
            args.summary_output.resolve(),
        )

    finally:
        stage12.FAMILIES = (
            original_stage12_families
        )

        stage13.CONFIGS = (
            original_stage13_configs
        )

        stage13.apply_config(
            baseline_config
        )


if __name__ == "__main__":
    main()
