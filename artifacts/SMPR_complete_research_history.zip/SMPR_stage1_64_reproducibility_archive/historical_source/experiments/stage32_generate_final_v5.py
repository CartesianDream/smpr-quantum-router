from __future__ import annotations

import argparse
import json
from collections import Counter
from dataclasses import asdict, replace
from pathlib import Path

import stage16_generate_benchmark_v3 as stage16
import stage27_generate_benchmark_v4 as stage27


SCHEMA_VERSION = 5
DEFAULT_MASTER_SEED = 20260831
DEFAULT_QUBIT_OFFSET = 0


def build_final_cases(
    master_seed: int,
    qubit_offset: int,
) -> tuple[list[stage16.StratifiedProfile], list[stage16.StratifiedCase]]:
    # split_offset 对最终全集没有影响；这里用 0 生成全部 60 个组合，再把
    # 每个 profile 固定为 test。所有参数在生成数据之前已经冻结。
    source_profiles = stage27.build_profiles(
        split_offset=0,
        qubit_offset=qubit_offset,
    )
    profiles = [replace(profile, split="test") for profile in source_profiles]
    cases: list[stage16.StratifiedCase] = []
    for index, profile in enumerate(profiles):
        case = stage16.build_case(profile, index, master_seed)
        cases.append(
            replace(
                case,
                name=case.name.replace("_v3_", "_v5_", 1),
            )
        )
    return profiles, cases


def validate_final_design(
    profiles: list[stage16.StratifiedProfile],
    cases: list[stage16.StratifiedCase],
) -> None:
    if len(profiles) != 60 or len(cases) != 60:
        raise ValueError("V5 最终全集必须包含 60 个实例")
    if len({case.profile_id for case in cases}) != 60:
        raise ValueError("V5 profile_id 不唯一")
    expected = {
        "topology": 15,
        "circuit_mode": 12,
        "length_factor": 20,
        "num_qubits": 20,
    }
    for field, count in expected.items():
        values = Counter(getattr(case, field) for case in cases)
        if set(values.values()) != {count}:
            raise ValueError(
                f"V5 的 {field} 不平衡：{dict(sorted(values.items(), key=str))}"
            )
    for case in cases:
        stage16.validate_case(case)


def save_dataset(
    path: Path,
    profiles: list[stage16.StratifiedProfile],
    cases: list[stage16.StratifiedCase],
    master_seed: int,
    qubit_offset: int,
) -> None:
    payload = {
        "schema_version": SCHEMA_VERSION,
        "master_seed": master_seed,
        "case_count": len(cases),
        "design": {
            "purpose": "frozen final holdout after Stage 31",
            "topologies": list(stage16.TOPOLOGIES),
            "circuit_modes": list(stage16.CIRCUIT_MODES),
            "length_factors": list(stage16.LENGTH_FACTORS),
            "qubit_sizes": list(stage16.QUBIT_SIZES),
            "qubit_offset": qubit_offset,
            "profile_count": 60,
            "profile_rule": "all topology x mode x length-factor combinations",
            "qubit_rule": "(mode_index + factor_index + qubit_offset) mod 3",
            "two_qubit_gate_rule": "CX = length_factor * num_qubits",
            "frozen_router_rules": [
                "ring && n==10 && far -> Stage27/k2",
                "grid && n>=8 && uniform -> Stage30/proxy8/k2",
                "grid && n==10 && alternating -> Stage31/proxy8/k4",
                "otherwise -> Stage26",
            ],
        },
        "profiles": [asdict(profile) for profile in profiles],
        "cases": [stage16.case_to_dict(case) for case in cases],
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def print_counts(cases: list[stage16.StratifiedCase]) -> None:
    for field in (
        "topology",
        "circuit_mode",
        "length_factor",
        "num_qubits",
    ):
        counts = Counter(getattr(case, field) for case in cases)
        print(f"{field}: {dict(sorted(counts.items(), key=str))}")


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Stage 32：生成冻结模型使用的 60 实例 V5 最终留出集"
    )
    parser.add_argument("--master-seed", type=int, default=DEFAULT_MASTER_SEED)
    parser.add_argument("--qubit-offset", type=int, default=DEFAULT_QUBIT_OFFSET)
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("data/benchmarks_v5/final_test.json"),
    )
    args = parser.parse_args()

    profiles, cases = build_final_cases(
        master_seed=args.master_seed,
        qubit_offset=args.qubit_offset,
    )
    validate_final_design(profiles, cases)
    save_dataset(
        path=args.output,
        profiles=profiles,
        cases=cases,
        master_seed=args.master_seed,
        qubit_offset=args.qubit_offset,
    )

    print("===== Benchmark V5 最终留出集生成完成 =====")
    print(f"输出：{args.output.resolve()}")
    print(f"master seed：{args.master_seed}")
    print(f"qubit offset：{args.qubit_offset}")
    print(f"实例数：{len(cases)}")
    print_counts(cases)
    print("触发专门规则的实例：")
    for index, case in enumerate(cases):
        special = (
            case.topology == "ring"
            and case.num_qubits == 10
            and case.circuit_mode == "far"
        ) or (
            case.topology == "grid"
            and case.num_qubits >= 8
            and case.circuit_mode == "uniform"
        ) or (
            case.topology == "grid"
            and case.num_qubits == 10
            and case.circuit_mode == "alternating"
        )
        if special:
            print(f"  index={index}: {case.name}")


if __name__ == "__main__":
    main()
