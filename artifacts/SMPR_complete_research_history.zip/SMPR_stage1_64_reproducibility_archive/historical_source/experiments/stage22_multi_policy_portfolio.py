"""
Stage 22：三策略路由 Portfolio。

实际实现位于 stage21_policy_portfolio.py，并已扩展为默认运行：
    v1, simpletes_ordered, front_sum

保留独立入口文件，避免 Stage 21 双策略实验与 Stage 22 三策略实验
在命令行和结果文件命名上发生混淆。
"""

from stage21_policy_portfolio import main


if __name__ == "__main__":
    main()
