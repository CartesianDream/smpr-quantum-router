from __future__ import annotations

import ast
import os
import shlex
import subprocess
import sys
from pathlib import Path


FROZEN_STAGE_SCRIPTS = {
    "route": "stage53_cross_layout_safe_hybrid.py",
    "parallel": "stage58_persistent_sharding.py",
    "analyze-v6": "stage56_analyze_blind_v6.py",
    "audit-cases": "stage61_reliability_audit.py",
    "verify-evidence": "stage64_finalize_verified_release.py",
}


def find_repo_root(start: Path | None = None) -> Path:
    candidates: list[Path] = []
    if start is not None:
        candidates.extend([start.resolve(), *start.resolve().parents])
    package_path = Path(__file__).resolve()
    candidates.extend(package_path.parents)
    candidates.extend([Path.cwd().resolve(), *Path.cwd().resolve().parents])
    seen: set[Path] = set()
    for candidate in candidates:
        if candidate in seen:
            continue
        seen.add(candidate)
        if (
            (candidate / "experiments" / "stage53_cross_layout_safe_hybrid.py").is_file()
            and (candidate / "data").is_dir()
        ):
            return candidate
    raise FileNotFoundError(
        "cannot locate repository root containing experiments/ and data/"
    )


def stage_script(repo_root: Path, role: str) -> Path:
    try:
        name = FROZEN_STAGE_SCRIPTS[role]
    except KeyError as error:
        raise ValueError(f"unknown frozen stage role: {role}") from error
    path = repo_root / "experiments" / name
    if not path.is_file():
        raise FileNotFoundError(path)
    return path


def deterministic_environment() -> dict[str, str]:
    environment = os.environ.copy()
    environment["PYTHONHASHSEED"] = "0"
    environment.setdefault("PYTHONIOENCODING", "utf-8")
    environment.setdefault("PYTHONUTF8", "1")
    for variable in (
        "OMP_NUM_THREADS",
        "OPENBLAS_NUM_THREADS",
        "MKL_NUM_THREADS",
        "NUMEXPR_NUM_THREADS",
        "VECLIB_MAXIMUM_THREADS",
        "RAYON_NUM_THREADS",
    ):
        environment[variable] = "1"
    return environment


def format_command(command: list[str]) -> str:
    if os.name == "nt":
        return subprocess.list2cmdline(command)
    return shlex.join(command)


def run_command(
    command: list[str],
    *,
    repo_root: Path,
    dry_run: bool = False,
) -> int:
    print(format_command(command))
    if dry_run:
        return 0
    completed = subprocess.run(
        command,
        cwd=repo_root,
        env=deterministic_environment(),
        check=False,
    )
    return completed.returncode


def missing_stage_imports(repo_root: Path) -> list[str]:
    experiments = repo_root / "experiments"
    missing: set[str] = set()
    for path in experiments.glob("stage*.py"):
        tree = ast.parse(path.read_text(encoding="utf-8"))
        modules: list[str] = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                modules.extend(alias.name for alias in node.names)
            elif isinstance(node, ast.ImportFrom) and node.module:
                modules.append(node.module)
        for module in modules:
            if module.startswith("stage") and not (
                experiments / f"{module}.py"
            ).is_file():
                missing.add(module)
    return sorted(missing)


def python_command(script: Path, *arguments: str) -> list[str]:
    return [sys.executable, "-u", str(script), *arguments]
