from __future__ import annotations

import argparse
import json
import re
import sys
from importlib import metadata
from pathlib import Path
from typing import Any

from .config import FrozenConfig, load_config
from .legacy import (
    find_repo_root,
    missing_stage_imports,
    python_command,
    run_command,
    stage_script,
)


EXPECTED_QISKIT_VERSION = "2.4.2"
EXPECTED_QASM3_IMPORT_VERSION = "0.6.0"
FROZEN_PORTFOLIO = (20, 1, 0, 4, 0.95)


def _repo_root(value: str | None) -> Path:
    return find_repo_root(Path(value) if value else None)


def _resolve_path(value: str, repo_root: Path) -> Path:
    path = Path(value)
    if not path.is_absolute():
        path = repo_root / path
    return path.resolve()


def _load_frozen_config(path: str, repo_root: Path) -> FrozenConfig:
    config = load_config(_resolve_path(path, repo_root), repo_root)
    if config.schema_version != 1:
        raise ValueError(f"unsupported configuration schema: {config.schema_version}")
    config.validate_input()
    return config


def _append_optional(command: list[str], flag: str, value: Any) -> None:
    if value is not None:
        command.extend([flag, str(value)])


def _validate_persistent_frozen_values(config: FrozenConfig) -> None:
    actual = (
        config.portfolio.qiskit_seeds,
        config.portfolio.qiskit_repeats,
        config.portfolio.hybrid_layouts,
        config.portfolio.hybrid_neighbors,
        config.portfolio.proxy_decay,
    )
    if actual != FROZEN_PORTFOLIO:
        raise ValueError(
            "Stage 58 hard-codes the frozen portfolio values "
            f"{FROZEN_PORTFOLIO}; config contains {actual}"
        )


def build_route_command(
    *,
    repo_root: Path,
    config: FrozenConfig,
    executor: str,
    output_dir: Path,
    case_indices: str | None = None,
    limit: int | None = None,
    workers: int | None = None,
    schedule: str | None = None,
    timing_reference: Path | None = None,
    quality_reference: Path | None = None,
    quality_policy: str = "exact",
    resume: bool = False,
) -> list[str]:
    if executor == "sequential":
        command = python_command(
            stage_script(repo_root, "route"),
            "--input",
            str(config.input_path),
            "--qiskit-seeds",
            str(config.portfolio.qiskit_seeds),
            "--qiskit-repeats",
            str(config.portfolio.qiskit_repeats),
            "--hybrid-layouts",
            str(config.portfolio.hybrid_layouts),
            "--hybrid-neighbors",
            str(config.portfolio.hybrid_neighbors),
            "--proxy-decay",
            str(config.portfolio.proxy_decay),
            "--selection-mode",
            config.portfolio.selection_mode,
            "--output-dir",
            str(output_dir),
        )
        _append_optional(command, "--case-indices", case_indices)
        _append_optional(command, "--limit", limit)
        if resume:
            raise ValueError("sequential Stage 53 does not support --resume")
        return command

    if executor != "persistent":
        raise ValueError(f"unknown executor: {executor}")
    _validate_persistent_frozen_values(config)
    command = python_command(
        stage_script(repo_root, "parallel"),
        "--input",
        str(config.input_path),
        "--workers",
        str(workers or config.execution.workers),
        "--schedule",
        schedule or config.execution.schedule,
        "--stage53-script",
        str(stage_script(repo_root, "route")),
        "--selection-mode",
        config.portfolio.selection_mode,
        "--quality-policy",
        quality_policy,
        "--output-dir",
        str(output_dir),
    )
    _append_optional(command, "--case-indices", case_indices)
    _append_optional(command, "--limit", limit)
    _append_optional(command, "--timing-reference", timing_reference)
    _append_optional(command, "--quality-reference", quality_reference)
    if resume:
        command.append("--resume")
    return command


def command_doctor(args: argparse.Namespace) -> int:
    root = _repo_root(args.repo_root)
    checks: list[dict[str, Any]] = []

    def add(name: str, status: str, detail: str) -> None:
        checks.append({"name": name, "status": status, "detail": detail})

    missing = missing_stage_imports(root)
    add(
        "stage imports",
        "pass" if not missing else "fail",
        "all upstream stage modules are present"
        if not missing
        else f"missing: {', '.join(missing)}",
    )

    for config_name in ("frozen_v5.toml", "frozen_v6.toml"):
        try:
            config = load_config(root / "configs" / config_name, root)
            config.validate_input()
        except Exception as error:
            add(config_name, "fail", str(error))
        else:
            add(config_name, "pass", f"{config.dataset} input hash verified")

    try:
        qiskit_version = metadata.version("qiskit")
    except metadata.PackageNotFoundError:
        add(
            "qiskit",
            "warn" if args.allow_missing_qiskit else "fail",
            f"not installed; frozen version is {EXPECTED_QISKIT_VERSION}",
        )
    else:
        add(
            "qiskit",
            "pass" if qiskit_version == EXPECTED_QISKIT_VERSION else "fail",
            f"installed={qiskit_version}, expected={EXPECTED_QISKIT_VERSION}",
        )

    try:
        qasm3_import_version = metadata.version("qiskit-qasm3-import")
    except metadata.PackageNotFoundError:
        add(
            "qiskit-qasm3-import",
            "warn" if args.allow_missing_qiskit else "fail",
            f"not installed; frozen version is {EXPECTED_QASM3_IMPORT_VERSION}",
        )
    else:
        add(
            "qiskit-qasm3-import",
            (
                "pass"
                if qasm3_import_version == EXPECTED_QASM3_IMPORT_VERSION
                else "fail"
            ),
            (
                f"installed={qasm3_import_version}, "
                f"expected={EXPECTED_QASM3_IMPORT_VERSION}"
            ),
        )

    secret_names = ("gjq-api-key.txt", "kaiwu-sdk-license.txt")
    present_secrets = [name for name in secret_names if (root / name).exists()]
    add(
        "credential files",
        "pass" if not present_secrets else "fail",
        "no local credential files detected"
        if not present_secrets
        else f"remove from repository: {', '.join(present_secrets)}",
    )

    verified_summary = root / "evidence" / "stage64_public" / "summary.json"
    try:
        evidence = json.loads(verified_summary.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError, UnicodeError) as error:
        add("Stage 64 evidence", "fail", str(error))
    else:
        add(
            "Stage 64 evidence",
            "pass" if evidence.get("passed") is True else "fail",
            "18 uploaded hashes, V5/V6 reproduction, and joint audit verified"
            if evidence.get("passed") is True
            else "verified evidence summary is not passed",
        )

    if args.json:
        print(json.dumps({"repo_root": str(root), "checks": checks}, indent=2))
    else:
        print(f"repository: {root}")
        for check in checks:
            print(
                f"[{check['status'].upper():4}] "
                f"{check['name']}: {check['detail']}"
            )
    return int(any(check["status"] == "fail" for check in checks))


def command_run(args: argparse.Namespace) -> int:
    root = _repo_root(args.repo_root)
    config = _load_frozen_config(args.config, root)
    output_dir = Path(args.output_dir)
    if not output_dir.is_absolute():
        output_dir = root / output_dir
    command = build_route_command(
        repo_root=root,
        config=config,
        executor=args.executor,
        output_dir=output_dir.resolve(),
        case_indices=args.case_indices,
        limit=args.limit,
        workers=args.workers,
        schedule=args.schedule,
        timing_reference=(
            _resolve_path(args.timing_reference, root)
            if args.timing_reference
            else None
        ),
        quality_reference=(
            _resolve_path(args.quality_reference, root)
            if args.quality_reference
            else None
        ),
        quality_policy=args.quality_policy,
        resume=args.resume,
    )
    return run_command(command, repo_root=root, dry_run=args.dry_run)


def command_audit(args: argparse.Namespace) -> int:
    root = _repo_root(args.repo_root)
    output_dir = Path(args.output_dir)
    if not output_dir.is_absolute():
        output_dir = root / output_dir
    command = python_command(
        stage_script(root, "audit-cases"),
        "--v5-cases",
        str(_resolve_path(args.v5_cases, root)),
        "--v6-cases",
        str(_resolve_path(args.v6_cases, root)),
        "--output-dir",
        str(output_dir.resolve()),
        "--bootstrap-samples",
        str(args.bootstrap_samples),
        "--bootstrap-seed",
        str(args.bootstrap_seed),
    )
    return run_command(command, repo_root=root, dry_run=args.dry_run)


def command_verify_evidence(args: argparse.Namespace) -> int:
    root = _repo_root(args.repo_root)
    output_dir = Path(args.output_dir)
    if not output_dir.is_absolute():
        output_dir = root / output_dir
    command = python_command(
        stage_script(root, "verify-evidence"),
        "--evidence-root",
        str(_resolve_path(args.evidence_root, root)),
        "--output-dir",
        str(output_dir.resolve()),
    )
    return run_command(command, repo_root=root, dry_run=args.dry_run)


def command_stage(args: argparse.Namespace) -> int:
    root = _repo_root(args.repo_root)
    if not re.fullmatch(r"stage[0-9][A-Za-z0-9_]*\.py", args.script):
        raise ValueError("stage script must be a basename such as stage56_analyze_blind_v6.py")
    script = root / "experiments" / args.script
    if not script.is_file():
        raise FileNotFoundError(script)
    command = python_command(script, *args.arguments)
    return run_command(command, repo_root=root, dry_run=args.dry_run)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="quantum-router",
        description="Reproducible Safe Multi-Layout Portfolio Router",
    )
    parser.add_argument(
        "--repo-root",
        help="repository root; normally detected automatically",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    doctor = subparsers.add_parser("doctor", help="verify source, data, and environment")
    doctor.add_argument("--allow-missing-qiskit", action="store_true")
    doctor.add_argument("--json", action="store_true")
    doctor.set_defaults(handler=command_doctor)

    run = subparsers.add_parser("run", help="run the frozen Stage 53/58 portfolio")
    run.add_argument("--config", required=True)
    run.add_argument(
        "--executor",
        choices=("sequential", "persistent"),
        default="persistent",
    )
    run.add_argument("--output-dir", required=True)
    run.add_argument("--case-indices")
    run.add_argument("--limit", type=int)
    run.add_argument("--workers", type=int)
    run.add_argument(
        "--schedule",
        choices=("lpt", "round-robin", "contiguous"),
    )
    run.add_argument("--timing-reference")
    run.add_argument("--quality-reference")
    run.add_argument(
        "--quality-policy",
        choices=("exact", "primary"),
        default="exact",
    )
    run.add_argument("--resume", action="store_true")
    run.add_argument("--dry-run", action="store_true")
    run.set_defaults(handler=command_run)

    audit = subparsers.add_parser("audit", help="run the Stage 61 case-level audit")
    audit.add_argument("--v5-cases", required=True)
    audit.add_argument("--v6-cases", required=True)
    audit.add_argument("--output-dir", required=True)
    audit.add_argument("--bootstrap-samples", type=int, default=10_000)
    audit.add_argument("--bootstrap-seed", type=int, default=20_260_723)
    audit.add_argument("--dry-run", action="store_true")
    audit.set_defaults(handler=command_audit)

    verify_evidence = subparsers.add_parser(
        "verify-evidence",
        help="verify the independent Stage 64 evidence bundle",
    )
    verify_evidence.add_argument(
        "--evidence-root",
        default="evidence/verified_20260725",
    )
    verify_evidence.add_argument("--output-dir", required=True)
    verify_evidence.add_argument("--dry-run", action="store_true")
    verify_evidence.set_defaults(handler=command_verify_evidence)

    stage = subparsers.add_parser("stage", help="run a named legacy stage script")
    stage.add_argument("script")
    stage.add_argument("--dry-run", action="store_true")
    stage.add_argument("arguments", nargs=argparse.REMAINDER)
    stage.set_defaults(handler=command_stage)
    return parser


def main(argv: list[str] | None = None) -> None:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        returncode = int(args.handler(args))
    except (FileNotFoundError, RuntimeError, TypeError, ValueError) as error:
        parser.error(str(error))
    raise SystemExit(returncode)


if __name__ == "__main__":
    main()
