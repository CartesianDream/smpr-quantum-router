from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import tempfile
import zipfile
from pathlib import Path


RELEASE_ROOT = "SMPR_quantum_router_stage64"
FIXED_ZIP_TIME = (2026, 7, 25, 0, 0, 0)
ORIGINAL_SOURCE_SHA256 = (
    "546bebc362ec82bf6548405a9273b9b6503ea26c3d6dc69f0a291978f33e8ae0"
)
EXCLUDED_DIRECTORIES = {
    ".git",
    ".idea",
    ".mypy_cache",
    ".pytest_cache",
    "__pycache__",
    "build",
    "dist",
    "results",
}
EXCLUDED_FILENAMES = {
    ".env",
    "release_manifest.json",
    "gjq-api-key.txt",
    "kaiwu-sdk-license.txt",
}
EXCLUDED_RELATIVE_FILES = {
    "scripts/example.py",
    "scripts/example2.py",
    "scripts/expamle1.py",
    "src/0",
    "data/0",
    "tests/0",
}
EXCLUDED_SUFFIXES = {
    ".key",
    ".p12",
    ".pem",
    ".pfx",
    ".pyc",
    ".pyo",
    ".zip",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def excluded(relative: Path) -> bool:
    posix = relative.as_posix()
    return (
        relative.name.lower() in EXCLUDED_FILENAMES
        or posix in EXCLUDED_RELATIVE_FILES
        or any(part in EXCLUDED_DIRECTORIES for part in relative.parts)
        or any(part.startswith(".venv") for part in relative.parts)
        or any(part.endswith(".egg-info") for part in relative.parts)
        or relative.suffix.lower() in EXCLUDED_SUFFIXES
    )


def copy_source(source: Path, destination: Path) -> None:
    for path in sorted(source.rglob("*")):
        relative = path.relative_to(source)
        if excluded(relative) or not path.is_file():
            continue
        target = destination / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, target)


def build_manifest(root: Path) -> dict[str, object]:
    return {
        "schema_version": 1,
        "stage": 64,
        "version": "0.4.0",
        "release_date": "2026-07-25",
        "release_root": RELEASE_ROOT,
        "purpose": (
            "installable, independently reproduced, and evidence-audited "
            "Safe Multi-Layout Portfolio Router final research release"
        ),
        "provenance": {
            "uploaded_source_archive_sha256": ORIGINAL_SOURCE_SHA256,
            "verified_evidence_archive_sha256": (
                "6c7f38aecea6318b3a8407a73d8f5ae67223ea8853e8f2bc3839261c9af3a85d"
            ),
            "parent_release": "0.3.1",
        },
        "frozen_inputs": {
            "V5": {
                "path": "data/benchmarks_v5/final_test.json",
                "sha256": (
                    "bd8008ad187e433d536a0300d8780c2bf8d210c5661b566aef19fda0c9f4fd79"
                ),
            },
            "V6": {
                "path": "data/benchmarks_v6/blind_test.json",
                "sha256": (
                    "49d7f9a63faea0ed3dbbf27d749744822123fc006fc9b0a5b95ae57ead71367b"
                ),
            },
        },
        "reference_evidence": {
            "v5_cases_sha256": (
                "0c4e73a0d87d204b6eeaf7bf302f9ce91dfb06622c6b5eeb323498b9e1643e09"
            ),
            "v6_cases_sha256": (
                "9e3711648f2e51808e7d6793ae415ad10a4cd11435767ddc4a36dd3fa774049c"
            ),
            "stage61_passed": True,
        },
        "verified_reproduction": {
            "v5_cases_sha256": (
                "a4716ef6445d46c5f108effc5dba12fec5e1d27ab3b23e0b62a686774c8ae79a"
            ),
            "v6_cases_sha256": (
                "a1466e8c6882747d8c7a5ee43f376ba803f1fff58acaff5e16a0a6608e21827f"
            ),
            "joint_audit_summary_sha256": (
                "04e4a31998416b7ac2f9b2ec88ea093e729660cf690ed6c8800499e93d0dac2f"
            ),
            "stage64_public_summary_sha256": sha256(
                root / "evidence" / "stage64_public" / "summary.json"
            ),
            "passed": True,
        },
        "frozen_runtime": {
            "python": "3.10, 3.11, or 3.12",
            "qiskit": "2.4.2",
            "qiskit_qasm3_import": "0.6.0",
            "selection_mode": "legacy",
        },
        "validation_scope": {
            "unit_tests": "21/21 passed in the packaging environment",
            "stage61_recalculation": "passed",
            "stage64_uploaded_hashes": "18/18 passed",
            "stage64_independent_v5_v6_reproduction": "passed",
            "editable_install_without_dependencies": "passed",
            "full_qiskit_route": "60-case V5 and 120-case V6 passed locally",
        },
        "intentional_exclusions": [
            "credential and license files",
            "IDE metadata and Python caches",
            "results, build outputs, and egg-info",
            "nested historical ZIP archives",
            "three unrelated cloud examples that read a local API-key file",
            "three accidental empty files named 0",
        ],
        "file_count_before_checksums": sum(
            path.is_file() for path in root.rglob("*")
        ),
    }


def write_sums(root: Path) -> None:
    paths = sorted(
        path
        for path in root.rglob("*")
        if path.is_file() and path.name != "SHA256SUMS.txt"
    )
    lines = [
        f"{sha256(path)}  {path.relative_to(root).as_posix()}"
        for path in paths
    ]
    (root / "SHA256SUMS.txt").write_text(
        "\n".join(lines) + "\n",
        encoding="utf-8",
    )


def write_zip(root: Path, archive: Path) -> None:
    archive.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(
        archive,
        "w",
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=9,
    ) as handle:
        for path in sorted(item for item in root.rglob("*") if item.is_file()):
            relative = Path(RELEASE_ROOT) / path.relative_to(root)
            info = zipfile.ZipInfo(relative.as_posix(), date_time=FIXED_ZIP_TIME)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            with path.open("rb") as source:
                handle.writestr(info, source.read(), compresslevel=9)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Build the verified deterministic Stage 64 source archive"
    )
    parser.add_argument(
        "--source",
        type=Path,
        default=Path(__file__).resolve().parents[1],
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    source = args.source.resolve()
    archive = args.output.resolve()
    with tempfile.TemporaryDirectory(prefix="smpr-stage64-release-") as temporary:
        root = Path(temporary) / RELEASE_ROOT
        root.mkdir()
        copy_source(source, root)
        (root / "RELEASE_MANIFEST.json").write_text(
            json.dumps(
                build_manifest(root),
                ensure_ascii=False,
                indent=2,
            )
            + "\n",
            encoding="utf-8",
        )
        write_sums(root)
        write_zip(root, archive)
        print(f"archive: {archive}")
        print(f"archive sha256: {sha256(archive)}")
        print(
            "release files:",
            sum(path.is_file() for path in root.rglob("*")),
        )


if __name__ == "__main__":
    main()
