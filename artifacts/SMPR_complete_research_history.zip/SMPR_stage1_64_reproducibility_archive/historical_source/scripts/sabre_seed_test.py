from qiskit import QuantumCircuit, transpile
from qiskit.transpiler import CouplingMap


def build_circuit() -> QuantumCircuit:
    circuit = QuantumCircuit(5)

    circuit.h(0)
    circuit.cx(0, 4)
    circuit.cx(1, 3)
    circuit.cx(4, 2)
    circuit.cx(0, 3)

    return circuit


def build_coupling_map() -> CouplingMap:
    edges = [
        (0, 1), (1, 0),
        (1, 2), (2, 1),
        (2, 3), (3, 2),
        (3, 4), (4, 3),
    ]

    return CouplingMap(edges)


def main() -> None:
    original = build_circuit()
    coupling_map = build_coupling_map()

    results = []

    for seed in range(20):
        routed = transpile(
            original,
            coupling_map=coupling_map,
            initial_layout=[0, 1, 2, 3, 4],
            routing_method="sabre",
            optimization_level=0,
            seed_transpiler=seed,
        )

        operations = dict(routed.count_ops())

        result = {
            "seed": seed,
            "swap": operations.get("swap", 0),
            "cx": operations.get("cx", 0),
            "size": routed.size(),
            "depth": routed.depth(),
            "circuit": routed,
        }

        results.append(result)

    # 先比较 SWAP 数；若 SWAP 数相同，再比较深度。
    results.sort(
        key=lambda item: (
            item["swap"],
            item["depth"],
            item["size"],
        )
    )

    print("seed | SWAP | CX | 门数 | 深度")
    print("-" * 35)

    for result in results:
        print(
            f"{result['seed']:4d} | "
            f"{result['swap']:4d} | "
            f"{result['cx']:2d} | "
            f"{result['size']:4d} | "
            f"{result['depth']:4d}"
        )

    best = results[0]

    print("\n===== 最优结果 =====")
    print("随机种子：", best["seed"])
    print("SWAP 数：", best["swap"])
    print("线路深度：", best["depth"])
    print(best["circuit"].draw(fold=-1))


if __name__ == "__main__":
    main()