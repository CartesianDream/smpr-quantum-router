from collections import deque
from qiskit import QuantumCircuit


NUM_QUBITS = 5

# 物理耦合图：0--1--2--3--4
EDGES = [
    (0, 1),
    (1, 2),
    (2, 3),
    (3, 4),
]

# 逻辑线路
LOGICAL_GATES = [
    ("h", 0),
    ("cx", 0, 4),
    ("cx", 1, 3),
    ("cx", 4, 2),
    ("cx", 0, 3),
]


def build_adjacency(n, edges):
    adjacency = [set() for _ in range(n)]

    for u, v in edges:
        adjacency[u].add(v)
        adjacency[v].add(u)

    return adjacency


def shortest_path(adjacency, start, goal):
    """用 BFS 求物理图上的一条最短路。"""
    queue = deque([start])
    parent = {start: None}

    while queue:
        current = queue.popleft()

        if current == goal:
            break

        for neighbor in adjacency[current]:
            if neighbor not in parent:
                parent[neighbor] = current
                queue.append(neighbor)

    if goal not in parent:
        raise ValueError(f"物理点 {start} 与 {goal} 不连通")

    path = []
    current = goal

    while current is not None:
        path.append(current)
        current = parent[current]

    return list(reversed(path))


def main():
    adjacency = build_adjacency(NUM_QUBITS, EDGES)

    # logical_to_physical[q]：逻辑比特 q 当前所在物理点
    logical_to_physical = list(range(NUM_QUBITS))

    # physical_to_logical[p]：物理点 p 当前放置的逻辑比特
    physical_to_logical = list(range(NUM_QUBITS))

    routed = QuantumCircuit(NUM_QUBITS)
    swap_sequence = []

    for gate in LOGICAL_GATES:
        gate_type = gate[0]

        if gate_type == "h":
            logical_qubit = gate[1]
            physical_qubit = logical_to_physical[logical_qubit]
            routed.h(physical_qubit)
            continue

        if gate_type != "cx":
            raise ValueError(f"暂不支持门类型：{gate_type}")

        logical_a, logical_b = gate[1], gate[2]

        physical_a = logical_to_physical[logical_a]
        physical_b = logical_to_physical[logical_b]

        # 若两逻辑比特不相邻，就沿最短路移动 logical_a。
        while physical_b not in adjacency[physical_a]:
            path = shortest_path(
                adjacency,
                physical_a,
                physical_b,
            )

            swap_u = path[0]
            swap_v = path[1]

            routed.swap(swap_u, swap_v)
            swap_sequence.append((swap_u, swap_v))

            logical_u = physical_to_logical[swap_u]
            logical_v = physical_to_logical[swap_v]

            physical_to_logical[swap_u] = logical_v
            physical_to_logical[swap_v] = logical_u

            logical_to_physical[logical_u] = swap_v
            logical_to_physical[logical_v] = swap_u

            physical_a = logical_to_physical[logical_a]
            physical_b = logical_to_physical[logical_b]

        routed.cx(physical_a, physical_b)

    print("===== 最短路贪心路由结果 =====")
    print(routed.draw(fold=-1))

    print("\n===== 统计信息 =====")
    print("SWAP 数：", len(swap_sequence))
    print("线路深度：", routed.depth())
    print("总门数：", routed.size())
    print("操作统计：", dict(routed.count_ops()))
    print("SWAP 序列：", swap_sequence)

    print("\n最终逻辑到物理映射：")
    for logical, physical in enumerate(logical_to_physical):
        print(f"q_{logical} -> {physical}")


if __name__ == "__main__":
    main()