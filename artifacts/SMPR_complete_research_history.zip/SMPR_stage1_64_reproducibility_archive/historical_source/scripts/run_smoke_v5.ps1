$ErrorActionPreference = "Stop"
$env:PYTHONHASHSEED = "0"

python -m quantum_router run `
  --config .\configs\frozen_v5.toml `
  --executor persistent `
  --case-indices 1,25,28,53,56 `
  --workers 4 `
  --quality-reference .\evidence\reference\v5_cases.csv `
  --quality-policy exact `
  --output-dir .\results\stage64_v5_smoke
