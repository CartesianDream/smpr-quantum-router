from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath


BANNED_FILENAMES = {
    ".env",
    "gjq-api-key.txt",
    "kaiwu-sdk-license.txt",
}
BANNED_SUFFIXES = {".key", ".p12", ".pem", ".pfx"}
IGNORED_EXTRA_PARTS = {
    ".git",
    ".idea",
    ".mypy_cache",
    ".pytest_cache",
    "__pycache__",
    "build",
    "dist",
    "results",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def parse_sums(path: Path) -> dict[str, str]:
    entries: dict[str, str] = {}
    for line_number, raw_line in enumerate(
        path.read_text(encoding="utf-8").splitlines(),
        start=1,
    ):
        if not raw_line.strip():
            continue
        try:
            digest, relative = raw_line.split("  ", 1)
        except ValueError as error:
            raise ValueError(
                f"{path}:{line_number}: expected '<sha256>  <path>'"
            ) from error
        pure = PurePosixPath(relative)
        if pure.is_absolute() or ".." in pure.parts:
            raise ValueError(f"unsafe manifest path: {relative}")
        if len(digest) != 64 or any(
            character not in "0123456789abcdef" for character in digest
        ):
            raise ValueError(f"invalid SHA-256 at {path}:{line_number}")
        if relative in entries:
            raise ValueError(f"duplicate manifest path: {relative}")
        entries[relative] = digest
    if not entries:
        raise ValueError("SHA256SUMS.txt is empty")
    return entries


def banned_files(root: Path) -> list[str]:
    findings: list[str] = []
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        name = path.name.lower()
        if name in BANNED_FILENAMES or path.suffix.lower() in BANNED_SUFFIXES:
            findings.append(path.relative_to(root).as_posix())
    return sorted(findings)


def ignored_extra(relative: Path) -> bool:
    return (
        any(part in IGNORED_EXTRA_PARTS for part in relative.parts)
        or any(part.startswith(".venv") for part in relative.parts)
        or relative.suffix.lower() in {".pyc", ".pyo"}
    )


def verify(root: Path, *, strict: bool) -> list[str]:
    failures: list[str] = []
    sums_path = root / "SHA256SUMS.txt"
    manifest_path = root / "RELEASE_MANIFEST.json"
    if not sums_path.is_file():
        return ["missing SHA256SUMS.txt"]
    if not manifest_path.is_file():
        return ["missing RELEASE_MANIFEST.json"]

    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, UnicodeError) as error:
        failures.append(f"invalid RELEASE_MANIFEST.json: {error}")
    else:
        if manifest.get("stage") != 64:
            failures.append("release manifest stage is not 64")
        if manifest.get("version") != "0.4.0":
            failures.append("release manifest version is not 0.4.0")
        reproduction = manifest.get("verified_reproduction", {})
        if reproduction.get("passed") is not True:
            failures.append("verified reproduction is not passed")

    try:
        expected = parse_sums(sums_path)
    except (UnicodeError, ValueError) as error:
        failures.append(str(error))
        return failures

    for relative, digest in expected.items():
        path = root / Path(PurePosixPath(relative))
        if not path.is_file():
            failures.append(f"missing: {relative}")
        elif sha256(path) != digest:
            failures.append(f"hash mismatch: {relative}")

    for relative in banned_files(root):
        failures.append(f"credential-like file present: {relative}")

    if strict:
        actual = {
            path.relative_to(root).as_posix()
            for path in root.rglob("*")
            if path.is_file()
            and path.name != "SHA256SUMS.txt"
            and not ignored_extra(path.relative_to(root))
        }
        expected_paths = set(expected)
        for relative in sorted(actual - expected_paths):
            failures.append(f"unexpected file: {relative}")
        for relative in sorted(expected_paths - actual):
            failures.append(f"manifest-only file: {relative}")
    return failures


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Verify Stage 64 source-release hashes and credential exclusions"
    )
    parser.add_argument(
        "--root",
        type=Path,
        default=Path(__file__).resolve().parents[1],
    )
    parser.add_argument(
        "--strict",
        action="store_true",
        help="also reject unlisted non-generated files",
    )
    args = parser.parse_args()
    root = args.root.resolve()
    failures = verify(root, strict=args.strict)
    print(f"release root: {root}")
    print(f"verification failures: {len(failures)}")
    for failure in failures:
        print(f"  - {failure}")
    if failures:
        raise SystemExit(1)
    print("PASSED: True")


if __name__ == "__main__":
    main()
