from qiskit import QuantumCircuit, transpile
from qiskit.transpiler import CouplingMap


def build_circuit() -> QuantumCircuit:
    """构造待路由的逻辑线路。"""
    circuit = QuantumCircuit(5)

    circuit.h(0)
    circuit.cx(0, 4)
    circuit.cx(1, 3)
    circuit.cx(4, 2)
    circuit.cx(0, 3)

    return circuit


def build_coupling_map() -> CouplingMap:
    """构造双向链状物理拓扑 0--1--2--3--4。"""
    edges = [
        (0, 1), (1, 0),
        (1, 2), (2, 1),
        (2, 3), (3, 2),
        (3, 4), (4, 3),
    ]

    return CouplingMap(edges)


def print_result(name: str, circuit: QuantumCircuit) -> None:
    """打印一次路由实验的结果。"""
    operations = dict(circuit.count_ops())

    print(f"\n{'=' * 15} {name} {'=' * 15}")
    print(circuit.draw(fold=-1))

    print("门数：", circuit.size())
    print("深度：", circuit.depth())
    print("操作统计：", operations)
    print("显式 SWAP 数：", operations.get("swap", 0))
    print("CX 数：", operations.get("cx", 0))

    if circuit.layout is not None:
        print("初始映射：", circuit.layout.initial_layout)
        print("最终映射：", circuit.layout.final_layout)


def main() -> None:
    original = build_circuit()
    coupling_map = build_coupling_map()

    # 实验 A：
    # 允许 SABRE 自己选择初始逻辑—物理映射。
    automatic_layout = transpile(
        original,
        coupling_map=coupling_map,
        layout_method="sabre",
        routing_method="sabre",
        optimization_level=0,
        seed_transpiler=42,
    )

    # 实验 B：
    # 固定为恒等初始映射 q_i -> i，
    # 此时 q_0 和 q_4 位于链的两端，必须进行路由。
    fixed_layout = transpile(
        original,
        coupling_map=coupling_map,
        initial_layout=[0, 1, 2, 3, 4],
        routing_method="sabre",
        optimization_level=0,
        seed_transpiler=42,
    )

    print("原始逻辑线路：")
    print(original.draw(fold=-1))
    print("原始操作统计：", dict(original.count_ops()))

    print_result("SABRE 自动初始映射", automatic_layout)
    print_result("固定恒等初始映射", fixed_layout)


if __name__ == "__main__":
    main()