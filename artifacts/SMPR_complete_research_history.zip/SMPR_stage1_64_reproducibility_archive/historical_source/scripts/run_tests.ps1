$ErrorActionPreference = "Stop"
$env:PYTHONHASHSEED = "0"
python -m unittest discover -s .\tests -v

