$ErrorActionPreference = "Stop"
$env:PYTHONHASHSEED = "0"

python -m quantum_router run `
  --config .\configs\frozen_v5.toml `
  --executor persistent `
  --workers 4 `
  --quality-reference .\evidence\reference\v5_cases.csv `
  --quality-policy exact `
  --output-dir .\results\stage64_v5
