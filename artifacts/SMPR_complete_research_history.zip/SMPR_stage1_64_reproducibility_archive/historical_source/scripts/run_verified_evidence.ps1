$ErrorActionPreference = "Stop"
$env:PYTHONHASHSEED = "0"

python -m quantum_router verify-evidence `
  --evidence-root .\evidence\verified_20260725 `
  --output-dir .\results\stage64_verified_evidence
