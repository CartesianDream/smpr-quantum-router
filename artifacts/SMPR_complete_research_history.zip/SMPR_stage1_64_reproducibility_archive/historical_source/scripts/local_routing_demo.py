from qiskit import QuantumCircuit, transpile
from qiskit.transpiler import CouplingMap


def build_circuit() -> QuantumCircuit:
    """构造一个需要路由的五比特逻辑线路。"""
    circuit = QuantumCircuit(5)

    circuit.h(0)
    circuit.cx(0, 4)
    circuit.cx(1, 3)
    circuit.cx(4, 2)
    circuit.cx(0, 3)

    return circuit


def build_coupling_map() -> CouplingMap:
    """物理耦合图：0--1--2--3--4。"""
    undirected_edges = [
        (0, 1),
        (1, 2),
        (2, 3),
        (3, 4),
    ]

    directed_edges = []

    for u, v in undirected_edges:
        directed_edges.append((u, v))
        directed_edges.append((v, u))

    return CouplingMap(directed_edges)


def main() -> None:
    original = build_circuit()
    coupling_map = build_coupling_map()

    routed = transpile(
        original,
        coupling_map=coupling_map,
        layout_method="sabre",
        routing_method="sabre",
        optimization_level=2,
        seed_transpiler=42,
    )

    print("===== 原始逻辑线路 =====")
    print(original.draw(fold=-1))

    print("\n===== SABRE 路由后的线路 =====")
    print(routed.draw(fold=-1))

    print("\n===== 统计信息 =====")
    print("原始门数：", original.size())
    print("路由后门数：", routed.size())
    print("原始深度：", original.depth())
    print("路由后深度：", routed.depth())
    print("路由后操作：", routed.count_ops())
    print("布局信息：", routed.layout)


if __name__ == "__main__":
    main()