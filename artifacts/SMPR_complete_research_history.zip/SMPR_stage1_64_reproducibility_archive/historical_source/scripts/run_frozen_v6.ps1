$ErrorActionPreference = "Stop"
$env:PYTHONHASHSEED = "0"

python -m quantum_router run `
  --config .\configs\frozen_v6.toml `
  --executor persistent `
  --workers 4 `
  --quality-reference .\evidence\reference\v6_cases.csv `
  --quality-policy primary `
  --output-dir .\results\stage64_v6
