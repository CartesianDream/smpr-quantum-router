$ErrorActionPreference = "Stop"
$env:PYTHONHASHSEED = "0"

python -m quantum_router run `
  --config .\configs\deterministic_probe_v5.toml `
  --executor persistent `
  --case-indices 1,25,28,53,56 `
  --workers 4 `
  --output-dir .\results\stage64_deterministic_probe_v5
