# SMPR：安全多布局组合量子比特路由器

SMPR（Safe Multi-Layout Portfolio Router）是一套面向受限耦合拓扑的可复现
量子比特路由研究软件。它把 20-seed LightSABRE 作为显式质量下界，组合独立
完整策略展开和跨布局迁移候选，并按 `(SWAP, weighted_depth)` 字典序安全选优。

本目录是 Stage 64 / 0.4.0 最终复现整理版。冻结 V6 证据为：

- 120 个预注册盲测实例；
- LightSABRE 总 SWAP 3176，SMPR 总 SWAP 3051，减少 125（3.94%）；
- 逐实例 SWAP 胜/平/负 50/70/0；
- 实例级 bootstrap 95% CI `[-0.024346, -0.013634]`；
- 因子单元 cluster bootstrap 95% CI `[-0.024392, -0.013594]`；
- 语义、拓扑、指标审计均为 120/120。

2026-07-25 的独立安装复现进一步完成：

- 上传证据包 SHA-256：
  `6c7f38aecea6318b3a8407a73d8f5ae67223ea8853e8f2bc3839261c9af3a85d`；
- 内部证据文件哈希 18/18 通过；
- V5 60 例在 `exact` 策略下差异数为 0；
- V6 120 例在 `primary` 策略下差异数为 0；
- Stage 61 联合统计审计 `PASSED: True`。

## 1. 软件边界

`src/quantum_router/` 提供稳定的公共模型、确定性选择规则和统一 CLI。
`experiments/` 保存 Stage 1--61 历史与冻结实验脚本。历史 CSV 列名、候选标签
和阶段脚本名称为复现已有哈希证据而保留，不代表 Stage 64 的正式算法名称。
`evidence/stage64_public/` 提供使用“独立展开”和“跨布局”名称的公开结果表。

两种选择模式必须明确区分：

- `legacy`：复现冻结 V5/V6，使用历史运行时间破平；
- `deterministic`：Stage 64 正式规范，使用
  `(seed, initial_mapping, label)` 破平，不依赖墙钟时间。

两者都先比较 `(SWAP, weighted_depth, backend_priority)`，因此质量下界相同；
但确定性模式属于新的实现版本，不能把 V6 再标为其未见盲测。

## 2. 环境与安装

支持 Python 3.10、3.11、3.12，冻结依赖为 Qiskit 2.4.2 和
qiskit-qasm3-import 0.6.0。后者用于导出后重新载入 OpenQASM 3 并执行审计。
Windows PowerShell：

```powershell
py -3.10 -m venv .venv-smpr
.\.venv-smpr\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r .\requirements-frozen.txt
python -m pip install -e .
```

若 `py -3.10` 不可用，也可在已有 Python 3.10--3.12 虚拟环境中直接执行后三条
命令。安装后检查版本、输入哈希、阶段依赖和凭据泄漏：

```powershell
python -c "import quantum_router; print(quantum_router.__version__)"
python -m quantum_router doctor
python .\scripts\verify_release.py
python -m unittest discover -s .\tests -v
```

预期包版本为 `0.4.0`，测试数为 21。`doctor` 要求 Qiskit 精确为 2.4.2，
qiskit-qasm3-import 精确为 0.6.0。

## 3. 快速验证

五例 V5 冒烟测试：

```powershell
python -m quantum_router run `
  --config .\configs\frozen_v5.toml `
  --executor persistent `
  --case-indices 1,25,28,53,56 `
  --workers 4 `
  --quality-reference .\evidence\reference\v5_cases.csv `
  --quality-policy exact `
  --output-dir .\results\stage64_v5_smoke
```

若进程已完成但最终合并被中断，可在相同命令末尾加入 `--resume`。恢复结果中的
墙钟时间只表示读取和合并已有分片，不能用作路由性能数据。

完整 V5/V6：

```powershell
.\scripts\run_frozen_v5.ps1
.\scripts\run_frozen_v6.ps1
```

V6 使用 `quality-policy primary`：严格比较选中来源、SWAP、深度和三项审计，
把未选中候选的辅助深度差异交给隔离审计。已知 case 39 有一个不影响最终
选择的辅助深度差异，Stage 59 的独立重跑已经确认。

## 4. 逐实例可靠性审计

```powershell
python -m quantum_router audit `
  --v5-cases .\evidence\reference\v5_cases.csv `
  --v6-cases .\evidence\reference\v6_cases.csv `
  --output-dir .\results\stage64_case_audit
```

该命令复算总量、逐实例质量下界、映射合法性、三项审计字段、预注册
bootstrap、60 单元 cluster bootstrap 和留一层级敏感性。

验证随发布包附带的独立复现证据，并生成不含历史内部名称的公开结果：

```powershell
python -m quantum_router verify-evidence `
  --output-dir .\results\stage64_verified_evidence
```

预期显示 `evidence hashes: 18/18`、`public legacy-name leaks: 0` 和
`PASSED: True`。

## 5. 确定性模式

```powershell
.\scripts\run_deterministic_probe_v5.ps1
```

该探针只用于回归和下一版盲测准备。若要把确定性模式作为新的主要结果，应先
冻结完整配置和输入清单，再生成新的 V7 盲测；不要继续用 V6 调整参数。

## 6. 目录与文档

```text
src/quantum_router/   公共包、数据模型、安全选择和 CLI
configs/              冻结复现配置与确定性探针配置
experiments/          历史探索、冻结算法与审计脚本
data/                 V5/V6 及早期基准数据
evidence/reference/   冻结的逐实例参考结果
evidence/verified_20260725/  独立复现原始证据
evidence/stage64_public/     公开命名结果和最终审计
tests/                核心、CLI、选择、恢复和审计测试
docs/                 正式实验报告、复现指南和工程说明
scripts/              PowerShell 入口、发布构建与完整性验证
```

建议依次阅读：

1. `docs/EXPERIMENT_REPORT.md`
2. `docs/REPRODUCIBILITY.md`
3. `docs/ALGORITHM_SPECIFICATION.md`
4. `docs/STAGE64_FINAL_REPORT.md`
5. `docs/STAGE63_ENGINEERING_REPORT.md`（历史工程整理记录）

## 7. 安全与发布

不要把 API key、云 SDK 许可证、`.env`、私钥或本机凭据放入仓库或压缩包。
构建脚本会拒绝常见凭据文件名和密钥后缀。若密钥曾进入任何共享压缩包，应
立即撤销并重新生成。

正式公开发布前仍需由版权所有者选择许可证，并补充仓库提交号、CPU、操作
系统和完整运行日志。当前许可占位不等同于开源授权。
