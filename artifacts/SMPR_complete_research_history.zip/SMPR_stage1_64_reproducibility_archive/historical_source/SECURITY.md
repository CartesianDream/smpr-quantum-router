# Security

Do not store API keys, cloud credentials, Qiskit tokens, or SDK license files
in this repository.  Supply credentials through the provider's supported
credential store or environment variables.

The Stage 62 handoff intentionally excludes `gjq-api-key.txt`.  If a credential
was ever placed in an archive or shared channel, revoke it and issue a new one.

