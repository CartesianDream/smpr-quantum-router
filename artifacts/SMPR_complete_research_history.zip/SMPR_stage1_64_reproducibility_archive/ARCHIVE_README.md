# SMPR Stage 1–64 complete reproducibility archive

This archive preserves the complete research-development source tree that led
to the frozen V5/V6 evidence. It intentionally retains historical filenames,
schema fields, candidate labels, comments, and compatibility behavior.

Do not use this archive as the public API. The clean `SMPR_quantum_router_public`
package is the maintained public core. The two artifacts are separated because
renaming historical fields would invalidate exact reproduction and hashes,
while publishing those fields as the main API would expose obsolete internal
terminology.

## Frozen results

- V5: LightSABRE / selected total SWAP = 1691 / 1641 over 60 cases.
- V6: LightSABRE / selected total SWAP = 3176 / 3051 over 120 blind cases.
- V6 per-case wins / ties / losses = 50 / 70 / 0.
- V6 relative reduction = 3.9358%.
- All three V5/V6 audits passed.
- Independent Windows reproduction obtained zero primary mismatches.

## Use

1. Enter `historical_source/`.
2. Follow its `README.md` and `docs/REPRODUCIBILITY.md`.
3. Install the exact dependencies from `requirements-frozen.txt`.
4. Run `python scripts/verify_release.py` before executing experiments.
5. Keep `PYTHONHASHSEED=0`.

The archive is evidence-preserving, not terminology-normalized. Its license
placeholder also requires copyright-holder review before public redistribution.

Run `python verify_archive.py` immediately after extraction. The verifier
requires exact agreement with all 316 recorded source paths, byte sizes, and
SHA-256 digests, verifies the outer metadata hashes, and rejects known
credential filenames.

Historical examples may contain code that *refers* to local credential
filenames, but no credential file is included. Do not insert credentials into
this archive. Embedded ZIP files are intentionally preserved because they were
part of the handed-off research tree; treat them as evidence snapshots, not as
the maintained public API.
