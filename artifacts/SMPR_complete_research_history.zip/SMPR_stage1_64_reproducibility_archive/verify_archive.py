from __future__ import annotations

import csv
import hashlib
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "historical_source"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    failures: list[str] = []
    with (ROOT / "ORIGINAL_SOURCE_SHA256SUMS.csv").open(
        "r", encoding="utf-8-sig", newline=""
    ) as handle:
        rows = list(csv.DictReader(handle))

    expected_paths = {str(row["Path"]) for row in rows}
    actual_paths = {
        path.relative_to(SOURCE).as_posix()
        for path in SOURCE.rglob("*")
        if path.is_file()
    }
    for relative in sorted(expected_paths - actual_paths):
        failures.append(f"missing source: {relative}")
    for relative in sorted(actual_paths - expected_paths):
        failures.append(f"unrecorded source: {relative}")

    for row in rows:
        path = SOURCE / str(row["Path"])
        if not path.is_file():
            continue
        if path.stat().st_size != int(row["Bytes"]):
            failures.append(f"size mismatch: {row['Path']}")
        if sha256(path) != str(row["SHA256"]).lower():
            failures.append(f"hash mismatch: {row['Path']}")

    for line in (ROOT / "SHA256SUMS.txt").read_text(encoding="utf-8").splitlines():
        digest, relative = line.split(maxsplit=1)
        path = ROOT / relative.strip()
        if not path.is_file():
            failures.append(f"missing archive metadata: {relative.strip()}")
        elif sha256(path) != digest.lower():
            failures.append(f"archive metadata hash mismatch: {relative.strip()}")

    prohibited = {
        "gjq-api-key.txt",
        "kaiwu-sdk-license.txt",
        ".env",
        "id_rsa",
        "id_ed25519",
    }
    credential_files = sorted(
        path.relative_to(SOURCE).as_posix()
        for path in SOURCE.rglob("*")
        if path.is_file() and path.name.lower() in prohibited
    )
    failures.extend(
        f"credential-like file present: {relative}" for relative in credential_files
    )

    print(f"historical source files: {len(actual_paths)}")
    print(f"recorded source files: {len(rows)}")
    print(f"verification failures: {len(failures)}")
    for failure in failures:
        print(f"[FAIL] {failure}")
    print(f"PASSED: {not failures}")
    raise SystemExit(1 if failures else 0)


if __name__ == "__main__":
    main()
